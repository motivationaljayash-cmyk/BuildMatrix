import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { useEffect } from 'react';
import { AuthProvider } from '@/context/AuthContext';
import { Navbar, Footer } from '@/components/Layout';
import { BuyerLayout, SellerLayout, TransporterLayout, AdminLayout } from '@/components/DashboardLayouts';
import Home from '@/pages/Home';
import Marketplace from '@/pages/Marketplace';
import CategoriesPage from '@/pages/Categories';
import ProductDetail from '@/pages/ProductDetail';
import Login from '@/pages/auth/Login';
import Signup from '@/pages/auth/Signup';
import ForgotPassword from '@/pages/auth/ForgotPassword';
import BuyerDashboard from '@/pages/buyer/BuyerDashboard';
import BuyerSearch from '@/pages/buyer/Search';
import BuyerCart from '@/pages/buyer/Cart';
import BuyerOrders from '@/pages/buyer/Orders';
import BuyerOrderDetail from '@/pages/buyer/OrderDetail';
import BuyerSaved from '@/pages/buyer/Saved';
import BuyerAddresses from '@/pages/buyer/Addresses';
import BuyerProfile from '@/pages/buyer/Profile';
import BuyerSupport from '@/pages/buyer/Support';
import SellerRegistration from '@/pages/seller/SellerRegistration';
import SellerDashboard from '@/pages/seller/SellerDashboard';
import SellerProducts from '@/pages/seller/Products';
import SellerAddProduct from '@/pages/seller/AddProduct';
import SellerOrders from '@/pages/seller/Orders';
import SellerEarnings from '@/pages/seller/Earnings';
import SellerStoreProfile from '@/pages/seller/StoreProfile';
import SellerSupport from '@/pages/seller/Support';
import TransporterRegistration from '@/pages/transporter/TransporterRegistration';
import TransporterDashboard from '@/pages/transporter/TransporterDashboard';
import TransporterJobs from '@/pages/transporter/Jobs';
import TransporterVehicle from '@/pages/transporter/Vehicle';
import TransporterProfile from '@/pages/transporter/Profile';
import TransporterSupport from '@/pages/transporter/Support';
import AdminDashboard from '@/pages/admin/AdminDashboard';
import AdminSellers from '@/pages/admin/Sellers';
import AdminProducts from '@/pages/admin/Products';
import AdminOrders from '@/pages/admin/Orders';
import AdminPayments from '@/pages/admin/Payments';
import AdminTransporters from '@/pages/admin/Transporters';
import AdminSettings from '@/pages/admin/Settings';
import AdminSupport from '@/pages/admin/Support';
import NotFound from '@/pages/NotFound';
import About from '@/pages/About';
import Contact from '@/pages/Contact';
import { trackVisit } from '@/lib/trackVisit';
import { ProtectedRoute } from '@/components/Layout';

function VisitorTracker() {
  const location = window.location.pathname;
  useEffect(() => { trackVisit(location); }, [location]);
  return null;
}

function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <VisitorTracker />
        <div className="flex min-h-screen flex-col">
          <Navbar />
          <div className="flex-1">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/marketplace" element={<Marketplace />} />
              <Route path="/categories" element={<CategoriesPage />} />
              <Route path="/about" element={<About />} />
              <Route path="/contact" element={<Contact />} />
              <Route path="/product/:id" element={<ProductDetail />} />
              <Route path="/login" element={<Login />} />
              <Route path="/signup" element={<Signup />} />
              <Route path="/forgot-password" element={<ForgotPassword />} />

              <Route path="/buyer" element={<BuyerLayout />}>
                <Route index element={<BuyerDashboard />} />
                <Route path="search" element={<BuyerSearch />} />
                <Route path="cart" element={<BuyerCart />} />
                <Route path="orders" element={<BuyerOrders />} />
                <Route path="orders/:id" element={<BuyerOrderDetail />} />
                <Route path="saved" element={<BuyerSaved />} />
                <Route path="addresses" element={<BuyerAddresses />} />
                <Route path="profile" element={<BuyerProfile />} />
                <Route path="support" element={<BuyerSupport />} />
              </Route>

              <Route path="/seller/register" element={<ProtectedRoute allowedRoles={['seller', 'admin', 'buyer']}><SellerRegistration /></ProtectedRoute>} />
              <Route path="/seller" element={<SellerLayout />}>
                <Route index element={<SellerDashboard />} />
                <Route path="products" element={<SellerProducts />} />
                <Route path="products/add" element={<SellerAddProduct />} />
                <Route path="products/:id/edit" element={<SellerAddProduct />} />
                <Route path="orders" element={<SellerOrders />} />
                <Route path="earnings" element={<SellerEarnings />} />
                <Route path="store-profile" element={<SellerStoreProfile />} />
                <Route path="support" element={<SellerSupport />} />
              </Route>

              <Route path="/transporter/register" element={<ProtectedRoute allowedRoles={['transporter', 'admin', 'buyer']}><TransporterRegistration /></ProtectedRoute>} />
              <Route path="/transporter" element={<TransporterLayout />}>
                <Route index element={<TransporterDashboard />} />
                <Route path="jobs" element={<TransporterJobs />} />
                <Route path="vehicle" element={<TransporterVehicle />} />
                <Route path="profile" element={<TransporterProfile />} />
                <Route path="support" element={<TransporterSupport />} />
              </Route>

              <Route path="/admin" element={<AdminLayout />}>
                <Route index element={<AdminDashboard />} />
                <Route path="sellers" element={<AdminSellers />} />
                <Route path="products" element={<AdminProducts />} />
                <Route path="orders" element={<AdminOrders />} />
                <Route path="payments" element={<AdminPayments />} />
                <Route path="transporters" element={<AdminTransporters />} />
                <Route path="settings" element={<AdminSettings />} />
                <Route path="support" element={<AdminSupport />} />
              </Route>

              <Route path="*" element={<NotFound />} />
            </Routes>
          </div>
          <Footer />
        </div>
      </BrowserRouter>
    </AuthProvider>
  );
}

export default App;
