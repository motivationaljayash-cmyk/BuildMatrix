import { Link } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { Search, MapPin, Package, Truck, Store, ArrowRight, Building2, Package as PackageIcon, Truck as TruckIcon, Store as StoreIcon, CheckCircle2, Layers, ShoppingCart, Banknote, Headphones } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { Category, PlatformSettings } from '@/types';

const CATEGORY_ICONS: Record<string, typeof Package> = {
  cement: Package,
  'steel-tmt': Layers,
  sand: Layers,
  'bricks-blocks': Building2,
  aggregates: Layers,
  'pipes-plumbing': Package,
  tiles: Layers,
  paint: Package,
  electrical: Package,
  'hardware-tools': Package,
  'construction-equipment': Truck,
  other: Package,
};

export default function Home() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [settings, setSettings] = useState<PlatformSettings | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [location, setLocation] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      const [{ data: catData }, { data: settingsData }] = await Promise.all([
        supabase.from('categories').select('*').eq('is_active', true).order('sort_order'),
        supabase.from('platform_settings').select('*').eq('id', 1).maybeSingle(),
      ]);
      setCategories((catData as Category[]) ?? []);
      setSettings(settingsData as PlatformSettings | null);
    };
    fetchData();
  }, []);

  const platformName = settings?.platform_name ?? 'BuildMatrix';
  const tagline = settings?.tagline ?? 'Construction Materials. Local Suppliers. Delivered.';

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const params = new URLSearchParams();
    if (searchQuery) params.set('q', searchQuery);
    if (location) params.set('location', location);
    window.location.href = `/marketplace?${params.toString()}`;
  };

  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
        <div className="absolute inset-0 opacity-10" style={{
          backgroundImage: 'radial-gradient(circle at 25% 25%, white 1px, transparent 1px), radial-gradient(circle at 75% 75%, white 1px, transparent 1px)',
          backgroundSize: '50px 50px'
        }} />
        <div className="relative mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8 lg:py-28">
          <div className="mx-auto max-w-3xl text-center">
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-slate-700 bg-slate-800/50 px-4 py-1.5">
              <span className="flex h-2 w-2 rounded-full bg-green-400" />
              <span className="text-sm font-medium text-slate-300">Verified suppliers. Real materials.</span>
            </div>
            <h1 className="text-4xl font-bold tracking-tight text-white sm:text-5xl lg:text-6xl">
              Find Construction Materials Near You
            </h1>
            <p className="mt-4 text-lg text-slate-300 sm:text-xl">
              {tagline}
            </p>

            <form onSubmit={handleSearch} className="mx-auto mt-8 max-w-2xl space-y-3">
              <div className="flex flex-col gap-3 sm:flex-row">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search cement, steel, sand, bricks, tiles, pipes..."
                    className="w-full rounded-lg border border-slate-600 bg-slate-800/50 py-3 pl-10 pr-4 text-white placeholder-slate-400 focus:border-white focus:outline-none focus:ring-1 focus:ring-white"
                  />
                </div>
                <div className="relative flex-1">
                  <MapPin className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    placeholder="Enter delivery location"
                    className="w-full rounded-lg border border-slate-600 bg-slate-800/50 py-3 pl-10 pr-4 text-white placeholder-slate-400 focus:border-white focus:outline-none focus:ring-1 focus:ring-white"
                  />
                </div>
              </div>
              <button type="submit" className="w-full rounded-lg bg-white py-3 text-base font-semibold text-slate-900 transition-colors hover:bg-slate-100 sm:w-auto sm:px-8">
                Search Materials
              </button>
            </form>

            <div className="mt-6 flex flex-wrap items-center justify-center gap-4">
              <Link to="/signup" className="inline-flex items-center gap-1.5 text-sm font-medium text-slate-300 hover:text-white">
                <StoreIcon className="h-4 w-4" />
                Become a Seller
              </Link>
              <Link to="/signup" className="inline-flex items-center gap-1.5 text-sm font-medium text-slate-300 hover:text-white">
                <TruckIcon className="h-4 w-4" />
                Join as Transport Partner
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="mb-8 text-center">
          <h2 className="text-2xl font-bold text-slate-900 sm:text-3xl">Browse by Category</h2>
          <p className="mt-2 text-slate-600">Find the right materials from verified local suppliers</p>
        </div>
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6">
          {categories.map((cat) => {
            const Icon = CATEGORY_ICONS[cat.slug] ?? Package;
            return (
              <Link
                key={cat.id}
                to={`/marketplace?category=${cat.slug}`}
                className="group flex flex-col items-center rounded-xl border border-slate-200 bg-white p-5 transition-all hover:border-slate-900 hover:shadow-md"
              >
                <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-lg bg-slate-100 text-slate-700 transition-colors group-hover:bg-slate-900 group-hover:text-white">
                  <Icon className="h-6 w-6" />
                </div>
                <span className="text-sm font-medium text-slate-800 text-center">{cat.name}</span>
              </Link>
            );
          })}
        </div>
      </section>

      {/* How It Works */}
      <section className="bg-slate-50 py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="mb-12 text-center">
            <h2 className="text-2xl font-bold text-slate-900 sm:text-3xl">How It Works</h2>
            <p className="mt-2 text-slate-600">From finding materials to getting them delivered</p>
          </div>
          <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-5">
            {[
              { step: 1, title: 'Find', desc: 'Search for construction materials from local suppliers', icon: Search },
              { step: 2, title: 'Compare', desc: 'Compare prices, products, and sellers', icon: Layers },
              { step: 3, title: 'Order', desc: 'Place your order and pay via UPI', icon: ShoppingCart },
              { step: 4, title: 'Transport', desc: 'Arrange delivery through transport partners', icon: Truck },
              { step: 5, title: 'Receive', desc: 'Track your delivery and receive materials', icon: CheckCircle2 },
            ].map((item) => (
              <div key={item.step} className="relative text-center">
                <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-slate-900 text-white">
                  <item.icon className="h-6 w-6" />
                </div>
                <div className="mb-1 text-xs font-bold text-slate-400">STEP {item.step}</div>
                <h3 className="text-lg font-semibold text-slate-900">{item.title}</h3>
                <p className="mt-1 text-sm text-slate-600">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Seller CTA */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          <div className="rounded-2xl border border-slate-200 bg-white p-8">
            <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-lg bg-slate-100">
              <StoreIcon className="h-6 w-6 text-slate-700" />
            </div>
            <h3 className="text-xl font-bold text-slate-900">Sell Construction Materials</h3>
            <p className="mt-2 text-slate-600">
              Register your business, list your products, and reach buyers in your area. Manage orders and grow your construction supply business.
            </p>
            <Link to="/signup" className="mt-6 inline-flex items-center gap-2 rounded-lg bg-slate-900 px-5 py-2.5 text-sm font-medium text-white hover:bg-slate-800">
              Start Selling
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
          <div className="rounded-2xl border border-slate-200 bg-white p-8">
            <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-lg bg-slate-100">
              <TruckIcon className="h-6 w-6 text-slate-700" />
            </div>
            <h3 className="text-xl font-bold text-slate-900">Join as Transport Partner</h3>
            <p className="mt-2 text-slate-600">
              Register your vehicle, find delivery jobs near you, and earn by transporting construction materials for buyers and sellers.
            </p>
            <Link to="/signup" className="mt-6 inline-flex items-center gap-2 rounded-lg bg-slate-900 px-5 py-2.5 text-sm font-medium text-white hover:bg-slate-800">
              Join as Transporter
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="bg-slate-900 py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4">
            {[
              { icon: PackageIcon, title: 'Real Products', desc: 'Materials from verified sellers with actual stock and pricing' },
              { icon: Banknote, title: 'UPI Payments', desc: 'Pay securely via UPI with manual verification' },
              { icon: TruckIcon, title: 'Transport Network', desc: 'Connect with transporters for material delivery' },
              { icon: Headphones, title: 'Support', desc: 'Get help with orders, payments, and deliveries' },
            ].map((f) => (
              <div key={f.title} className="text-center">
                <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-lg bg-slate-800 text-white">
                  <f.icon className="h-6 w-6" />
                </div>
                <h3 className="text-lg font-semibold text-white">{f.title}</h3>
                <p className="mt-1 text-sm text-slate-400">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
