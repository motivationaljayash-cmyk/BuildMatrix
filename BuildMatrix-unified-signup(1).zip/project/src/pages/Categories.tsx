import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import type { Category } from '@/types';
import { Package, Layers, Building2, Truck } from 'lucide-react';

const CATEGORY_ICONS: Record<string, typeof Package> = {
  cement: Package,
  'steel-tmt': Layers,
  sand: Layers,
  'bricks-blocks': Building2,
  aggregates: Layers,
  'pipes-plumbing': Package,
  tiles: Layers,
  paint: Package,
  electrical: Package,
  'hardware-tools': Package,
  'construction-equipment': Truck,
  other: Package,
};

export default function CategoriesPage() {
  const [categories, setCategories] = useState<Category[]>([]);

  useEffect(() => {
    const fetchCategories = async () => {
      const { data } = await supabase.from('categories').select('*').eq('is_active', true).order('sort_order');
      setCategories((data as Category[]) ?? []);
    };
    fetchCategories();
  }, []);

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      <h1 className="text-2xl font-bold text-slate-900">All Categories</h1>
      <p className="mt-1 text-sm text-slate-600">Browse construction materials by category</p>
      <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6">
        {categories.map((cat) => {
          const Icon = CATEGORY_ICONS[cat.slug] ?? Package;
          return (
            <Link
              key={cat.id}
              to={`/marketplace?category=${cat.slug}`}
              className="group flex flex-col items-center rounded-xl border border-slate-200 bg-white p-6 transition-all hover:border-slate-900 hover:shadow-md"
            >
              <div className="mb-3 flex h-14 w-14 items-center justify-center rounded-lg bg-slate-100 text-slate-700 transition-colors group-hover:bg-slate-900 group-hover:text-white">
                <Icon className="h-7 w-7" />
              </div>
              <span className="text-sm font-medium text-slate-800 text-center">{cat.name}</span>
              {cat.description && <span className="mt-1 text-xs text-slate-500 text-center line-clamp-2">{cat.description}</span>}
            </Link>
          );
        })}
      </div>
    </div>
  );
}
