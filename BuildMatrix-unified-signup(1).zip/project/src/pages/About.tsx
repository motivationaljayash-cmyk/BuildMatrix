import { Building2, ShieldCheck, Truck, Users } from 'lucide-react';

export default function About() {
  return (
    <div className="bg-white">
      <section className="border-b border-slate-200 bg-slate-50">
        <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-3 py-1.5 text-sm font-medium text-slate-700">
              <Building2 className="h-4 w-4" /> BuildMatrix
            </div>
            <h1 className="text-4xl font-bold tracking-tight text-slate-900 sm:text-5xl">Construction materials, connected.</h1>
            <p className="mt-5 text-lg leading-8 text-slate-600">BuildMatrix connects buyers with local construction-material suppliers and delivery partners through one marketplace.</p>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:px-8">
        <div className="grid gap-6 md:grid-cols-3">
          <div className="card"><Users className="h-7 w-7 text-slate-900" /><h2 className="mt-4 font-semibold text-slate-900">Local suppliers</h2><p className="mt-2 text-sm leading-6 text-slate-600">Discover construction products from registered sellers in one place.</p></div>
          <div className="card"><Truck className="h-7 w-7 text-slate-900" /><h2 className="mt-4 font-semibold text-slate-900">Delivery options</h2><p className="mt-2 text-sm leading-6 text-slate-600">Connect orders with transport partners for material movement.</p></div>
          <div className="card"><ShieldCheck className="h-7 w-7 text-slate-900" /><h2 className="mt-4 font-semibold text-slate-900">Verified workflow</h2><p className="mt-2 text-sm leading-6 text-slate-600">Seller verification and payment-proof review help keep marketplace activity organized.</p></div>
        </div>
      </section>
    </div>
  );
}
