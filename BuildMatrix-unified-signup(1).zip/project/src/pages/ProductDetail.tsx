import { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import type { Product, Cart } from '@/types';
import { formatCurrency } from '@/lib/utils';
import { EmptyState } from '@/components/EmptyState';
import { Package, MapPin, Store, Truck, CheckCircle2, ShoppingCart, Minus, Plus, ArrowLeft, ShieldCheck } from 'lucide-react';

export default function ProductDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [quantity, setQuantity] = useState(1);
  const [addingToCart, setAddingToCart] = useState(false);
  const [selectedImage, setSelectedImage] = useState(0);

  useEffect(() => {
    const fetchProduct = async () => {
      if (!id) return;
      setLoading(true);
      const { data } = await supabase
        .from('products')
        .select(`
          *,
          category:categories(*),
          seller:seller_profiles(*),
          product_images(*),
          product_specs(*)
        `)
        .eq('id', id)
        .maybeSingle();
      setProduct(data as Product | null);
      if (data) setQuantity((data as Product).min_order_quantity || 1);
      setLoading(false);
    };
    fetchProduct();
  }, [id]);

  const handleAddToCart = async () => {
    if (!user) {
      navigate('/login');
      return;
    }
    if (!product) return;
    setAddingToCart(true);

    try {
      let cartId: string | null = null;
      const { data: existingCart } = await supabase
        .from('carts')
        .select('*, cart_items(*)')
        .eq('user_id', user.id)
        .maybeSingle();

      if (existingCart) {
        const cart = existingCart as Cart & { cart_items: { product_id: string }[] };
        if (cart.seller_id && cart.seller_id !== product.seller_id && cart.cart_items && cart.cart_items.length > 0) {
          alert('Your cart already has products from another seller. Please checkout or remove those items first.');
          setAddingToCart(false);
          return;
        }
        cartId = cart.id;
        if (!cart.seller_id) {
          await supabase.from('carts').update({ seller_id: product.seller_id }).eq('id', cart.id);
        }
      } else {
        const { data: newCart } = await supabase
          .from('carts')
          .insert({ user_id: user.id, seller_id: product.seller_id })
          .select()
          .single();
        cartId = (newCart as Cart)?.id ?? null;
      }

      if (!cartId) {
        alert('Failed to access cart. Please try again.');
        setAddingToCart(false);
        return;
      }

      const { data: existingItem } = await supabase
        .from('cart_items')
        .select('*')
        .eq('cart_id', cartId)
        .eq('product_id', product.id)
        .maybeSingle();

      if (existingItem) {
        await supabase
          .from('cart_items')
          .update({ quantity: (existingItem as { quantity: number }).quantity + quantity })
          .eq('id', existingItem.id);
      } else {
        await supabase.from('cart_items').insert({
          cart_id: cartId,
          product_id: product.id,
          quantity,
        });
      }

      navigate('/buyer/cart');
    } catch (err) {
      alert('Failed to add to cart. Please try again.');
    }
    setAddingToCart(false);
  };

  if (loading) {
    return (
      <div className="flex justify-center py-20">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-slate-300 border-t-slate-900" />
      </div>
    );
  }

  if (!product) {
    return (
      <EmptyState
        icon={<Package className="h-8 w-8" />}
        title="Product not found"
        description="This product may have been removed or is no longer available."
        action={<Link to="/marketplace" className="btn-primary">Back to Marketplace</Link>}
      />
    );
  }

  const images = product.product_images ?? [];

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      <Link to="/marketplace" className="mb-4 inline-flex items-center gap-1 text-sm text-slate-600 hover:text-slate-900">
        <ArrowLeft className="h-4 w-4" /> Back to marketplace
      </Link>

      <div className="grid grid-cols-1 gap-8 lg:grid-cols-2">
        {/* Images */}
        <div>
          <div className="aspect-square rounded-xl border border-slate-200 bg-slate-50 overflow-hidden">
            {images.length > 0 ? (
              <img src={images[selectedImage]?.image_url} alt={product.name} className="h-full w-full object-cover" />
            ) : (
              <div className="flex h-full w-full items-center justify-center">
                <Package className="h-16 w-16 text-slate-300" />
              </div>
            )}
          </div>
          {images.length > 1 && (
            <div className="mt-4 flex gap-2 overflow-x-auto">
              {images.map((img, idx) => (
                <button
                  key={img.id}
                  onClick={() => setSelectedImage(idx)}
                  className={`h-20 w-20 shrink-0 overflow-hidden rounded-lg border-2 ${selectedImage === idx ? 'border-slate-900' : 'border-slate-200'}`}
                >
                  <img src={img.image_url} alt="" className="h-full w-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Details */}
        <div>
          {product.category && (
            <Link to={`/marketplace?category=${product.category.slug}`} className="text-sm font-medium text-slate-500 hover:text-slate-900">
              {product.category.name}
            </Link>
          )}
          <h1 className="mt-1 text-2xl font-bold text-slate-900">{product.name}</h1>
          {product.brand && <p className="mt-1 text-slate-600">Brand: {product.brand}</p>}

          {product.seller && (
            <div className="mt-4 flex items-center gap-3 rounded-lg border border-slate-200 bg-white p-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-slate-100">
                <Store className="h-5 w-5 text-slate-600" />
              </div>
              <div>
                <p className="font-medium text-slate-900">{product.seller.business_name}</p>
                <div className="flex items-center gap-1.5">
                  {product.seller.verification_status === 'approved' && (
                    <span className="inline-flex items-center gap-0.5 text-xs text-green-600">
                      <ShieldCheck className="h-3 w-3" /> Verified Seller
                    </span>
                  )}
                  <span className="flex items-center gap-0.5 text-xs text-slate-500">
                    <MapPin className="h-3 w-3" /> {product.seller.city}, {product.seller.state}
                  </span>
                </div>
              </div>
            </div>
          )}

          <div className="mt-6 flex items-baseline gap-2">
            <span className="text-3xl font-bold text-slate-900">{formatCurrency(product.price)}</span>
            <span className="text-slate-500">/ {product.unit}</span>
          </div>

          {product.description && (
            <div className="mt-6">
              <h3 className="font-semibold text-slate-900">Description</h3>
              <p className="mt-2 text-sm text-slate-600 leading-relaxed">{product.description}</p>
            </div>
          )}

          <div className="mt-6 grid grid-cols-2 gap-4">
            <div className="rounded-lg border border-slate-200 p-3">
              <p className="text-xs text-slate-500">Available Stock</p>
              <p className="mt-1 font-semibold text-slate-900">{product.stock_quantity} {product.unit}</p>
            </div>
            <div className="rounded-lg border border-slate-200 p-3">
              <p className="text-xs text-slate-500">Min. Order</p>
              <p className="mt-1 font-semibold text-slate-900">{product.min_order_quantity} {product.unit}</p>
            </div>
            {product.is_delivery_available && (
              <div className="rounded-lg border border-slate-200 p-3">
                <p className="text-xs text-slate-500">Delivery</p>
                <p className="mt-1 flex items-center gap-1 font-semibold text-slate-900">
                  <Truck className="h-4 w-4" /> Available
                </p>
              </div>
            )}
            {product.estimated_delivery_days && (
              <div className="rounded-lg border border-slate-200 p-3">
                <p className="text-xs text-slate-500">Est. Delivery</p>
                <p className="mt-1 font-semibold text-slate-900">{product.estimated_delivery_days}</p>
              </div>
            )}
          </div>

          <div className="mt-6">
            <label className="label">Quantity ({product.unit})</label>
            <div className="flex items-center gap-3">
              <button
                onClick={() => setQuantity(Math.max(product.min_order_quantity, quantity - 1))}
                className="rounded-lg border border-slate-300 p-2 hover:bg-slate-50"
              >
                <Minus className="h-4 w-4" />
              </button>
              <input
                type="number"
                value={quantity}
                onChange={(e) => setQuantity(Math.max(product.min_order_quantity, parseFloat(e.target.value) || product.min_order_quantity))}
                className="input w-24 text-center"
              />
              <button
                onClick={() => setQuantity(Math.min(product.stock_quantity, quantity + 1))}
                className="rounded-lg border border-slate-300 p-2 hover:bg-slate-50"
              >
                <Plus className="h-4 w-4" />
              </button>
              <span className="text-sm text-slate-500">
                Subtotal: {formatCurrency(product.price * quantity)}
              </span>
            </div>
            {quantity > product.stock_quantity && (
              <p className="mt-1 text-xs text-red-600">Quantity exceeds available stock ({product.stock_quantity})</p>
            )}
          </div>

          <button
            onClick={handleAddToCart}
            disabled={addingToCart || quantity > product.stock_quantity || product.stock_quantity <= 0}
            className="mt-6 btn-primary w-full"
          >
            <ShoppingCart className="h-5 w-5" />
            {product.stock_quantity <= 0 ? 'Out of Stock' : 'Add to Cart'}
          </button>
        </div>
      </div>
    </div>
  );
}
