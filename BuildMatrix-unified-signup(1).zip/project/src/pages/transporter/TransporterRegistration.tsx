import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import type { TransporterProfile } from '@/types';
import { Truck, Save, ArrowRight, ShieldCheck } from 'lucide-react';

export default function TransporterRegistration() {
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  const [existing, setExisting] = useState<TransporterProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    name: '', phone: '', email: '', service_area: '', base_delivery_charge: '', additional_distance_charge: '',
  });

  useEffect(() => {
    if (!user) return;
    const fetchExisting = async () => {
      const { data } = await supabase.from('transporter_profiles').select('*').eq('user_id', user.id).maybeSingle();
      setExisting(data as TransporterProfile | null);
      if (data) {
        const t = data as TransporterProfile;
        setForm({ name: t.name, phone: t.phone, email: t.email, service_area: t.service_area, base_delivery_charge: String(t.base_delivery_charge), additional_distance_charge: String(t.additional_distance_charge) });
      } else {
        setForm(f => ({ ...f, name: profile?.full_name ?? '', email: user.email ?? '', phone: profile?.phone ?? '' }));
      }
      setLoading(false);
    };
    fetchExisting();
  }, [user, profile]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setSaving(true);
    try {
      if (existing) {
        await supabase.from('transporter_profiles').update({
          name: form.name, phone: form.phone, email: form.email, service_area: form.service_area,
          base_delivery_charge: parseFloat(form.base_delivery_charge) || 0, additional_distance_charge: parseFloat(form.additional_distance_charge) || 0,
        }).eq('id', existing.id);
      } else {
        const { error } = await supabase.from('transporter_profiles').insert({
          user_id: user.id, name: form.name, phone: form.phone, email: form.email, service_area: form.service_area,
          base_delivery_charge: parseFloat(form.base_delivery_charge) || 0, additional_distance_charge: parseFloat(form.additional_distance_charge) || 0,
        });
        if (!error) {
          await supabase.from('profiles').update({ role: 'transporter' }).eq('id', user.id);
          const { data: admins } = await supabase.from('profiles').select('id').eq('role', 'admin');
          if (admins) {
            for (const a of admins) {
              await supabase.from('notifications').insert({ user_id: a.id, title: 'New Transporter Application', message: `${form.name} has applied for transporter verification.`, type: 'verification', link: '/admin/transporters' });
            }
          }
        }
      }
      navigate('/transporter');
    } catch (err) {
      alert('Failed to save transporter profile.');
    }
    setSaving(false);
  };

  if (loading) return <div className="flex justify-center py-20"><div className="h-8 w-8 animate-spin rounded-full border-2 border-slate-300 border-t-slate-900" /></div>;

  return (
    <div className="mx-auto max-w-3xl px-4 py-8">
      <div className="mb-6">
        <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-xl bg-slate-900 text-white"><Truck className="h-6 w-6" /></div>
        <h1 className="text-2xl font-bold text-slate-900">Transporter Registration</h1>
        <p className="mt-1 text-sm text-slate-600">Register to provide delivery services for construction material orders.</p>
      </div>

      {existing && (
        <div className="mb-6 rounded-lg border border-slate-200 bg-slate-50 p-4">
          <div className="flex items-center gap-2">
            <ShieldCheck className="h-5 w-5 text-slate-600" />
            <span className="font-medium text-slate-900">Status: </span>
            <span className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${existing.verification_status === 'approved' ? 'bg-green-100 text-green-800' : existing.verification_status === 'rejected' ? 'bg-red-100 text-red-800' : 'bg-amber-100 text-amber-800'}`}>
              {existing.verification_status.charAt(0).toUpperCase() + existing.verification_status.slice(1)}
            </span>
          </div>
          {existing.verification_notes && <p className="mt-2 text-sm text-slate-600">{existing.verification_notes}</p>}
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="card space-y-4">
          <h3 className="font-semibold text-slate-900">Personal Information</h3>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div><label className="label">Full Name</label><input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="input" /></div>
            <div><label className="label">Phone</label><input required value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className="input" /></div>
            <div><label className="label">Email</label><input required type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="input" /></div>
            <div><label className="label">Service Area</label><input required value={form.service_area} onChange={(e) => setForm({ ...form, service_area: e.target.value })} className="input" placeholder="e.g. Mumbai Metropolitan Region" /></div>
          </div>
        </div>

        <div className="card space-y-4">
          <h3 className="font-semibold text-slate-900">Pricing</h3>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div><label className="label">Base Delivery Charge (INR)</label><input type="number" step="0.01" value={form.base_delivery_charge} onChange={(e) => setForm({ ...form, base_delivery_charge: e.target.value })} className="input" /></div>
            <div><label className="label">Additional Distance Charge (INR/km)</label><input type="number" step="0.01" value={form.additional_distance_charge} onChange={(e) => setForm({ ...form, additional_distance_charge: e.target.value })} className="input" /></div>
          </div>
        </div>

        <button type="submit" disabled={saving} className="btn-primary w-full">
          <Save className="h-4 w-4" /> {saving ? 'Saving...' : existing ? 'Update Profile' : 'Submit Application'}
          {!saving && <ArrowRight className="h-4 w-4" />}
        </button>
      </form>
    </div>
  );
}
