import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import type { TransporterProfile, Delivery } from '@/types';
import { Badge, EmptyState } from '@/components/Layout';
import { DELIVERY_STATUS_LABELS, DELIVERY_STATUS_COLORS, formatCurrency } from '@/lib/utils';
import { PackageX, Truck, Check, Package, MapPin } from 'lucide-react';

export default function TransporterJobs() {
  const { user } = useAuth();
  const [transporter, setTransporter] = useState<TransporterProfile | null>(null);
  const [deliveries, setDeliveries] = useState<Delivery[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    const fetchData = async () => {
      const { data: tpData } = await supabase.from('transporter_profiles').select('*').eq('user_id', user.id).maybeSingle();
      setTransporter(tpData as TransporterProfile | null);
      if (tpData) {
        const { data } = await supabase
          .from('deliveries')
          .select('*, order:orders(*)')
          .or(`transporter_id.eq.${(tpData as TransporterProfile).id},status.eq.available`)
          .order('created_at', { ascending: false });
        setDeliveries((data as Delivery[]) ?? []);
      }
      setLoading(false);
    };
    fetchData();
  }, [user]);

  const acceptJob = async (deliveryId: string) => {
    if (!transporter) return;
    await supabase.from('deliveries').update({ status: 'accepted', transporter_id: transporter.id }).eq('id', deliveryId);
    const { data: del } = await supabase.from('deliveries').select('order_id').eq('id', deliveryId).maybeSingle();
    if (del) {
      const orderDelivery = del as { order_id: string };
      const { data: order } = await supabase.from('orders').select('buyer_id').eq('id', orderDelivery.order_id).maybeSingle();
      if (order) {
        await supabase.from('notifications').insert({
          user_id: (order as { buyer_id: string }).buyer_id,
          title: 'Delivery Accepted',
          message: 'A transporter has accepted your delivery request.',
          type: 'delivery',
          link: `/buyer/orders/${orderDelivery.order_id}`,
        });
      }
    }
    refreshDeliveries();
  };

  const updateStatus = async (deliveryId: string, status: string) => {
    await supabase.from('deliveries').update({ status }).eq('id', deliveryId);
    refreshDeliveries();
  };

  const refreshDeliveries = async () => {
    if (!transporter) return;
    const { data } = await supabase
      .from('deliveries')
      .select('*, order:orders(*)')
      .or(`transporter_id.eq.${transporter.id},status.eq.available`)
      .order('created_at', { ascending: false });
    setDeliveries((data as Delivery[]) ?? []);
  };

  if (loading) return <div className="flex justify-center py-20"><div className="h-8 w-8 animate-spin rounded-full border-2 border-slate-300 border-t-slate-900" /></div>;
  if (!transporter) return <EmptyState icon={<Truck className="h-8 w-8" />} title="No transporter profile found" />;

  const availableJobs = deliveries.filter(d => d.status === 'available');
  const myJobs = deliveries.filter(d => d.transporter_id === transporter.id);

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-slate-900">Delivery Jobs</h1>

      {availableJobs.length > 0 && (
        <div>
          <h2 className="mb-3 text-lg font-semibold text-slate-900">Available Jobs</h2>
          <div className="space-y-3">
            {availableJobs.map((d) => (
              <div key={d.id} className="card">
                <div className="flex items-start justify-between">
                  <div className="space-y-1">
                    <p className="font-medium text-slate-900">{d.material_description ?? 'Construction materials'}</p>
                    <p className="text-sm text-slate-500 flex items-center gap-1"><MapPin className="h-3 w-3" /> Pickup: {d.pickup_address}</p>
                    <p className="text-sm text-slate-500 flex items-center gap-1"><MapPin className="h-3 w-3" /> Delivery: {d.delivery_address}</p>
                    {d.required_vehicle_capacity && <p className="text-sm text-slate-500">Required: {d.required_vehicle_capacity}</p>}
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-slate-900">{formatCurrency(d.delivery_charge)}</p>
                    <button onClick={() => acceptJob(d.id)} className="btn-primary mt-2 text-xs">Accept Job</button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div>
        <h2 className="mb-3 text-lg font-semibold text-slate-900">My Jobs</h2>
        {myJobs.length === 0 ? (
          <EmptyState icon={<PackageX className="h-8 w-8" />} title="No active jobs" description="Accept available delivery jobs to start earning." />
        ) : (
          <div className="space-y-3">
            {myJobs.map((d) => (
              <div key={d.id} className="card">
                <div className="flex items-start justify-between">
                  <div className="space-y-1">
                    <p className="font-medium text-slate-900">{d.material_description ?? 'Delivery'}</p>
                    <p className="text-sm text-slate-500">Pickup: {d.pickup_address}</p>
                    <p className="text-sm text-slate-500">Delivery: {d.delivery_address}</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="font-semibold text-slate-900">{formatCurrency(d.delivery_charge)}</span>
                    <Badge label={DELIVERY_STATUS_LABELS[d.status]} className={DELIVERY_STATUS_COLORS[d.status]} />
                  </div>
                </div>
                <div className="mt-3 flex flex-wrap gap-2">
                  {d.status === 'accepted' && <button onClick={() => updateStatus(d.id, 'pickup')} className="btn-primary text-xs"><Package className="h-3.5 w-3.5" /> At Pickup</button>}
                  {d.status === 'pickup' && <button onClick={() => updateStatus(d.id, 'in_transit')} className="btn-primary text-xs"><Truck className="h-3.5 w-3.5" /> Start Transit</button>}
                  {d.status === 'in_transit' && <button onClick={() => updateStatus(d.id, 'delivered')} className="btn-primary text-xs"><Check className="h-3.5 w-3.5" /> Mark Delivered</button>}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
