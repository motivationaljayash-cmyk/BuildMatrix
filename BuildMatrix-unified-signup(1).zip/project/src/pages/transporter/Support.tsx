import BuyerSupport from '@/pages/buyer/Support';
export default function TransporterSupport() { return <BuyerSupport />; }
