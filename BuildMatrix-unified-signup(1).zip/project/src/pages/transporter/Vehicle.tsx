import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import type { TransporterProfile, Vehicle } from '@/types';
import { EmptyState } from '@/components/EmptyState';
import { Truck, Plus, Trash2, X } from 'lucide-react';

export default function TransporterVehicle() {
  const { user } = useAuth();
  const [transporter, setTransporter] = useState<TransporterProfile | null>(null);
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ vehicle_type: 'truck' as Vehicle['vehicle_type'], vehicle_number: '', vehicle_capacity: '' });

  useEffect(() => {
    if (!user) return;
    const fetchData = async () => {
      const { data: tpData } = await supabase.from('transporter_profiles').select('*').eq('user_id', user.id).maybeSingle();
      setTransporter(tpData as TransporterProfile | null);
      if (tpData) {
        const { data: vData } = await supabase.from('vehicles').select('*').eq('transporter_id', (tpData as TransporterProfile).id);
        setVehicles((vData as Vehicle[]) ?? []);
      }
      setLoading(false);
    };
    fetchData();
  }, [user]);

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!transporter) return;
    await supabase.from('vehicles').insert({ transporter_id: transporter.id, ...form });
    setShowForm(false);
    setForm({ vehicle_type: 'truck', vehicle_number: '', vehicle_capacity: '' });
    const { data } = await supabase.from('vehicles').select('*').eq('transporter_id', transporter.id);
    setVehicles((data as Vehicle[]) ?? []);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this vehicle?')) return;
    await supabase.from('vehicles').delete().eq('id', id);
    setVehicles((prev) => prev.filter((v) => v.id !== id));
  };

  if (loading) return <div className="flex justify-center py-20"><div className="h-8 w-8 animate-spin rounded-full border-2 border-slate-300 border-t-slate-900" /></div>;
  if (!transporter) return <EmptyState icon={<Truck className="h-8 w-8" />} title="No transporter profile found" />;

  const vehicleTypes: { value: Vehicle['vehicle_type']; label: string }[] = [
    { value: 'truck', label: 'Truck' }, { value: 'pickup', label: 'Pickup' }, { value: 'mini_truck', label: 'Mini Truck' },
    { value: 'tractor', label: 'Tractor' }, { value: 'trailer', label: 'Trailer' }, { value: 'other', label: 'Other' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-slate-900">My Vehicles</h1>
        <button onClick={() => setShowForm(!showForm)} className="btn-primary"><Plus className="h-4 w-4" /> Add Vehicle</button>
      </div>

      {showForm && (
        <form onSubmit={handleAdd} className="card space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-slate-900">Add Vehicle</h3>
            <button type="button" onClick={() => setShowForm(false)}><X className="h-4 w-4 text-slate-400" /></button>
          </div>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <div><label className="label">Vehicle Type</label><select value={form.vehicle_type} onChange={(e) => setForm({ ...form, vehicle_type: e.target.value as Vehicle['vehicle_type'] })} className="input">{vehicleTypes.map((v) => <option key={v.value} value={v.value}>{v.label}</option>)}</select></div>
            <div><label className="label">Vehicle Number</label><input required value={form.vehicle_number} onChange={(e) => setForm({ ...form, vehicle_number: e.target.value })} className="input" placeholder="MH01 AB 1234" /></div>
            <div><label className="label">Capacity</label><input required value={form.vehicle_capacity} onChange={(e) => setForm({ ...form, vehicle_capacity: e.target.value })} className="input" placeholder="e.g. 5 tonnes" /></div>
          </div>
          <button type="submit" className="btn-primary">Save Vehicle</button>
        </form>
      )}

      {vehicles.length === 0 && !showForm ? (
        <EmptyState icon={<Truck className="h-8 w-8" />} title="No vehicles added" description="Add your vehicle details so you can accept delivery jobs that match your capacity." />
      ) : (
        <div className="space-y-3">
          {vehicles.map((v) => (
            <div key={v.id} className="card flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-slate-100"><Truck className="h-5 w-5 text-slate-600" /></div>
                <div>
                  <p className="font-medium text-slate-900">{v.vehicle_number}</p>
                  <p className="text-sm text-slate-500">{vehicleTypes.find((t) => t.value === v.vehicle_type)?.label ?? v.vehicle_type} · {v.vehicle_capacity}</p>
                </div>
              </div>
              <button onClick={() => handleDelete(v.id)} className="rounded-lg p-2 text-red-500 hover:bg-red-50"><Trash2 className="h-4 w-4" /></button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
