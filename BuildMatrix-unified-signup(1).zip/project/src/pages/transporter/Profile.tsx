import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import type { TransporterProfile } from '@/types';
import { Save, Truck } from 'lucide-react';

export default function TransporterProfilePage() {
  const { user } = useAuth();
  const [transporter, setTransporter] = useState<TransporterProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [form, setForm] = useState({ name: '', phone: '', email: '', service_area: '', base_delivery_charge: '', additional_distance_charge: '' });

  useEffect(() => {
    if (!user) return;
    const fetchData = async () => {
      const { data } = await supabase.from('transporter_profiles').select('*').eq('user_id', user.id).maybeSingle();
      setTransporter(data as TransporterProfile | null);
      if (data) {
        const t = data as TransporterProfile;
        setForm({ name: t.name, phone: t.phone, email: t.email, service_area: t.service_area, base_delivery_charge: String(t.base_delivery_charge), additional_distance_charge: String(t.additional_distance_charge) });
      }
      setLoading(false);
    };
    fetchData();
  }, [user]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!transporter) return;
    setSaving(true);
    await supabase.from('transporter_profiles').update({
      name: form.name, phone: form.phone, email: form.email, service_area: form.service_area,
      base_delivery_charge: parseFloat(form.base_delivery_charge) || 0, additional_distance_charge: parseFloat(form.additional_distance_charge) || 0,
    }).eq('id', transporter.id);
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  if (loading) return <div className="flex justify-center py-20"><div className="h-8 w-8 animate-spin rounded-full border-2 border-slate-300 border-t-slate-900" /></div>;
  if (!transporter) return <div className="text-center py-20"><Truck className="mx-auto mb-4 h-12 w-12 text-slate-300" /><p className="text-slate-600">No transporter profile found.</p></div>;

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-slate-900">My Profile</h1>
      <form onSubmit={handleSubmit} className="card max-w-lg space-y-4">
        <div><label className="label">Full Name</label><input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="input" /></div>
        <div><label className="label">Phone</label><input required value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className="input" /></div>
        <div><label className="label">Email</label><input required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="input" /></div>
        <div><label className="label">Service Area</label><input required value={form.service_area} onChange={(e) => setForm({ ...form, service_area: e.target.value })} className="input" /></div>
        <div><label className="label">Base Delivery Charge (INR)</label><input type="number" step="0.01" value={form.base_delivery_charge} onChange={(e) => setForm({ ...form, base_delivery_charge: e.target.value })} className="input" /></div>
        <div><label className="label">Additional Distance Charge (INR/km)</label><input type="number" step="0.01" value={form.additional_distance_charge} onChange={(e) => setForm({ ...form, additional_distance_charge: e.target.value })} className="input" /></div>
        <button type="submit" disabled={saving} className="btn-primary"><Save className="h-4 w-4" /> {saving ? 'Saving...' : 'Save Changes'}</button>
        {saved && <p className="text-sm text-green-600">Profile updated successfully.</p>}
      </form>
    </div>
  );
}
