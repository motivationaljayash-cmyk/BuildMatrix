import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import type { TransporterProfile, Delivery } from '@/types';
import { StatCard, Badge, EmptyState } from '@/components/Layout';
import { formatCurrency, DELIVERY_STATUS_LABELS, DELIVERY_STATUS_COLORS, SELLER_STATUS_LABELS, SELLER_STATUS_COLORS } from '@/lib/utils';
import { Truck, PackageX, Package, CheckCircle2, AlertCircle, ShieldCheck } from 'lucide-react';

export default function TransporterDashboard() {
  const { user } = useAuth();
  const [transporter, setTransporter] = useState<TransporterProfile | null>(null);
  const [deliveries, setDeliveries] = useState<Delivery[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    const fetchData = async () => {
      const { data: tpData } = await supabase.from('transporter_profiles').select('*').eq('user_id', user.id).maybeSingle();
      setTransporter(tpData as TransporterProfile | null);
      if (tpData) {
        const { data: delData } = await supabase
          .from('deliveries')
          .select('*, order:orders(*)')
          .or(`transporter_id.eq.${(tpData as TransporterProfile).id},status.eq.available`)
          .order('created_at', { ascending: false });
        setDeliveries((delData as Delivery[]) ?? []);
      }
      setLoading(false);
    };
    fetchData();
  }, [user]);

  if (loading) return <div className="flex justify-center py-20"><div className="h-8 w-8 animate-spin rounded-full border-2 border-slate-300 border-t-slate-900" /></div>;

  if (!transporter) {
    return <EmptyState icon={<Truck className="h-8 w-8" />} title="No transporter profile found" description="Register as a transporter to start accepting delivery jobs." action={<Link to="/transporter/register" className="btn-primary">Register Now</Link>} />;
  }

  const availableJobs = deliveries.filter(d => d.status === 'available');
  const activeJobs = deliveries.filter(d => ['accepted', 'pickup', 'in_transit'].includes(d.status));
  const completedJobs = deliveries.filter(d => d.status === 'delivered');
  const earnings = completedJobs.reduce((sum, d) => sum + d.delivery_charge, 0);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">{transporter.name}</h1>
          <div className="mt-1 flex items-center gap-2">
            <Badge label={SELLER_STATUS_LABELS[transporter.verification_status]} className={SELLER_STATUS_COLORS[transporter.verification_status]} />
            <span className="text-sm text-slate-500">{transporter.service_area}</span>
          </div>
        </div>
        <Link to="/transporter/jobs" className="btn-primary"><Truck className="h-4 w-4" /> View Jobs</Link>
      </div>

      {transporter.verification_status === 'pending' && (
        <div className="rounded-lg border border-amber-200 bg-amber-50 p-4">
          <div className="flex items-center gap-2">
            <AlertCircle className="h-5 w-5 text-amber-600" />
            <p className="text-sm text-amber-800">Your transporter application is pending admin review. You'll be able to accept jobs once approved.</p>
          </div>
        </div>
      )}

      {transporter.verification_status === 'approved' && (
        <div className="rounded-lg border border-green-200 bg-green-50 p-4">
          <div className="flex items-center gap-2">
            <ShieldCheck className="h-5 w-5 text-green-600" />
            <p className="text-sm text-green-800">Your transporter account is approved. You can now accept delivery jobs.</p>
          </div>
        </div>
      )}

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard label="Available Jobs" value={availableJobs.length} icon={<Package className="h-5 w-5" />} />
        <StatCard label="Active Jobs" value={activeJobs.length} icon={<Truck className="h-5 w-5" />} />
        <StatCard label="Completed Jobs" value={completedJobs.length} icon={<CheckCircle2 className="h-5 w-5" />} />
        <StatCard label="Earnings" value={formatCurrency(earnings)} icon={<Truck className="h-5 w-5" />} />
      </div>

      <div>
        <h2 className="mb-4 text-lg font-semibold text-slate-900">Recent Delivery Jobs</h2>
        {deliveries.length === 0 ? (
          <EmptyState icon={<PackageX className="h-8 w-8" />} title="No delivery jobs available" description="When orders are ready for delivery, jobs will appear here for you to accept." />
        ) : (
          <div className="space-y-3">
            {deliveries.slice(0, 5).map((d) => (
              <Link key={d.id} to="/transporter/jobs" className="card flex items-center justify-between hover:border-slate-300 transition-colors">
                <div>
                  <p className="font-medium text-slate-900">{d.material_description ?? 'Delivery job'}</p>
                  <p className="text-sm text-slate-500">{d.pickup_address ?? 'Pickup'} → {d.delivery_address ?? 'Delivery'}</p>
                </div>
                <div className="flex items-center gap-3">
                  <span className="font-semibold text-slate-900">{formatCurrency(d.delivery_charge)}</span>
                  <Badge label={DELIVERY_STATUS_LABELS[d.status]} className={DELIVERY_STATUS_COLORS[d.status]} />
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
