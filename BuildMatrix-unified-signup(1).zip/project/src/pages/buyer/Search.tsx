import Marketplace from '@/pages/Marketplace';

export default function BuyerSearch() {
  return <Marketplace />;
}
