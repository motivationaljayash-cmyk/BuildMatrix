import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import type { Address } from '@/types';
import { EmptyState } from '@/components/EmptyState';
import { MapPin, Plus, Trash2, Pencil, X } from 'lucide-react';

export default function BuyerAddresses() {
  const { user } = useAuth();
  const [addresses, setAddresses] = useState<Address[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Address | null>(null);
  const [form, setForm] = useState({ recipient_name: '', phone: '', address_line1: '', address_line2: '', city: '', state: '', pin_code: '', label: '', is_default: false });

  useEffect(() => {
    if (!user) return;
    const fetchAddresses = async () => {
      const { data } = await supabase.from('addresses').select('*').eq('user_id', user.id).order('is_default', { ascending: false });
      setAddresses((data as Address[]) ?? []);
      setLoading(false);
    };
    fetchAddresses();
  }, [user]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    if (editing) {
      await supabase.from('addresses').update({ ...form }).eq('id', editing.id);
    } else {
      await supabase.from('addresses').insert({ ...form, user_id: user.id });
    }
    setShowForm(false);
    setEditing(null);
    setForm({ recipient_name: '', phone: '', address_line1: '', address_line2: '', city: '', state: '', pin_code: '', label: '', is_default: false });
    const { data } = await supabase.from('addresses').select('*').eq('user_id', user.id).order('is_default', { ascending: false });
    setAddresses((data as Address[]) ?? []);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this address?')) return;
    await supabase.from('addresses').delete().eq('id', id);
    setAddresses((prev) => prev.filter((a) => a.id !== id));
  };

  const handleEdit = (addr: Address) => {
    setEditing(addr);
    setForm({ recipient_name: addr.recipient_name, phone: addr.phone, address_line1: addr.address_line1, address_line2: addr.address_line2 ?? '', city: addr.city, state: addr.state, pin_code: addr.pin_code, label: addr.label ?? '', is_default: addr.is_default });
    setShowForm(true);
  };

  if (loading) return <div className="flex justify-center py-20"><div className="h-8 w-8 animate-spin rounded-full border-2 border-slate-300 border-t-slate-900" /></div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-slate-900">Delivery Addresses</h1>
        <button onClick={() => { setShowForm(!showForm); setEditing(null); setForm({ recipient_name: '', phone: '', address_line1: '', address_line2: '', city: '', state: '', pin_code: '', label: '', is_default: false }); }} className="btn-primary">
          <Plus className="h-4 w-4" /> Add Address
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="card space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-slate-900">{editing ? 'Edit Address' : 'New Address'}</h3>
            <button type="button" onClick={() => setShowForm(false)}><X className="h-4 w-4 text-slate-400" /></button>
          </div>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div><label className="label">Label</label><input value={form.label} onChange={(e) => setForm({ ...form, label: e.target.value })} className="input" placeholder="Home, Office..." /></div>
            <div><label className="label">Recipient Name</label><input required value={form.recipient_name} onChange={(e) => setForm({ ...form, recipient_name: e.target.value })} className="input" /></div>
            <div><label className="label">Phone</label><input required value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className="input" /></div>
            <div><label className="label">Address Line 1</label><input required value={form.address_line1} onChange={(e) => setForm({ ...form, address_line1: e.target.value })} className="input" /></div>
            <div><label className="label">Address Line 2</label><input value={form.address_line2} onChange={(e) => setForm({ ...form, address_line2: e.target.value })} className="input" /></div>
            <div><label className="label">City</label><input required value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} className="input" /></div>
            <div><label className="label">State</label><input required value={form.state} onChange={(e) => setForm({ ...form, state: e.target.value })} className="input" /></div>
            <div><label className="label">PIN Code</label><input required value={form.pin_code} onChange={(e) => setForm({ ...form, pin_code: e.target.value })} className="input" /></div>
          </div>
          <label className="flex items-center gap-2 text-sm text-slate-700">
            <input type="checkbox" checked={form.is_default} onChange={(e) => setForm({ ...form, is_default: e.target.checked })} />
            Set as default address
          </label>
          <button type="submit" className="btn-primary">{editing ? 'Update Address' : 'Save Address'}</button>
        </form>
      )}

      {addresses.length === 0 && !showForm ? (
        <EmptyState icon={<MapPin className="h-8 w-8" />} title="No addresses added" description="Add a delivery address to place orders." />
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          {addresses.map((addr) => (
            <div key={addr.id} className="card">
              <div className="flex items-start justify-between">
                <div>
                  {addr.label && <span className="text-xs font-medium text-slate-500">{addr.label}</span>}
                  <p className="font-medium text-slate-900">{addr.recipient_name}</p>
                  <p className="text-sm text-slate-600">{addr.phone}</p>
                  <p className="mt-1 text-sm text-slate-600">{addr.address_line1}{addr.address_line2 ? `, ${addr.address_line2}` : ''}</p>
                  <p className="text-sm text-slate-600">{addr.city}, {addr.state} {addr.pin_code}</p>
                  {addr.is_default && <span className="mt-2 inline-block rounded-full bg-green-100 px-2 py-0.5 text-xs font-medium text-green-800">Default</span>}
                </div>
                <div className="flex gap-1">
                  <button onClick={() => handleEdit(addr)} className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-100"><Pencil className="h-4 w-4" /></button>
                  <button onClick={() => handleDelete(addr.id)} className="rounded-lg p-1.5 text-red-500 hover:bg-red-50"><Trash2 className="h-4 w-4" /></button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
