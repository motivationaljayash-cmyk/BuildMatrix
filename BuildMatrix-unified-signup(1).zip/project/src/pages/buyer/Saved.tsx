import { Link } from 'react-router-dom';
import { EmptyState } from '@/components/EmptyState';
import { Heart } from 'lucide-react';

export default function BuyerSaved() {
  return (
    <EmptyState
      icon={<Heart className="h-8 w-8" />}
      title="No saved products yet"
      description="Save products you're interested in to find them quickly later."
      action={<Link to="/marketplace" className="btn-primary">Browse Marketplace</Link>}
    />
  );
}
