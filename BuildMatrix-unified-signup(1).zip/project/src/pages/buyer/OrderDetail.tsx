import { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import type { Order, Payment, PlatformSettings } from '@/types';
import { Badge, EmptyState } from '@/components/Layout';
import { ORDER_STATUS_LABELS, ORDER_STATUS_COLORS, PAYMENT_STATUS_LABELS, PAYMENT_STATUS_COLORS, formatCurrency, formatShortDate } from '@/lib/utils';
import { paymentService } from '@/lib/paymentService';
import { PackageX, Copy, Upload, Check, Truck, ArrowLeft, ExternalLink, Image as ImageIcon, X } from 'lucide-react';

export default function BuyerOrderDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [order, setOrder] = useState<Order | null>(null);
  const [settings, setSettings] = useState<PlatformSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(false);
  const [uploadingProof, setUploadingProof] = useState(false);
  const [transactionRef, setTransactionRef] = useState('');
  const [screenshotUrl, setScreenshotUrl] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      if (!id || !user) return;
      const [{ data: orderData }, { data: settingsData }] = await Promise.all([
        supabase.from('orders').select('*, order_items(*), seller:seller_profiles(*), delivery_address:addresses(*), payments(*, payment_proofs(*))').eq('id', id).maybeSingle(),
        supabase.from('platform_settings').select('*').eq('id', 1).maybeSingle(),
      ]);
      setOrder(orderData as Order | null);
      setSettings(settingsData as PlatformSettings | null);
      setLoading(false);
    };
    fetchData();
  }, [id, user]);

  const payment = order?.payments?.[0] as Payment | undefined;

  const handleCopyUpi = () => {
    if (settings?.upi_id) {
      navigator.clipboard.writeText(settings.upi_id);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleUploadProof = async () => {
    if (!order || !payment || !user) return;
    if (!screenshotUrl) {
      alert('Please provide a screenshot URL.');
      return;
    }
    setUploadingProof(true);
    try {
      await supabase.from('payment_proofs').insert({
        payment_id: payment.id,
        screenshot_url: screenshotUrl,
        transaction_reference: transactionRef,
      });
      await supabase.from('payments').update({ status: 'payment_submitted' }).eq('id', payment.id);
      await supabase.from('orders').update({ status: 'payment_submitted' }).eq('id', order.id);

      const { data: adminProfiles } = await supabase.from('profiles').select('id').eq('role', 'admin');
      if (adminProfiles) {
        for (const admin of adminProfiles) {
          await supabase.from('notifications').insert({
            user_id: admin.id,
            title: 'Payment Verification Required',
            message: `Order #${order.id.slice(0, 8)} payment proof submitted. Please verify.`,
            type: 'payment',
            link: '/admin/payments',
          });
        }
      }

      setTransactionRef('');
      setScreenshotUrl('');
      const { data: updatedOrder } = await supabase.from('orders').select('*, order_items(*), payments(*, payment_proofs(*))').eq('id', order.id).maybeSingle();
      setOrder(updatedOrder as Order | null);
    } catch (err) {
      alert('Failed to submit payment proof.');
    }
    setUploadingProof(false);
  };

  const handleCancelOrder = async () => {
    if (!order || !user) return;
    if (!confirm('Are you sure you want to cancel this order?')) return;
    await supabase.from('orders').update({ status: 'cancelled' }).eq('id', order.id);
    navigate('/buyer/orders');
  };

  const handleRequestDelivery = async () => {
    if (!order || !user) return;
    const addr = order.delivery_address;
    const pickupAddr = order.seller ? `${order.seller.business_address}, ${order.seller.city}, ${order.seller.state} ${order.seller.pin_code}` : '';
    const deliveryAddr = addr ? `${addr.address_line1}, ${addr.city}, ${addr.state} ${addr.pin_code}` : '';
    const materialDesc = order.order_items?.map((i) => `${i.product_name} x${i.quantity}`).join(', ') ?? '';
    await supabase.from('deliveries').insert({
      order_id: order.id,
      pickup_address: pickupAddr,
      delivery_address: deliveryAddr,
      material_description: materialDesc,
      approximate_weight: '',
      required_vehicle_capacity: '',
      preferred_delivery_time: '',
      delivery_charge: order.delivery_charge,
      status: 'available',
    });
    await supabase.from('orders').update({ status: 'transport_assigned' }).eq('id', order.id);
    alert('Delivery request created. Transporters will be able to accept this job.');
    const { data: updatedOrder } = await supabase.from('orders').select('*, order_items(*), payments(*, payment_proofs(*))').eq('id', order.id).maybeSingle();
    setOrder(updatedOrder as Order | null);
  };

  if (loading) return <div className="flex justify-center py-20"><div className="h-8 w-8 animate-spin rounded-full border-2 border-slate-300 border-t-slate-900" /></div>;
  if (!order) return <EmptyState icon={<PackageX className="h-8 w-8" />} title="Order not found" action={<Link to="/buyer/orders" className="btn-primary">Back to Orders</Link>} />;

  const upiId = settings?.upi_id ?? '';
  const payeeName = settings?.platform_name ?? 'BuildMatrix';
  const paymentDetails = upiId ? paymentService.generatePaymentDetails(order.final_total, upiId, payeeName) : null;

  const orderTimeline = [
    'pending_payment', 'payment_submitted', 'payment_verification', 'confirmed',
    'seller_accepted', 'processing', 'ready_for_pickup', 'transport_assigned',
    'out_for_delivery', 'delivered', 'completed'
  ];
  const currentStepIndex = orderTimeline.indexOf(order.status);

  const canCancel = ['pending_payment', 'payment_submitted', 'payment_verification'].includes(order.status);
  const canRequestDelivery = order.status === 'seller_accepted' || order.status === 'ready_for_pickup';

  return (
    <div className="space-y-6">
      <Link to="/buyer/orders" className="inline-flex items-center gap-1 text-sm text-slate-600 hover:text-slate-900">
        <ArrowLeft className="h-4 w-4" /> Back to orders
      </Link>

      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Order #{order.id.slice(0, 8)}</h1>
          <p className="text-sm text-slate-500">Placed on {formatShortDate(order.created_at)}</p>
        </div>
        <Badge label={ORDER_STATUS_LABELS[order.status] ?? order.status} className={ORDER_STATUS_COLORS[order.status] ?? ''} />
      </div>

      {/* Timeline */}
      {order.status !== 'cancelled' && order.status !== 'refunded' && order.status !== 'disputed' && (
        <div className="card">
          <h3 className="mb-4 font-semibold text-slate-900">Order Timeline</h3>
          <div className="flex flex-wrap gap-2">
            {orderTimeline.map((step, idx) => (
              <div key={step} className="flex items-center gap-2">
                <div className={`flex h-7 w-7 items-center justify-center rounded-full text-xs font-bold ${idx <= currentStepIndex ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-400'}`}>
                  {idx <= currentStepIndex ? <Check className="h-3.5 w-3.5" /> : idx + 1}
                </div>
                <span className={`text-xs ${idx <= currentStepIndex ? 'font-medium text-slate-900' : 'text-slate-400'}`}>
                  {ORDER_STATUS_LABELS[step] ?? step}
                </span>
                {idx < orderTimeline.length - 1 && <div className={`h-0.5 w-4 ${idx < currentStepIndex ? 'bg-slate-900' : 'bg-slate-200'}`} />}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Order Items */}
      <div className="card">
        <h3 className="mb-4 font-semibold text-slate-900">Items</h3>
        <div className="space-y-3">
          {order.order_items?.map((item) => (
            <div key={item.id} className="flex items-center justify-between border-b border-slate-100 pb-3 last:border-0">
              <div>
                <p className="font-medium text-slate-900">{item.product_name}</p>
                <p className="text-sm text-slate-500">{item.quantity} {item.unit} × {formatCurrency(item.unit_price)}</p>
              </div>
              <span className="font-semibold text-slate-900">{formatCurrency(item.subtotal)}</span>
            </div>
          ))}
        </div>
        <div className="mt-4 space-y-2 text-sm">
          <div className="flex justify-between"><span className="text-slate-600">Material Subtotal</span><span className="font-medium">{formatCurrency(order.material_subtotal)}</span></div>
          <div className="flex justify-between"><span className="text-slate-600">Delivery Charge</span><span className="font-medium">{formatCurrency(order.delivery_charge)}</span></div>
          <div className="flex justify-between"><span className="text-slate-600">Platform Fee ({order.platform_fee_percentage}%)</span><span className="font-medium">{formatCurrency(order.platform_fee_amount)}</span></div>
          {order.other_charges > 0 && <div className="flex justify-between"><span className="text-slate-600">Other Charges</span><span className="font-medium">{formatCurrency(order.other_charges)}</span></div>}
          <div className="border-t border-slate-200 pt-2 flex justify-between"><span className="font-semibold">Total</span><span className="font-bold text-lg">{formatCurrency(order.final_total)}</span></div>
        </div>
      </div>

      {/* Payment Section */}
      {payment && (
        <div className="card">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-slate-900">Payment</h3>
            <Badge label={PAYMENT_STATUS_LABELS[payment.status] ?? payment.status} className={PAYMENT_STATUS_COLORS[payment.status] ?? ''} />
          </div>

          {payment.status === 'unpaid' && paymentDetails && (
            <div className="space-y-4">
              <div className="rounded-lg bg-slate-50 p-4 text-center">
                <p className="text-sm text-slate-600">Amount to Pay</p>
                <p className="text-3xl font-bold text-slate-900">{formatCurrency(order.final_total)}</p>
              </div>
              <div className="flex flex-col items-center gap-3">
                <img src={paymentDetails.qrUrl} alt="UPI QR Code" className="h-48 w-48 rounded-lg border border-slate-200" />
                <div className="flex items-center gap-2">
                  <code className="rounded-lg bg-slate-100 px-3 py-2 text-sm font-mono">{upiId}</code>
                  <button onClick={handleCopyUpi} className="rounded-lg border border-slate-300 p-2 hover:bg-slate-50"><Copy className="h-4 w-4" /></button>
                  {copied && <span className="text-xs text-green-600">Copied!</span>}
                </div>
                <a href={paymentDetails.upiLink} className="btn-secondary"><ExternalLink className="h-4 w-4" /> Open UPI App</a>
              </div>
              <p className="text-sm text-slate-600 text-center">{paymentDetails.instructions}</p>

              <div className="border-t border-slate-200 pt-4 space-y-3">
                <h4 className="font-medium text-slate-900">Submit Payment Proof</h4>
                <div>
                  <label className="label">Transaction / Reference ID</label>
                  <input type="text" value={transactionRef} onChange={(e) => setTransactionRef(e.target.value)} className="input" placeholder="UPI transaction reference" />
                </div>
                <div>
                  <label className="label">Payment Screenshot URL</label>
                  <input type="url" value={screenshotUrl} onChange={(e) => setScreenshotUrl(e.target.value)} className="input" placeholder="https://...screenshot.png" />
                </div>
                <button onClick={handleUploadProof} disabled={uploadingProof} className="btn-primary w-full">
                  <Upload className="h-4 w-4" /> {uploadingProof ? 'Submitting...' : 'Submit Payment Proof'}
                </button>
              </div>
            </div>
          )}

          {payment.status === 'payment_submitted' && (
            <div className="rounded-lg bg-blue-50 border border-blue-200 p-4">
              <p className="text-sm text-blue-800">Your payment proof has been submitted and is awaiting admin verification. You'll be notified once verified.</p>
            </div>
          )}

          {payment.status === 'verified' && (
            <div className="rounded-lg bg-green-50 border border-green-200 p-4">
              <p className="text-sm text-green-800">Your payment has been verified. The seller will process your order shortly.</p>
            </div>
          )}

          {payment.status === 'rejected' && (
            <div className="rounded-lg bg-red-50 border border-red-200 p-4">
              <p className="text-sm text-red-800">Your payment was rejected. {payment.rejection_reason ?? 'Please contact support.'}</p>
            </div>
          )}
        </div>
      )}

      {/* Delivery Request */}
      {canRequestDelivery && (
        <div className="card">
          <h3 className="font-semibold text-slate-900 mb-2">Request Delivery</h3>
          <p className="text-sm text-slate-600 mb-4">Create a delivery request so transporters can pick up your order.</p>
          <button onClick={handleRequestDelivery} className="btn-primary"><Truck className="h-4 w-4" /> Request Delivery</button>
        </div>
      )}

      {/* Actions */}
      {canCancel && (
        <button onClick={handleCancelOrder} className="btn-danger w-full"><X className="h-4 w-4" /> Cancel Order</button>
      )}
    </div>
  );
}
