import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import type { Cart, Product, Address, PlatformSettings } from '@/types';
import { formatCurrency, calculatePlatformFee } from '@/lib/utils';
import { EmptyState } from '@/components/EmptyState';
import { ShoppingCart, Trash2, Minus, Plus, MapPin, ArrowRight, Package } from 'lucide-react';

export default function BuyerCart() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [cart, setCart] = useState<Cart | null>(null);
  const [addresses, setAddresses] = useState<Address[]>([]);
  const [selectedAddress, setSelectedAddress] = useState<string>('');
  const [settings, setSettings] = useState<PlatformSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [placingOrder, setPlacingOrder] = useState(false);
  const [deliveryCharge, setDeliveryCharge] = useState(0);

  useEffect(() => {
    if (!user) return;
    const fetchCart = async () => {
      const { data: cartData } = await supabase
        .from('carts')
        .select(`*, cart_items(*, product:products(*, product_images(*)))`)
        .eq('user_id', user.id)
        .maybeSingle();
      setCart(cartData as Cart | null);

      const { data: addrData } = await supabase
        .from('addresses')
        .select('*')
        .eq('user_id', user.id)
        .order('is_default', { ascending: false });
      setAddresses((addrData as Address[]) ?? []);
      if (addrData && addrData.length > 0) setSelectedAddress((addrData as Address[])[0].id);

      const { data: settingsData } = await supabase
        .from('platform_settings')
        .select('*')
        .eq('id', 1)
        .maybeSingle();
      setSettings(settingsData as PlatformSettings | null);
      setLoading(false);
    };
    fetchCart();
  }, [user]);

  const cartItems = cart?.cart_items ?? [];
  const materialSubtotal = cartItems.reduce((sum, item) => {
    const product = item.product as Product;
    return sum + (product?.price ?? 0) * item.quantity;
  }, 0);
  const platformFeePercentage = settings?.commission_percentage ?? 4;
  const platformFee = calculatePlatformFee(materialSubtotal, platformFeePercentage);
  const total = materialSubtotal + deliveryCharge + platformFee;

  const updateQuantity = async (itemId: string, quantity: number) => {
    if (quantity < 1) return;
    await supabase.from('cart_items').update({ quantity }).eq('id', itemId);
    if (user) {
      const { data } = await supabase
        .from('carts')
        .select(`*, cart_items(*, product:products(*, product_images(*)))`)
        .eq('user_id', user.id)
        .maybeSingle();
      setCart(data as Cart | null);
    }
  };

  const removeItem = async (itemId: string) => {
    await supabase.from('cart_items').delete().eq('id', itemId);
    if (user) {
      const { data } = await supabase
        .from('carts')
        .select(`*, cart_items(*, product:products(*, product_images(*)))`)
        .eq('user_id', user.id)
        .maybeSingle();
      setCart(data as Cart | null);
    }
  };

  const placeOrder = async () => {
    if (!user || !cart || cartItems.length === 0) return;
    if (!selectedAddress) {
      alert('Please select a delivery address.');
      return;
    }
    setPlacingOrder(true);
    try {
      const { data: order, error } = await supabase
        .from('orders')
        .insert({
          buyer_id: user.id,
          seller_id: cart.seller_id,
          delivery_address_id: selectedAddress,
          material_subtotal: materialSubtotal,
          delivery_charge: deliveryCharge,
          platform_fee_percentage: platformFeePercentage,
          platform_fee_amount: platformFee,
          final_total: total,
          status: 'pending_payment',
          payment_method: 'manual_upi',
        })
        .select()
        .single();

      if (error || !order) {
        alert('Failed to place order. Please try again.');
        setPlacingOrder(false);
        return;
      }

      const orderItems = cartItems.map((item) => {
        const product = item.product as Product;
        return {
          order_id: order.id,
          product_id: item.product_id,
          product_name: product.name,
          quantity: item.quantity,
          unit_price: product.price,
          unit: product.unit,
          subtotal: product.price * item.quantity,
        };
      });
      await supabase.from('order_items').insert(orderItems);

      await supabase.from('payments').insert({
        order_id: order.id,
        buyer_id: user.id,
        payment_method: 'manual_upi',
        amount: total,
        status: 'unpaid',
      });

      await supabase.from('commissions').insert({
        order_id: order.id,
        commission_percentage: platformFeePercentage,
        commission_amount: platformFee,
        seller_settlement_amount: materialSubtotal - platformFee,
        transport_charge: deliveryCharge,
        transporter_settlement: 0,
        other_charges: 0,
        status: 'pending',
      });

      await supabase.from('notifications').insert({
        user_id: user.id,
        title: 'Order Placed',
        message: `Your order #${order.id.slice(0, 8)} has been placed. Please complete the payment.`,
        type: 'order',
        link: `/buyer/orders/${order.id}`,
      });

      if (cart.seller_id) {
        const { data: sellerProfile } = await supabase
          .from('seller_profiles')
          .select('user_id')
          .eq('id', cart.seller_id)
          .maybeSingle();
        if (sellerProfile) {
          await supabase.from('notifications').insert({
            user_id: (sellerProfile as { user_id: string }).user_id,
            title: 'New Order Received',
            message: `You received a new order #${order.id.slice(0, 8)}.`,
            type: 'order',
            link: '/seller/orders',
          });
        }
      }

      await supabase.from('cart_items').delete().in('id', cartItems.map((i) => i.id));
      await supabase.from('carts').delete().eq('id', cart.id);

      navigate(`/buyer/orders/${order.id}`);
    } catch (err) {
      alert('Failed to place order. Please try again.');
    }
    setPlacingOrder(false);
  };

  if (loading) {
    return <div className="flex justify-center py-20"><div className="h-8 w-8 animate-spin rounded-full border-2 border-slate-300 border-t-slate-900" /></div>;
  }

  if (!cart || cartItems.length === 0) {
    return (
      <EmptyState
        icon={<ShoppingCart className="h-8 w-8" />}
        title="Your cart is empty"
        description="Browse the marketplace and add construction materials to your cart."
        action={<Link to="/marketplace" className="btn-primary">Browse Marketplace</Link>}
      />
    );
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-slate-900">Your Cart</h1>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 space-y-3">
          {cartItems.map((item) => {
            const product = item.product as Product;
            const img = product.product_images?.[0]?.image_url;
            return (
              <div key={item.id} className="card flex items-center gap-4">
                <div className="h-20 w-20 shrink-0 overflow-hidden rounded-lg bg-slate-100">
                  {img ? <img src={img} alt={product.name} className="h-full w-full object-cover" /> : <div className="flex h-full w-full items-center justify-center"><Package className="h-8 w-8 text-slate-300" /></div>}
                </div>
                <div className="flex-1 min-w-0">
                  <Link to={`/product/${product.id}`} className="font-medium text-slate-900 hover:underline">{product.name}</Link>
                  <p className="text-sm text-slate-500">{formatCurrency(product.price)} / {product.unit}</p>
                  <p className="text-sm text-slate-600">Subtotal: {formatCurrency(product.price * item.quantity)}</p>
                </div>
                <div className="flex items-center gap-2">
                  <button onClick={() => updateQuantity(item.id, item.quantity - 1)} className="rounded-lg border border-slate-300 p-1.5 hover:bg-slate-50"><Minus className="h-3.5 w-3.5" /></button>
                  <span className="w-10 text-center text-sm font-medium">{item.quantity}</span>
                  <button onClick={() => updateQuantity(item.id, Math.min(item.quantity + 1, product.stock_quantity))} className="rounded-lg border border-slate-300 p-1.5 hover:bg-slate-50"><Plus className="h-3.5 w-3.5" /></button>
                  <button onClick={() => removeItem(item.id)} className="ml-2 rounded-lg p-1.5 text-red-500 hover:bg-red-50"><Trash2 className="h-4 w-4" /></button>
                </div>
              </div>
            );
          })}
        </div>

        <div className="space-y-4">
          <div className="card">
            <h3 className="font-semibold text-slate-900">Delivery Address</h3>
            {addresses.length === 0 ? (
              <div className="mt-3">
                <p className="text-sm text-slate-500">No addresses added yet.</p>
                <Link to="/buyer/addresses" className="mt-2 inline-flex items-center gap-1 text-sm font-medium text-slate-900 hover:underline">
                  <MapPin className="h-4 w-4" /> Add an address
                </Link>
              </div>
            ) : (
              <select value={selectedAddress} onChange={(e) => setSelectedAddress(e.target.value)} className="input mt-3">
                {addresses.map((a) => (
                  <option key={a.id} value={a.id}>{a.label ?? a.recipient_name} - {a.city}, {a.state}</option>
                ))}
              </select>
            )}
          </div>

          <div className="card">
            <h3 className="font-semibold text-slate-900">Delivery Charge</h3>
            <div className="mt-3 flex items-center gap-2">
              <input type="number" value={deliveryCharge} onChange={(e) => setDeliveryCharge(Math.max(0, parseFloat(e.target.value) || 0))} className="input" placeholder="0" min="0" />
              <span className="text-sm text-slate-500">INR</span>
            </div>
            <p className="mt-1 text-xs text-slate-500">Enter delivery charge quoted by seller or transporter.</p>
          </div>

          <div className="card">
            <h3 className="font-semibold text-slate-900">Order Summary</h3>
            <div className="mt-3 space-y-2 text-sm">
              <div className="flex justify-between"><span className="text-slate-600">Material Subtotal</span><span className="font-medium text-slate-900">{formatCurrency(materialSubtotal)}</span></div>
              <div className="flex justify-between"><span className="text-slate-600">Delivery Charge</span><span className="font-medium text-slate-900">{formatCurrency(deliveryCharge)}</span></div>
              <div className="flex justify-between"><span className="text-slate-600">Platform Fee ({platformFeePercentage}%)</span><span className="font-medium text-slate-900">{formatCurrency(platformFee)}</span></div>
              <div className="border-t border-slate-200 pt-2 flex justify-between"><span className="font-semibold text-slate-900">Total</span><span className="font-bold text-slate-900">{formatCurrency(total)}</span></div>
            </div>
            <button onClick={placeOrder} disabled={placingOrder || !selectedAddress} className="btn-primary mt-4 w-full">
              {placingOrder ? 'Placing Order...' : 'Place Order'}
              {!placingOrder && <ArrowRight className="h-4 w-4" />}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
