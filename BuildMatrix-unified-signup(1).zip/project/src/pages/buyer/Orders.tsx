import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import type { Order } from '@/types';
import { Badge, EmptyState } from '@/components/Layout';
import { ORDER_STATUS_LABELS, ORDER_STATUS_COLORS, formatCurrency, formatShortDate } from '@/lib/utils';
import { PackageX, Package } from 'lucide-react';

export default function BuyerOrders() {
  const { user } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    const fetchOrders = async () => {
      const { data } = await supabase
        .from('orders')
        .select('*, order_items(*)')
        .eq('buyer_id', user.id)
        .order('created_at', { ascending: false });
      setOrders((data as Order[]) ?? []);
      setLoading(false);
    };
    fetchOrders();
  }, [user]);

  if (loading) return <div className="flex justify-center py-20"><div className="h-8 w-8 animate-spin rounded-full border-2 border-slate-300 border-t-slate-900" /></div>;

  if (orders.length === 0) {
    return (
      <EmptyState
        icon={<PackageX className="h-8 w-8" />}
        title="You have no orders yet"
        description="Browse the marketplace and place your first order to see it here."
        action={<Link to="/marketplace" className="btn-primary">Browse Marketplace</Link>}
      />
    );
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-slate-900">Your Orders</h1>
      <div className="space-y-3">
        {orders.map((order) => (
          <Link key={order.id} to={`/buyer/orders/${order.id}`} className="card flex items-center justify-between hover:border-slate-300 transition-colors">
            <div>
              <p className="font-medium text-slate-900">Order #{order.id.slice(0, 8)}</p>
              <p className="text-sm text-slate-500">{formatShortDate(order.created_at)} · {order.order_items?.length ?? 0} items</p>
            </div>
            <div className="flex items-center gap-3">
              <span className="font-semibold text-slate-900">{formatCurrency(order.final_total)}</span>
              <Badge label={ORDER_STATUS_LABELS[order.status] ?? order.status} className={ORDER_STATUS_COLORS[order.status] ?? ''} />
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
