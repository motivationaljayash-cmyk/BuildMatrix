import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import type { SupportTicket } from '@/types';
import { EmptyState } from '@/components/EmptyState';
import { Badge } from '@/components/Layout';
import { TICKET_STATUS_LABELS, TICKET_STATUS_COLORS, formatShortDate } from '@/lib/utils';
import { LifeBuoy, Plus, X, MessageSquare } from 'lucide-react';

export default function BuyerSupport() {
  const { user } = useAuth();
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [subject, setSubject] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('');

  useEffect(() => {
    if (!user) return;
    const fetchTickets = async () => {
      const { data } = await supabase.from('support_tickets').select('*, support_ticket_replies(*)').eq('user_id', user.id).order('created_at', { ascending: false });
      setTickets((data as SupportTicket[]) ?? []);
      setLoading(false);
    };
    fetchTickets();
  }, [user]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    await supabase.from('support_tickets').insert({ user_id: user.id, subject, description, category });
    setSubject(''); setDescription(''); setCategory(''); setShowForm(false);
    const { data } = await supabase.from('support_tickets').select('*, support_ticket_replies(*)').eq('user_id', user.id).order('created_at', { ascending: false });
    setTickets((data as SupportTicket[]) ?? []);
  };

  if (loading) return <div className="flex justify-center py-20"><div className="h-8 w-8 animate-spin rounded-full border-2 border-slate-300 border-t-slate-900" /></div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-slate-900">Support</h1>
        <button onClick={() => setShowForm(!showForm)} className="btn-primary"><Plus className="h-4 w-4" /> New Ticket</button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="card space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-slate-900">Create Support Ticket</h3>
            <button type="button" onClick={() => setShowForm(false)}><X className="h-4 w-4 text-slate-400" /></button>
          </div>
          <div><label className="label">Subject</label><input required value={subject} onChange={(e) => setSubject(e.target.value)} className="input" /></div>
          <div><label className="label">Category</label><select value={category} onChange={(e) => setCategory(e.target.value)} className="input"><option value="">Select...</option><option value="order">Order Issue</option><option value="payment">Payment Issue</option><option value="delivery">Delivery Issue</option><option value="product">Product Issue</option><option value="account">Account Issue</option><option value="other">Other</option></select></div>
          <div><label className="label">Description</label><textarea required value={description} onChange={(e) => setDescription(e.target.value)} className="input min-h-[100px]" /></div>
          <button type="submit" className="btn-primary">Submit Ticket</button>
        </form>
      )}

      {tickets.length === 0 && !showForm ? (
        <EmptyState icon={<LifeBuoy className="h-8 w-8" />} title="No support tickets" description="Need help with something? Create a support ticket and our team will assist you." />
      ) : (
        <div className="space-y-3">
          {tickets.map((t) => (
            <div key={t.id} className="card">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium text-slate-900">{t.subject}</p>
                  <p className="text-sm text-slate-500">{formatShortDate(t.created_at)} · {t.category}</p>
                </div>
                <Badge label={TICKET_STATUS_LABELS[t.status] ?? t.status} className={TICKET_STATUS_COLORS[t.status] ?? ''} />
              </div>
              <p className="mt-2 text-sm text-slate-600">{t.description}</p>
              {t.support_ticket_replies && t.support_ticket_replies.length > 0 && (
                <div className="mt-3 border-t border-slate-100 pt-3">
                  <p className="text-xs font-medium text-slate-500 mb-2">{t.support_ticket_replies.length} replies</p>
                  {t.support_ticket_replies.map((r) => (
                    <div key={r.id} className="mb-2 flex gap-2">
                      <MessageSquare className="h-4 w-4 text-slate-400 mt-0.5 shrink-0" />
                      <p className="text-sm text-slate-600">{r.message}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
