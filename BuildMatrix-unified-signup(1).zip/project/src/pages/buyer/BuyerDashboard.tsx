import { Link } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { StatCard, Badge } from '@/components/Layout';
import { EmptyState } from '@/components/EmptyState';
import { ShoppingCart, Package, MapPin, Search, Heart, ArrowRight, PackageX } from 'lucide-react';
import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import type { Order } from '@/types';
import { ORDER_STATUS_LABELS, ORDER_STATUS_COLORS, formatCurrency, formatShortDate } from '@/lib/utils';

export default function BuyerDashboard() {
  const { user } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    const fetchOrders = async () => {
      const { data } = await supabase
        .from('orders')
        .select('*, order_items(*)')
        .eq('buyer_id', user.id)
        .order('created_at', { ascending: false })
        .limit(5);
      setOrders((data as Order[]) ?? []);
      setLoading(false);
    };
    fetchOrders();
  }, [user]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Welcome back</h1>
        <p className="mt-1 text-sm text-slate-600">Find construction materials and manage your orders</p>
      </div>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard label="Active Orders" value={orders.filter(o => !['completed', 'cancelled', 'refunded'].includes(o.status)).length} icon={<Package className="h-5 w-5" />} />
        <StatCard label="Completed Orders" value={orders.filter(o => o.status === 'completed').length} icon={<ShoppingCart className="h-5 w-5" />} />
        <StatCard label="Total Orders" value={orders.length} icon={<Package className="h-5 w-5" />} />
        <StatCard label="Total Spent" value={formatCurrency(orders.reduce((sum, o) => sum + o.final_total, 0))} icon={<ShoppingCart className="h-5 w-5" />} />
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <Link to="/buyer/search" className="card hover:border-slate-300 hover:shadow-md transition-all">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-slate-100"><Search className="h-5 w-5 text-slate-700" /></div>
            <div><p className="font-semibold text-slate-900">Search Products</p><p className="text-sm text-slate-500">Find materials</p></div>
          </div>
        </Link>
        <Link to="/buyer/cart" className="card hover:border-slate-300 hover:shadow-md transition-all">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-slate-100"><ShoppingCart className="h-5 w-5 text-slate-700" /></div>
            <div><p className="font-semibold text-slate-900">View Cart</p><p className="text-sm text-slate-500">Checkout items</p></div>
          </div>
        </Link>
        <Link to="/buyer/addresses" className="card hover:border-slate-300 hover:shadow-md transition-all">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-slate-100"><MapPin className="h-5 w-5 text-slate-700" /></div>
            <div><p className="font-semibold text-slate-900">Addresses</p><p className="text-sm text-slate-500">Manage delivery locations</p></div>
          </div>
        </Link>
      </div>

      <div>
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg font-semibold text-slate-900">Recent Orders</h2>
          <Link to="/buyer/orders" className="text-sm font-medium text-slate-600 hover:text-slate-900">View all</Link>
        </div>
        {loading ? (
          <div className="flex justify-center py-10"><div className="h-6 w-6 animate-spin rounded-full border-2 border-slate-300 border-t-slate-900" /></div>
        ) : orders.length === 0 ? (
          <EmptyState
            icon={<PackageX className="h-8 w-8" />}
            title="You have no orders yet"
            description="Browse the marketplace and add materials to your cart to place your first order."
            action={<Link to="/marketplace" className="btn-primary">Browse Marketplace</Link>}
          />
        ) : (
          <div className="space-y-3">
            {orders.map((order) => (
              <Link key={order.id} to={`/buyer/orders/${order.id}`} className="card flex items-center justify-between hover:border-slate-300 transition-colors">
                <div>
                  <p className="font-medium text-slate-900">Order #{order.id.slice(0, 8)}</p>
                  <p className="text-sm text-slate-500">{formatShortDate(order.created_at)} · {order.order_items?.length ?? 0} items</p>
                </div>
                <div className="flex items-center gap-3">
                  <span className="font-semibold text-slate-900">{formatCurrency(order.final_total)}</span>
                  <Badge label={ORDER_STATUS_LABELS[order.status] ?? order.status} className={ORDER_STATUS_COLORS[order.status] ?? ''} />
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
