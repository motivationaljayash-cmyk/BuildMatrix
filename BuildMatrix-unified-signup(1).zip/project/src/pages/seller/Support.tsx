import BuyerSupport from '@/pages/buyer/Support';
export default function SellerSupport() { return <BuyerSupport />; }
