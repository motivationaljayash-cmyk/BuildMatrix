import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import type { SellerProfile, Order, Commission } from '@/types';
import { StatCard, EmptyState } from '@/components/Layout';
import { formatCurrency } from '@/lib/utils';
import { Banknote, Package } from 'lucide-react';

export default function SellerEarnings() {
  const { user } = useAuth();
  const [seller, setSeller] = useState<SellerProfile | null>(null);
  const [orders, setOrders] = useState<Order[]>([]);
  const [commissions, setCommissions] = useState<Commission[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    const fetchData = async () => {
      const { data: sellerData } = await supabase.from('seller_profiles').select('*').eq('user_id', user.id).maybeSingle();
      setSeller(sellerData as SellerProfile | null);
      if (sellerData) {
        const [{ data: ordersData }, { data: commissionData }] = await Promise.all([
          supabase.from('orders').select('*').eq('seller_id', (sellerData as SellerProfile).id).in('status', ['completed', 'delivered']).order('created_at', { ascending: false }),
          supabase.from('commissions').select('*').in('order_id', ((await supabase.from('orders').select('id').eq('seller_id', (sellerData as SellerProfile).id)).data ?? []).map((o: { id: string }) => o.id)),
        ]);
        setOrders((ordersData as Order[]) ?? []);
        setCommissions((commissionData as Commission[]) ?? []);
      }
      setLoading(false);
    };
    fetchData();
  }, [user]);

  if (loading) return <div className="flex justify-center py-20"><div className="h-8 w-8 animate-spin rounded-full border-2 border-slate-300 border-t-slate-900" /></div>;
  if (!seller) return <EmptyState icon={<Banknote className="h-8 w-8" />} title="No seller profile found" />;

  const grossSales = orders.reduce((sum, o) => sum + o.material_subtotal, 0);
  const platformFees = commissions.reduce((sum, c) => sum + c.commission_amount, 0);
  const netSettlement = grossSales - platformFees;

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-slate-900">Earnings</h1>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <StatCard label="Gross Sales" value={formatCurrency(grossSales)} icon={<Banknote className="h-5 w-5" />} />
        <StatCard label="Platform Fees" value={formatCurrency(platformFees)} icon={<Banknote className="h-5 w-5" />} />
        <StatCard label="Net Settlement" value={formatCurrency(netSettlement)} icon={<Banknote className="h-5 w-5" />} />
      </div>

      {orders.length === 0 ? (
        <EmptyState icon={<Package className="h-8 w-8" />} title="No earnings yet" description="Your completed order earnings will appear here." />
      ) : (
        <div className="space-y-3">
          {orders.map((order) => {
            const commission = commissions.find((c) => c.order_id === order.id);
            return (
              <div key={order.id} className="card">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium text-slate-900">Order #{order.id.slice(0, 8)}</p>
                    <p className="text-sm text-slate-500">Material: {formatCurrency(order.material_subtotal)} · Fee: {formatCurrency(commission?.commission_amount ?? 0)}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-slate-900">{formatCurrency(commission?.seller_settlement_amount ?? order.material_subtotal - order.platform_fee_amount)}</p>
                    <p className="text-xs text-slate-500">Net Settlement</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
