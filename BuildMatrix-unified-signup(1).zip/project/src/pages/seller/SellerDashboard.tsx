import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import type { SellerProfile, Order, Product } from '@/types';
import { StatCard, Badge } from '@/components/Layout';
import { EmptyState } from '@/components/EmptyState';
import { formatCurrency, formatShortDate, ORDER_STATUS_LABELS, ORDER_STATUS_COLORS, SELLER_STATUS_LABELS, SELLER_STATUS_COLORS } from '@/lib/utils';
import { Package, Boxes, Banknote, Store, Plus, AlertCircle, ArrowRight, ShieldCheck, MessageSquare, RefreshCw } from 'lucide-react';

export default function SellerDashboard() {
  const { user } = useAuth();
  const [seller, setSeller] = useState<SellerProfile | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [resubmitting, setResubmitting] = useState(false);
  const [resubmitted, setResubmitted] = useState(false);

  useEffect(() => {
    if (!user) return;
    const fetchData = async () => {
      const { data: sellerData } = await supabase.from('seller_profiles').select('*').eq('user_id', user.id).maybeSingle();
      setSeller(sellerData as SellerProfile | null);
      if (sellerData) {
        const [{ data: productsData }, { data: ordersData }] = await Promise.all([
          supabase.from('products').select('*').eq('seller_id', (sellerData as SellerProfile).id),
          supabase.from('orders').select('*, order_items(*)').eq('seller_id', (sellerData as SellerProfile).id).order('created_at', { ascending: false }).limit(5),
        ]);
        setProducts((productsData as Product[]) ?? []);
        setOrders((ordersData as Order[]) ?? []);
      }
      setLoading(false);
    };
    fetchData();
  }, [user]);

  const resubmitForReview = async () => {
    if (!seller || !user) return;
    setResubmitting(true);
    await supabase.from('seller_profiles').update({
      verification_status: 'pending',
      verification_notes: null,
      info_request_message: null,
    }).eq('id', seller.id);
    const { data: admins } = await supabase.from('profiles').select('id').eq('role', 'admin');
    if (admins) {
      for (const a of admins) {
        await supabase.from('notifications').insert({
          user_id: a.id,
          title: 'Seller Resubmitted Application',
          message: `${seller.business_name} has resubmitted their application after providing requested information.`,
          type: 'verification',
          link: '/admin/sellers',
        });
      }
    }
    const { data: updatedSeller } = await supabase.from('seller_profiles').select('*').eq('id', seller.id).maybeSingle();
    setSeller(updatedSeller as SellerProfile | null);
    setResubmitting(false);
    setResubmitted(true);
    setTimeout(() => setResubmitted(false), 4000);
  };

  if (loading) return <div className="flex justify-center py-20"><div className="h-8 w-8 animate-spin rounded-full border-2 border-slate-300 border-t-slate-900" /></div>;

  if (!seller) {
    return (
      <EmptyState
        icon={<Store className="h-8 w-8" />}
        title="No seller profile found"
        description="Register your business to start selling construction materials."
        action={<Link to="/seller/register" className="btn-primary">Register Now</Link>}
      />
    );
  }

  const activeProducts = products.filter(p => p.status === 'active');
  const pendingOrders = orders.filter(o => ['confirmed', 'seller_accepted', 'processing'].includes(o.status));
  const completedOrders = orders.filter(o => o.status === 'completed');
  const grossSales = completedOrders.reduce((sum, o) => sum + o.material_subtotal, 0);
  const platformFees = completedOrders.reduce((sum, o) => sum + o.platform_fee_amount, 0);
  const netSettlement = grossSales - platformFees;
  const isApproved = seller.verification_status === 'approved';

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">{seller.business_name}</h1>
          <div className="mt-1 flex items-center gap-2">
            <Badge label={SELLER_STATUS_LABELS[seller.verification_status] ?? seller.verification_status} className={SELLER_STATUS_COLORS[seller.verification_status] ?? ''} />
            <span className="text-sm text-slate-500">{seller.city}, {seller.state}</span>
          </div>
        </div>
        <Link to="/seller/products/add" className="btn-primary"><Plus className="h-4 w-4" /> Add Product</Link>
      </div>

      {seller.verification_status === 'pending' && (
        <div className="rounded-lg border border-amber-200 bg-amber-50 p-4">
          <div className="flex items-center gap-2">
            <AlertCircle className="h-5 w-5 text-amber-600" />
            <p className="text-sm text-amber-800">Your seller application is pending admin review. You can create products as drafts, but they won't be visible to buyers until you're approved.</p>
          </div>
        </div>
      )}

      {seller.verification_status === 'rejected' && (
        <div className="rounded-lg border border-red-200 bg-red-50 p-4">
          <div className="flex items-start gap-2">
            <AlertCircle className="h-5 w-5 text-red-600 mt-0.5" />
            <div>
              <p className="text-sm font-medium text-red-800">Your seller application was rejected.</p>
              {seller.rejection_reason && <p className="mt-1 text-sm text-red-700">Reason: {seller.rejection_reason}</p>}
              {seller.rejected_at && <p className="mt-1 text-xs text-red-500">Rejected on {formatShortDate(seller.rejected_at)}</p>}
              <p className="mt-2 text-sm text-red-700">You can update your profile and resubmit by editing your registration.</p>
              <Link to="/seller/register" className="mt-3 inline-flex items-center gap-1.5 rounded-lg bg-red-600 px-4 py-2 text-sm font-medium text-white hover:bg-red-700">
                <RefreshCw className="h-4 w-4" /> Update & Resubmit
              </Link>
            </div>
          </div>
        </div>
      )}

      {seller.verification_status === 'more_information_required' && (
        <div className="rounded-lg border border-blue-200 bg-blue-50 p-4">
          <div className="flex items-start gap-2">
            <MessageSquare className="h-5 w-5 text-blue-600 mt-0.5" />
            <div className="flex-1">
              <p className="text-sm font-medium text-blue-800">The admin has requested more information from you.</p>
              {seller.info_request_message && (
                <div className="mt-2 rounded-lg bg-white border border-blue-200 p-3">
                  <p className="text-xs font-medium text-blue-600">Admin's message:</p>
                  <p className="mt-1 text-sm text-slate-700">{seller.info_request_message}</p>
                </div>
              )}
              {seller.info_requested_at && <p className="mt-2 text-xs text-blue-500">Requested on {formatShortDate(seller.info_requested_at)}</p>}
              <p className="mt-3 text-sm text-blue-700">Please update your profile with the requested information, then click the button below to resubmit for review.</p>
              <div className="mt-3 flex flex-wrap gap-2">
                <Link to="/seller/register" className="inline-flex items-center gap-1.5 rounded-lg border border-blue-300 bg-white px-4 py-2 text-sm font-medium text-blue-700 hover:bg-blue-50">
                  <RefreshCw className="h-4 w-4" /> Update Profile
                </Link>
                <button onClick={resubmitForReview} disabled={resubmitting} className="inline-flex items-center gap-1.5 rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 disabled:opacity-50">
                  <RefreshCw className="h-4 w-4" /> {resubmitting ? 'Submitting...' : 'Resubmit for Review'}
                </button>
              </div>
              {resubmitted && <p className="mt-2 text-sm text-green-600">Your application has been resubmitted for admin review.</p>}
            </div>
          </div>
        </div>
      )}

      {seller.verification_status === 'suspended' && (
        <div className="rounded-lg border border-gray-300 bg-gray-50 p-4">
          <div className="flex items-center gap-2">
            <AlertCircle className="h-5 w-5 text-gray-600" />
            <p className="text-sm text-gray-800">Your seller account has been suspended. {seller.verification_notes ?? 'Please contact support.'}</p>
          </div>
        </div>
      )}

      {isApproved && (
        <div className="rounded-lg border border-green-200 bg-green-50 p-4">
          <div className="flex items-center gap-2">
            <ShieldCheck className="h-5 w-5 text-green-600" />
            <p className="text-sm text-green-800">Your seller account is verified and approved. You can add products and submit them for approval to make them visible to buyers.</p>
            {seller.approved_at && <span className="ml-auto text-xs text-green-500">Approved on {formatShortDate(seller.approved_at)}</span>}
          </div>
        </div>
      )}

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard label="Total Products" value={products.length} icon={<Boxes className="h-5 w-5" />} />
        <StatCard label="Active Products" value={activeProducts.length} icon={<Package className="h-5 w-5" />} />
        <StatCard label="Pending Orders" value={pendingOrders.length} icon={<Package className="h-5 w-5" />} />
        <StatCard label="Completed Orders" value={completedOrders.length} icon={<Package className="h-5 w-5" />} />
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <StatCard label="Gross Sales" value={formatCurrency(grossSales)} icon={<Banknote className="h-5 w-5" />} />
        <StatCard label="Platform Fees" value={formatCurrency(platformFees)} icon={<Banknote className="h-5 w-5" />} />
        <StatCard label="Net Settlement" value={formatCurrency(netSettlement)} icon={<Banknote className="h-5 w-5" />} />
      </div>

      <div>
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg font-semibold text-slate-900">Recent Orders</h2>
          <Link to="/seller/orders" className="text-sm font-medium text-slate-600 hover:text-slate-900">View all</Link>
        </div>
        {orders.length === 0 ? (
          <EmptyState icon={<Package className="h-8 w-8" />} title="No orders yet" description="When buyers place orders for your products, they'll appear here." />
        ) : (
          <div className="space-y-3">
            {orders.map((order) => (
              <Link key={order.id} to="/seller/orders" className="card flex items-center justify-between hover:border-slate-300 transition-colors">
                <div>
                  <p className="font-medium text-slate-900">Order #{order.id.slice(0, 8)}</p>
                  <p className="text-sm text-slate-500">{formatShortDate(order.created_at)} · {order.order_items?.length ?? 0} items</p>
                </div>
                <div className="flex items-center gap-3">
                  <span className="font-semibold text-slate-900">{formatCurrency(order.final_total)}</span>
                  <Badge label={ORDER_STATUS_LABELS[order.status] ?? order.status} className={ORDER_STATUS_COLORS[order.status] ?? ''} />
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
