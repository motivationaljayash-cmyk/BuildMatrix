import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import type { Product, SellerProfile } from '@/types';
import { Badge, EmptyState } from '@/components/Layout';
import { PRODUCT_STATUS_LABELS, PRODUCT_STATUS_COLORS, formatCurrency, formatShortDate } from '@/lib/utils';
import { Plus, Package, Pencil, Boxes, Store, AlertCircle, ShieldCheck } from 'lucide-react';

export default function SellerProducts() {
  const { user } = useAuth();
  const [seller, setSeller] = useState<SellerProfile | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    const fetchData = async () => {
      const { data: sellerData } = await supabase.from('seller_profiles').select('*').eq('user_id', user.id).maybeSingle();
      setSeller(sellerData as SellerProfile | null);
      if (sellerData) {
        const { data } = await supabase.from('products').select('*, category:categories(*)').eq('seller_id', (sellerData as SellerProfile).id).order('created_at', { ascending: false });
        setProducts((data as Product[]) ?? []);
      }
      setLoading(false);
    };
    fetchData();
  }, [user]);

  const submitForApproval = async (id: string) => {
    if (!seller) return;
    if (seller.verification_status !== 'approved') {
      alert('Your seller account must be approved by an admin before you can submit products for approval.');
      return;
    }
    if (!confirm('Submit this product for admin approval?')) return;
    await supabase.from('products').update({ status: 'pending_approval' }).eq('id', id);
    const { data: admins } = await supabase.from('profiles').select('id').eq('role', 'admin');
    if (admins) {
      for (const a of admins) {
        await supabase.from('notifications').insert({ user_id: a.id, title: 'New Product Pending Approval', message: `A new product from ${seller.business_name} is awaiting approval.`, type: 'product', link: '/admin/products' });
      }
    }
    const { data: productsData } = await supabase.from('products').select('*, category:categories(*)').eq('seller_id', seller.id).order('created_at', { ascending: false });
    setProducts((productsData as Product[]) ?? []);
  };

  if (loading) return <div className="flex justify-center py-20"><div className="h-8 w-8 animate-spin rounded-full border-2 border-slate-300 border-t-slate-900" /></div>;

  if (!seller) {
    return <EmptyState icon={<Store className="h-8 w-8" />} title="No seller profile found" description="Register your business first." action={<Link to="/seller/register" className="btn-primary">Register Now</Link>} />;
  }

  const isApproved = seller.verification_status === 'approved';

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-slate-900">My Products</h1>
        <Link to="/seller/products/add" className="btn-primary"><Plus className="h-4 w-4" /> Add Product</Link>
      </div>

      {!isApproved && (
        <div className="rounded-lg border border-amber-200 bg-amber-50 p-4">
          <div className="flex items-center gap-2">
            <AlertCircle className="h-5 w-5 text-amber-600" />
            <p className="text-sm text-amber-800">
              {seller.verification_status === 'more_information_required'
                ? 'The admin has requested more information. Please update your profile and resubmit before you can publish products.'
                : seller.verification_status === 'rejected'
                ? 'Your seller application was rejected. You can still create draft products, but they cannot be submitted for approval until your account is approved.'
                : 'Your seller account is pending approval. You can create draft products, but they cannot be submitted for approval until your account is approved by an admin.'}
            </p>
          </div>
        </div>
      )}

      {isApproved && (
        <div className="rounded-lg border border-green-200 bg-green-50 p-4">
          <div className="flex items-center gap-2">
            <ShieldCheck className="h-5 w-5 text-green-600" />
            <p className="text-sm text-green-800">Your seller account is approved. You can submit products for admin approval to make them visible to buyers.</p>
          </div>
        </div>
      )}

      {products.length === 0 ? (
        <EmptyState icon={<Boxes className="h-8 w-8" />} title="No products yet" description="Add your first construction material product to start selling." action={<Link to="/seller/products/add" className="btn-primary"><Plus className="h-4 w-4" /> Add Product</Link>} />
      ) : (
        <div className="space-y-3">
          {products.map((product) => (
            <div key={product.id} className="card flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="h-12 w-12 shrink-0 rounded-lg bg-slate-100 flex items-center justify-center">
                  <Package className="h-6 w-6 text-slate-400" />
                </div>
                <div>
                  <p className="font-medium text-slate-900">{product.name}</p>
                  <p className="text-sm text-slate-500">{product.category?.name ?? 'Uncategorized'} · {formatCurrency(product.price)}/{product.unit} · Stock: {product.stock_quantity}</p>
                  <p className="text-xs text-slate-400">Added {formatShortDate(product.created_at)}</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Badge label={PRODUCT_STATUS_LABELS[product.status] ?? product.status} className={PRODUCT_STATUS_COLORS[product.status] ?? ''} />
                {product.status === 'draft' && isApproved && (
                  <button onClick={() => submitForApproval(product.id)} className="btn-secondary text-xs px-3 py-1.5">Submit for Approval</button>
                )}
                {product.status === 'draft' && !isApproved && (
                  <span className="text-xs text-slate-400" title="Seller must be approved first">Approval locked</span>
                )}
                <Link to={`/seller/products/${product.id}/edit`} className="rounded-lg p-2 text-slate-500 hover:bg-slate-100"><Pencil className="h-4 w-4" /></Link>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
