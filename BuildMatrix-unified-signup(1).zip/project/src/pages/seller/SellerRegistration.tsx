import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import type { SellerProfile } from '@/types';
import { Store, Save, ArrowRight, ShieldCheck } from 'lucide-react';

export default function SellerRegistration() {
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  const [existing, setExisting] = useState<SellerProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    owner_name: '', business_name: '', phone: '', email: '', business_address: '',
    city: '', state: '', pin_code: '', gst_number: '', business_registration_info: '',
    business_description: '', bank_account_name: '', bank_account_number: '', bank_ifsc: '', bank_name: '', upi_id: '',
  });

  useEffect(() => {
    if (!user) return;
    const fetchExisting = async () => {
      const { data } = await supabase.from('seller_profiles').select('*').eq('user_id', user.id).maybeSingle();
      setExisting(data as SellerProfile | null);
      if (data) {
        const s = data as SellerProfile;
        setForm({ owner_name: s.owner_name, business_name: s.business_name, phone: s.phone, email: s.email, business_address: s.business_address, city: s.city, state: s.state, pin_code: s.pin_code, gst_number: s.gst_number ?? '', business_registration_info: s.business_registration_info ?? '', business_description: s.business_description ?? '', bank_account_name: s.bank_account_name ?? '', bank_account_number: s.bank_account_number ?? '', bank_ifsc: s.bank_ifsc ?? '', bank_name: s.bank_name ?? '', upi_id: s.upi_id ?? '' });
      } else {
        setForm(f => ({ ...f, owner_name: profile?.full_name ?? '', email: user.email ?? '', phone: profile?.phone ?? '' }));
      }
      setLoading(false);
    };
    fetchExisting();
  }, [user, profile]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setSaving(true);
    try {
      if (existing) {
        await supabase.from('seller_profiles').update({ ...form }).eq('id', existing.id);
      } else {
        const { data, error } = await supabase.from('seller_profiles').insert({ ...form, user_id: user.id }).select().single();
        if (!error && data) {
          await supabase.from('profiles').update({ role: 'seller' }).eq('id', user.id);
          const { data: admins } = await supabase.from('profiles').select('id').eq('role', 'admin');
          if (admins) {
            for (const a of admins) {
              await supabase.from('notifications').insert({ user_id: a.id, title: 'New Seller Application', message: `${form.business_name} has applied for seller verification.`, type: 'verification', link: '/admin/sellers' });
            }
          }
        }
      }
      navigate('/seller');
    } catch (err) {
      alert('Failed to save seller profile.');
    }
    setSaving(false);
  };

  if (loading) return <div className="flex justify-center py-20"><div className="h-8 w-8 animate-spin rounded-full border-2 border-slate-300 border-t-slate-900" /></div>;

  return (
    <div className="mx-auto max-w-3xl px-4 py-8">
      <div className="mb-6">
        <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-xl bg-slate-900 text-white"><Store className="h-6 w-6" /></div>
        <h1 className="text-2xl font-bold text-slate-900">Seller Application</h1>
        <p className="mt-1 text-sm text-slate-600">Your seller application is created during signup. Use this page only to review or update the information you submitted.</p>
      </div>

      {existing && (
        <div className="mb-6 rounded-lg border border-slate-200 bg-slate-50 p-4">
          <div className="flex items-center gap-2">
            <ShieldCheck className="h-5 w-5 text-slate-600" />
            <span className="font-medium text-slate-900">Application Status: </span>
            <span className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${existing.verification_status === 'approved' ? 'bg-green-100 text-green-800' : existing.verification_status === 'rejected' ? 'bg-red-100 text-red-800' : 'bg-amber-100 text-amber-800'}`}>
              {existing.verification_status.charAt(0).toUpperCase() + existing.verification_status.slice(1)}
            </span>
          </div>
          {existing.verification_notes && <p className="mt-2 text-sm text-slate-600">{existing.verification_notes}</p>}
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="card space-y-4">
          <h3 className="font-semibold text-slate-900">Business Information</h3>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div><label className="label">Owner Name</label><input required value={form.owner_name} onChange={(e) => setForm({ ...form, owner_name: e.target.value })} className="input" /></div>
            <div><label className="label">Business Name</label><input required value={form.business_name} onChange={(e) => setForm({ ...form, business_name: e.target.value })} className="input" /></div>
            <div><label className="label">Phone</label><input required value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className="input" /></div>
            <div><label className="label">Email</label><input required type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="input" /></div>
          </div>
        </div>

        <div className="card space-y-4">
          <h3 className="font-semibold text-slate-900">Business Address</h3>
          <div><label className="label">Business Address</label><input required value={form.business_address} onChange={(e) => setForm({ ...form, business_address: e.target.value })} className="input" /></div>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <div><label className="label">City</label><input required value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} className="input" /></div>
            <div><label className="label">State</label><input required value={form.state} onChange={(e) => setForm({ ...form, state: e.target.value })} className="input" /></div>
            <div><label className="label">PIN Code</label><input required value={form.pin_code} onChange={(e) => setForm({ ...form, pin_code: e.target.value })} className="input" /></div>
          </div>
        </div>

        <div className="card space-y-4">
          <h3 className="font-semibold text-slate-900">Business Details</h3>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div><label className="label">GST Number (if applicable)</label><input value={form.gst_number} onChange={(e) => setForm({ ...form, gst_number: e.target.value })} className="input" /></div>
            <div><label className="label">Business Registration Info</label><input value={form.business_registration_info} onChange={(e) => setForm({ ...form, business_registration_info: e.target.value })} className="input" /></div>
          </div>
          <div><label className="label">Business Description</label><textarea value={form.business_description} onChange={(e) => setForm({ ...form, business_description: e.target.value })} className="input min-h-[80px]" /></div>
        </div>

        <div className="card space-y-4">
          <h3 className="font-semibold text-slate-900">Bank / Payment Settlement</h3>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div><label className="label">Bank Account Name</label><input value={form.bank_account_name} onChange={(e) => setForm({ ...form, bank_account_name: e.target.value })} className="input" /></div>
            <div><label className="label">Bank Account Number</label><input value={form.bank_account_number} onChange={(e) => setForm({ ...form, bank_account_number: e.target.value })} className="input" /></div>
            <div><label className="label">Bank IFSC</label><input value={form.bank_ifsc} onChange={(e) => setForm({ ...form, bank_ifsc: e.target.value })} className="input" /></div>
            <div><label className="label">Bank Name</label><input value={form.bank_name} onChange={(e) => setForm({ ...form, bank_name: e.target.value })} className="input" /></div>
            <div><label className="label">UPI ID</label><input value={form.upi_id} onChange={(e) => setForm({ ...form, upi_id: e.target.value })} className="input" /></div>
          </div>
        </div>

        <button type="submit" disabled={saving} className="btn-primary w-full">
          <Save className="h-4 w-4" /> {saving ? 'Saving...' : existing ? 'Update Profile' : 'Submit Application'}
          {!saving && <ArrowRight className="h-4 w-4" />}
        </button>
      </form>
    </div>
  );
}
