import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import type { Category, SellerProfile, Product } from '@/types';
import { Save, ArrowLeft, Plus, X, Package } from 'lucide-react';

const UNITS = ['per bag', 'per kg', 'per tonne', 'per piece', 'per cubic foot', 'per cubic metre', 'per sq ft', 'per box', 'per litre', 'per metre', 'per set'];

export default function SellerAddProduct() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [seller, setSeller] = useState<SellerProfile | null>(null);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [imageUrls, setImageUrls] = useState<string[]>([]);
  const [imageUrl, setImageUrl] = useState('');
  const [specs, setSpecs] = useState<{ key: string; value: string }[]>([]);
  const [specKey, setSpecKey] = useState('');
  const [specValue, setSpecValue] = useState('');
  const [form, setForm] = useState({
    name: '', brand: '', description: '', price: '', unit: 'per bag', min_order_quantity: '1',
    stock_quantity: '', sku: '', delivery_radius_km: '10', is_delivery_available: true,
    estimated_delivery_days: '', category_id: '',
  });

  useEffect(() => {
    if (!user) return;
    const fetchData = async () => {
      const [{ data: sellerData }, { data: catData }] = await Promise.all([
        supabase.from('seller_profiles').select('*').eq('user_id', user.id).maybeSingle(),
        supabase.from('categories').select('*').eq('is_active', true).order('sort_order'),
      ]);
      setSeller(sellerData as SellerProfile | null);
      setCategories((catData as Category[]) ?? []);

      if (id) {
        const { data: product } = await supabase.from('products').select('*, product_images(*), product_specs(*)').eq('id', id).maybeSingle();
        if (product) {
          const p = product as Product & { product_images: { image_url: string }[]; product_specs: { spec_key: string; spec_value: string }[] };
          setForm({
            name: p.name, brand: p.brand ?? '', description: p.description ?? '', price: String(p.price),
            unit: p.unit, min_order_quantity: String(p.min_order_quantity), stock_quantity: String(p.stock_quantity),
            sku: p.sku ?? '', delivery_radius_km: String(p.delivery_radius_km), is_delivery_available: p.is_delivery_available,
            estimated_delivery_days: p.estimated_delivery_days ?? '', category_id: p.category_id ?? '',
          });
          setImageUrls(p.product_images?.map((i) => i.image_url) ?? []);
          setSpecs(p.product_specs?.map((s) => ({ key: s.spec_key, value: s.spec_value })) ?? []);
        }
      }
      setLoading(false);
    };
    fetchData();
  }, [user, id]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !seller) return;
    setSaving(true);
    try {
      const productData = {
        seller_id: seller.id,
        category_id: form.category_id || null,
        name: form.name,
        brand: form.brand || null,
        description: form.description || null,
        price: parseFloat(form.price),
        unit: form.unit,
        min_order_quantity: parseFloat(form.min_order_quantity),
        stock_quantity: parseFloat(form.stock_quantity),
        sku: form.sku || null,
        delivery_radius_km: parseInt(form.delivery_radius_km),
        is_delivery_available: form.is_delivery_available,
        estimated_delivery_days: form.estimated_delivery_days || null,
        status: id ? undefined : 'draft' as const,
      };

      let productId: string;
      if (id) {
        const { data, error } = await supabase.from('products').update(productData).eq('id', id).select().single();
        if (error) throw error;
        productId = id;
        await supabase.from('product_images').delete().eq('product_id', id);
        await supabase.from('product_specs').delete().eq('product_id', id);
      } else {
        const { data, error } = await supabase.from('products').insert(productData).select().single();
        if (error) throw error;
        productId = (data as Product).id;
      }

      if (imageUrls.length > 0) {
        await supabase.from('product_images').insert(imageUrls.map((url, idx) => ({ product_id: productId, image_url: url, sort_order: idx })));
      }
      if (specs.length > 0) {
        await supabase.from('product_specs').insert(specs.map((s) => ({ product_id: productId, spec_key: s.key, spec_value: s.value })));
      }

      navigate('/seller/products');
    } catch (err) {
      alert('Failed to save product. Please try again.');
    }
    setSaving(false);
  };

  if (loading) return <div className="flex justify-center py-20"><div className="h-8 w-8 animate-spin rounded-full border-2 border-slate-300 border-t-slate-900" /></div>;
  if (!seller) return <div className="text-center py-20"><p className="text-slate-600">Please register as a seller first.</p></div>;

  return (
    <div className="space-y-6">
      <button onClick={() => navigate('/seller/products')} className="inline-flex items-center gap-1 text-sm text-slate-600 hover:text-slate-900">
        <ArrowLeft className="h-4 w-4" /> Back to products
      </button>
      <h1 className="text-2xl font-bold text-slate-900">{id ? 'Edit Product' : 'Add Product'}</h1>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="card space-y-4">
          <h3 className="font-semibold text-slate-900">Product Information</h3>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div><label className="label">Product Name</label><input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="input" /></div>
            <div><label className="label">Brand</label><input value={form.brand} onChange={(e) => setForm({ ...form, brand: e.target.value })} className="input" /></div>
            <div className="sm:col-span-2"><label className="label">Description</label><textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} className="input min-h-[80px]" /></div>
            <div><label className="label">Category</label><select value={form.category_id} onChange={(e) => setForm({ ...form, category_id: e.target.value })} className="input"><option value="">Select category</option>{categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></div>
            <div><label className="label">SKU / Reference</label><input value={form.sku} onChange={(e) => setForm({ ...form, sku: e.target.value })} className="input" /></div>
          </div>
        </div>

        <div className="card space-y-4">
          <h3 className="font-semibold text-slate-900">Pricing & Stock</h3>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            <div><label className="label">Price (INR)</label><input required type="number" step="0.01" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} className="input" /></div>
            <div><label className="label">Unit</label><select value={form.unit} onChange={(e) => setForm({ ...form, unit: e.target.value })} className="input">{UNITS.map((u) => <option key={u} value={u}>{u}</option>)}</select></div>
            <div><label className="label">Min. Order Quantity</label><input required type="number" step="0.01" value={form.min_order_quantity} onChange={(e) => setForm({ ...form, min_order_quantity: e.target.value })} className="input" /></div>
            <div><label className="label">Available Stock</label><input required type="number" step="0.01" value={form.stock_quantity} onChange={(e) => setForm({ ...form, stock_quantity: e.target.value })} className="input" /></div>
          </div>
        </div>

        <div className="card space-y-4">
          <h3 className="font-semibold text-slate-900">Delivery Settings</h3>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div><label className="label">Delivery Radius (km)</label><input type="number" value={form.delivery_radius_km} onChange={(e) => setForm({ ...form, delivery_radius_km: e.target.value })} className="input" /></div>
            <div><label className="label">Estimated Delivery</label><input value={form.estimated_delivery_days} onChange={(e) => setForm({ ...form, estimated_delivery_days: e.target.value })} className="input" placeholder="e.g. 2-3 days" /></div>
          </div>
          <label className="flex items-center gap-2 text-sm text-slate-700">
            <input type="checkbox" checked={form.is_delivery_available} onChange={(e) => setForm({ ...form, is_delivery_available: e.target.checked })} />
            Delivery available for this product
          </label>
        </div>

        <div className="card space-y-4">
          <h3 className="font-semibold text-slate-900">Product Images</h3>
          <div className="flex gap-2">
            <input value={imageUrl} onChange={(e) => setImageUrl(e.target.value)} className="input" placeholder="Image URL" />
            <button type="button" onClick={() => { if (imageUrl) { setImageUrls([...imageUrls, imageUrl]); setImageUrl(''); } }} className="btn-secondary shrink-0"><Plus className="h-4 w-4" /> Add</button>
          </div>
          {imageUrls.length > 0 && (
            <div className="flex flex-wrap gap-3">
              {imageUrls.map((url, idx) => (
                <div key={idx} className="relative">
                  <img src={url} alt="" className="h-20 w-20 rounded-lg border border-slate-200 object-cover" />
                  <button type="button" onClick={() => setImageUrls(imageUrls.filter((_, i) => i !== idx))} className="absolute -right-2 -top-2 rounded-full bg-red-500 p-1 text-white"><X className="h-3 w-3" /></button>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="card space-y-4">
          <h3 className="font-semibold text-slate-900">Product Specifications</h3>
          <div className="flex flex-col gap-2 sm:flex-row">
            <input value={specKey} onChange={(e) => setSpecKey(e.target.value)} className="input" placeholder="Spec name (e.g. Grade)" />
            <input value={specValue} onChange={(e) => setSpecValue(e.target.value)} className="input" placeholder="Spec value (e.g. OPC 53)" />
            <button type="button" onClick={() => { if (specKey && specValue) { setSpecs([...specs, { key: specKey, value: specValue }]); setSpecKey(''); setSpecValue(''); } }} className="btn-secondary shrink-0"><Plus className="h-4 w-4" /> Add</button>
          </div>
          {specs.length > 0 && (
            <div className="space-y-2">
              {specs.map((s, idx) => (
                <div key={idx} className="flex items-center justify-between rounded-lg bg-slate-50 px-3 py-2">
                  <span className="text-sm"><strong className="text-slate-700">{s.key}:</strong> <span className="text-slate-600">{s.value}</span></span>
                  <button type="button" onClick={() => setSpecs(specs.filter((_, i) => i !== idx))} className="text-red-500"><X className="h-4 w-4" /></button>
                </div>
              ))}
            </div>
          )}
        </div>

        <button type="submit" disabled={saving} className="btn-primary w-full">
          <Save className="h-4 w-4" /> {saving ? 'Saving...' : id ? 'Update Product' : 'Save as Draft'}
        </button>
        <p className="text-center text-sm text-slate-500">Products are saved as drafts. Submit for admin approval to make them visible to buyers.</p>
      </form>
    </div>
  );
}
