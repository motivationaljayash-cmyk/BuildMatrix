import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import type { Order, SellerProfile } from '@/types';
import { Badge, EmptyState } from '@/components/Layout';
import { ORDER_STATUS_LABELS, ORDER_STATUS_COLORS, formatCurrency, formatShortDate } from '@/lib/utils';
import { PackageX, Package, Check, X, Truck, Clock } from 'lucide-react';

export default function SellerOrders() {
  const { user } = useAuth();
  const [seller, setSeller] = useState<SellerProfile | null>(null);
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    const fetchData = async () => {
      const { data: sellerData } = await supabase.from('seller_profiles').select('*').eq('user_id', user.id).maybeSingle();
      setSeller(sellerData as SellerProfile | null);
      if (sellerData) {
        const { data } = await supabase.from('orders').select('*, order_items(*), buyer:profiles!orders_buyer_id_fkey(full_name)').eq('seller_id', (sellerData as SellerProfile).id).order('created_at', { ascending: false });
        setOrders((data as Order[]) ?? []);
      }
      setLoading(false);
    };
    fetchData();
  }, [user]);

  const updateStatus = async (orderId: string, status: string) => {
    await supabase.from('orders').update({ status }).eq('id', orderId);
    const { data: order } = await supabase.from('orders').select('buyer_id').eq('id', orderId).maybeSingle();
    if (order) {
      await supabase.from('notifications').insert({
        user_id: (order as { buyer_id: string }).buyer_id,
        title: 'Order Status Updated',
        message: `Your order status has been updated to: ${ORDER_STATUS_LABELS[status] ?? status}.`,
        type: 'order',
        link: `/buyer/orders/${orderId}`,
      });
    }
    if (seller) {
      const { data } = await supabase.from('orders').select('*, order_items(*), buyer:profiles!orders_buyer_id_fkey(full_name)').eq('seller_id', seller.id).order('created_at', { ascending: false });
      setOrders((data as Order[]) ?? []);
    }
  };

  if (loading) return <div className="flex justify-center py-20"><div className="h-8 w-8 animate-spin rounded-full border-2 border-slate-300 border-t-slate-900" /></div>;

  if (!seller) return <EmptyState icon={<Package className="h-8 w-8" />} title="No seller profile found" />;

  if (orders.length === 0) {
    return <EmptyState icon={<PackageX className="h-8 w-8" />} title="No orders yet" description="When buyers place orders for your products, they'll appear here for you to manage." />;
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-slate-900">Orders</h1>
      <div className="space-y-4">
        {orders.map((order) => (
          <div key={order.id} className="card">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <p className="font-medium text-slate-900">Order #{order.id.slice(0, 8)}</p>
                <p className="text-sm text-slate-500">{formatShortDate(order.created_at)} · {(order as { buyer?: { full_name?: string } }).buyer?.full_name ?? 'Buyer'}</p>
              </div>
              <div className="flex items-center gap-3">
                <span className="font-semibold text-slate-900">{formatCurrency(order.final_total)}</span>
                <Badge label={ORDER_STATUS_LABELS[order.status] ?? order.status} className={ORDER_STATUS_COLORS[order.status] ?? ''} />
              </div>
            </div>

            <div className="mt-4 space-y-2">
              {order.order_items?.map((item) => (
                <div key={item.id} className="flex justify-between text-sm border-b border-slate-100 pb-2 last:border-0">
                  <span className="text-slate-700">{item.product_name} × {item.quantity} {item.unit}</span>
                  <span className="font-medium text-slate-900">{formatCurrency(item.subtotal)}</span>
                </div>
              ))}
            </div>

            <div className="mt-4 flex flex-wrap gap-2">
              {order.status === 'confirmed' && (
                <button onClick={() => updateStatus(order.id, 'seller_accepted')} className="btn-primary text-xs"><Check className="h-3.5 w-3.5" /> Accept Order</button>
              )}
              {order.status === 'seller_accepted' && (
                <button onClick={() => updateStatus(order.id, 'processing')} className="btn-primary text-xs"><Clock className="h-3.5 w-3.5" /> Start Processing</button>
              )}
              {order.status === 'processing' && (
                <button onClick={() => updateStatus(order.id, 'ready_for_pickup')} className="btn-primary text-xs"><Package className="h-3.5 w-3.5" /> Ready for Pickup</button>
              )}
              {order.status === 'ready_for_pickup' && (
                <button onClick={() => updateStatus(order.id, 'out_for_delivery')} className="btn-primary text-xs"><Truck className="h-3.5 w-3.5" /> Mark Out for Delivery</button>
              )}
              {order.status === 'out_for_delivery' && (
                <button onClick={() => updateStatus(order.id, 'delivered')} className="btn-primary text-xs"><Check className="h-3.5 w-3.5" /> Mark Delivered</button>
              )}
              {order.status === 'delivered' && (
                <button onClick={() => updateStatus(order.id, 'completed')} className="btn-primary text-xs"><Check className="h-3.5 w-3.5" /> Complete Order</button>
              )}
              {['confirmed', 'seller_accepted', 'processing'].includes(order.status) && (
                <button onClick={() => updateStatus(order.id, 'disputed')} className="btn-danger text-xs"><X className="h-3.5 w-3.5" /> Dispute</button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
