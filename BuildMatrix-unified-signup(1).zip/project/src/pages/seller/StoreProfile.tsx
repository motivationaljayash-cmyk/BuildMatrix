import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import type { SellerProfile } from '@/types';
import { Save, Store } from 'lucide-react';

export default function SellerStoreProfile() {
  const { user } = useAuth();
  const [seller, setSeller] = useState<SellerProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [form, setForm] = useState({
    business_name: '', business_description: '', business_address: '', city: '', state: '', pin_code: '',
    phone: '', email: '', gst_number: '', delivery_radius_km: 10, is_delivery_available: true,
    bank_account_name: '', bank_account_number: '', bank_ifsc: '', bank_name: '', upi_id: '',
  });

  useEffect(() => {
    if (!user) return;
    const fetchData = async () => {
      const { data } = await supabase.from('seller_profiles').select('*').eq('user_id', user.id).maybeSingle();
      setSeller(data as SellerProfile | null);
      if (data) {
        const s = data as SellerProfile;
        setForm({
          business_name: s.business_name, business_description: s.business_description ?? '', business_address: s.business_address,
          city: s.city, state: s.state, pin_code: s.pin_code, phone: s.phone, email: s.email,
          gst_number: s.gst_number ?? '', delivery_radius_km: s.delivery_radius_km, is_delivery_available: s.is_delivery_available,
          bank_account_name: s.bank_account_name ?? '', bank_account_number: s.bank_account_number ?? '', bank_ifsc: s.bank_ifsc ?? '', bank_name: s.bank_name ?? '', upi_id: s.upi_id ?? '',
        });
      }
      setLoading(false);
    };
    fetchData();
  }, [user]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!seller) return;
    setSaving(true);
    await supabase.from('seller_profiles').update(form).eq('id', seller.id);
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  if (loading) return <div className="flex justify-center py-20"><div className="h-8 w-8 animate-spin rounded-full border-2 border-slate-300 border-t-slate-900" /></div>;
  if (!seller) return <div className="text-center py-20"><Store className="mx-auto mb-4 h-12 w-12 text-slate-300" /><p className="text-slate-600">No seller profile found.</p></div>;

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-slate-900">Store Profile</h1>
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="card space-y-4">
          <h3 className="font-semibold text-slate-900">Business Information</h3>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div><label className="label">Business Name</label><input required value={form.business_name} onChange={(e) => setForm({ ...form, business_name: e.target.value })} className="input" /></div>
            <div><label className="label">Phone</label><input required value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className="input" /></div>
            <div><label className="label">Email</label><input required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="input" /></div>
            <div><label className="label">GST Number</label><input value={form.gst_number} onChange={(e) => setForm({ ...form, gst_number: e.target.value })} className="input" /></div>
          </div>
          <div><label className="label">Business Description</label><textarea value={form.business_description} onChange={(e) => setForm({ ...form, business_description: e.target.value })} className="input min-h-[80px]" /></div>
        </div>

        <div className="card space-y-4">
          <h3 className="font-semibold text-slate-900">Business Address</h3>
          <div><label className="label">Address</label><input required value={form.business_address} onChange={(e) => setForm({ ...form, business_address: e.target.value })} className="input" /></div>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <div><label className="label">City</label><input required value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} className="input" /></div>
            <div><label className="label">State</label><input required value={form.state} onChange={(e) => setForm({ ...form, state: e.target.value })} className="input" /></div>
            <div><label className="label">PIN Code</label><input required value={form.pin_code} onChange={(e) => setForm({ ...form, pin_code: e.target.value })} className="input" /></div>
          </div>
        </div>

        <div className="card space-y-4">
          <h3 className="font-semibold text-slate-900">Delivery Settings</h3>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div><label className="label">Delivery Radius (km)</label><input type="number" value={form.delivery_radius_km} onChange={(e) => setForm({ ...form, delivery_radius_km: parseInt(e.target.value) })} className="input" /></div>
          </div>
          <label className="flex items-center gap-2 text-sm text-slate-700">
            <input type="checkbox" checked={form.is_delivery_available} onChange={(e) => setForm({ ...form, is_delivery_available: e.target.checked })} />
            Delivery available
          </label>
        </div>

        <div className="card space-y-4">
          <h3 className="font-semibold text-slate-900">Bank / Payment Settlement</h3>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div><label className="label">Account Name</label><input value={form.bank_account_name} onChange={(e) => setForm({ ...form, bank_account_name: e.target.value })} className="input" /></div>
            <div><label className="label">Account Number</label><input value={form.bank_account_number} onChange={(e) => setForm({ ...form, bank_account_number: e.target.value })} className="input" /></div>
            <div><label className="label">IFSC</label><input value={form.bank_ifsc} onChange={(e) => setForm({ ...form, bank_ifsc: e.target.value })} className="input" /></div>
            <div><label className="label">Bank Name</label><input value={form.bank_name} onChange={(e) => setForm({ ...form, bank_name: e.target.value })} className="input" /></div>
            <div><label className="label">UPI ID</label><input value={form.upi_id} onChange={(e) => setForm({ ...form, upi_id: e.target.value })} className="input" /></div>
          </div>
        </div>

        <button type="submit" disabled={saving} className="btn-primary"><Save className="h-4 w-4" /> {saving ? 'Saving...' : 'Save Changes'}</button>
        {saved && <p className="text-sm text-green-600">Profile updated successfully.</p>}
      </form>
    </div>
  );
}
