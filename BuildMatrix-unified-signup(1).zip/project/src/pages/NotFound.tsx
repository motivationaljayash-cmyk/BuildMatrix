import { Link } from 'react-router-dom';
import { PackageX } from 'lucide-react';

export default function NotFound() {
  return (
    <div className="flex min-h-[60vh] flex-col items-center justify-center px-4 text-center">
      <PackageX className="mb-4 h-16 w-16 text-slate-300" />
      <h1 className="text-2xl font-bold text-slate-900">Page not found</h1>
      <p className="mt-2 text-slate-600">The page you're looking for doesn't exist.</p>
      <Link to="/" className="mt-6 btn-primary">Go Home</Link>
    </div>
  );
}
