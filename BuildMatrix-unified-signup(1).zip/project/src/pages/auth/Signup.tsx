import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { Building2, Mail, Lock, User, Phone, ArrowRight, MapPin, Store, Landmark } from 'lucide-react';
import type { UserRole } from '@/types';

type SignupForm = {
  fullName: string;
  email: string;
  phone: string;
  password: string;
  addressLine1: string;
  addressLine2: string;
  city: string;
  state: string;
  pinCode: string;
  businessName: string;
  gstNumber: string;
  businessRegistrationInfo: string;
  businessDescription: string;
  bankAccountName: string;
  bankAccountNumber: string;
  bankIfsc: string;
  bankName: string;
  upiId: string;
};

const initialForm: SignupForm = {
  fullName: '', email: '', phone: '', password: '',
  addressLine1: '', addressLine2: '', city: '', state: '', pinCode: '',
  businessName: '', gstNumber: '', businessRegistrationInfo: '', businessDescription: '',
  bankAccountName: '', bankAccountNumber: '', bankIfsc: '', bankName: '', upiId: '',
};

export default function Signup() {
  const { signUp } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState<SignupForm>(initialForm);
  const [role, setRole] = useState<'buyer' | 'seller'>('buyer');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const update = (key: keyof SignupForm, value: string) => setForm((current) => ({ ...current, [key]: value }));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!/^[0-9+()\-\s]{10,15}$/.test(form.phone.trim())) {
      setError('Please enter a valid phone number.');
      return;
    }
    if (!/^\d{6}$/.test(form.pinCode.trim())) {
      setError('Please enter a valid 6-digit PIN code.');
      return;
    }
    if (role === 'seller' && !form.businessName.trim()) {
      setError('Business name is required for seller registration.');
      return;
    }

    setLoading(true);
    const { error } = await signUp(form.email.trim(), form.password, form.fullName.trim(), role, {
      phone: form.phone.trim(),
      address_line1: form.addressLine1.trim(),
      address_line2: form.addressLine2.trim(),
      city: form.city.trim(),
      state: form.state.trim(),
      pin_code: form.pinCode.trim(),
      business_name: form.businessName.trim(),
      gst_number: form.gstNumber.trim(),
      business_registration_info: form.businessRegistrationInfo.trim(),
      business_description: form.businessDescription.trim(),
      bank_account_name: form.bankAccountName.trim(),
      bank_account_number: form.bankAccountNumber.trim(),
      bank_ifsc: form.bankIfsc.trim(),
      bank_name: form.bankName.trim(),
      upi_id: form.upiId.trim(),
    });
    setLoading(false);
    if (error) setError(error);
    else navigate('/login');
  };

  const input = (key: keyof SignupForm, placeholder: string, type = 'text', required = true) => (
    <input type={type} required={required} value={form[key]} onChange={(e) => update(key, e.target.value)} className="input" placeholder={placeholder} />
  );

  return (
    <div className="min-h-screen bg-slate-50 py-10">
      <div className="mx-auto max-w-3xl px-4">
        <div className="mb-8 text-center">
          <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-slate-900 text-white"><Building2 className="h-6 w-6" /></div>
          <h1 className="text-2xl font-bold text-slate-900">Create your BuildMatrix account</h1>
          <p className="mt-2 text-sm text-slate-600">Complete your details now. Sellers will go directly into admin review after signup.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="card space-y-4">
            <h2 className="flex items-center gap-2 font-semibold text-slate-900"><User className="h-5 w-5" /> Account & contact</h2>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div><label className="label">Full Name</label>{input('fullName', 'Your full name')}</div>
              <div><label className="label">Phone</label>{input('phone', '+91 98765 43210', 'tel')}</div>
              <div><label className="label">Email</label>{input('email', 'you@example.com', 'email')}</div>
              <div><label className="label">Password</label>{input('password', 'Minimum 6 characters', 'password')}</div>
            </div>
          </div>

          <div className="card space-y-4">
            <h2 className="font-semibold text-slate-900">I want to join as</h2>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <button type="button" onClick={() => setRole('buyer')} className={`rounded-xl border p-4 text-left ${role === 'buyer' ? 'border-slate-900 bg-slate-50' : 'border-slate-200'}`}>
                <div className="flex items-center gap-3"><MapPin className="h-5 w-5" /><div><p className="font-semibold">Buyer</p><p className="text-xs text-slate-500">Buy construction materials</p></div></div>
              </button>
              <button type="button" onClick={() => setRole('seller')} className={`rounded-xl border p-4 text-left ${role === 'seller' ? 'border-slate-900 bg-slate-50' : 'border-slate-200'}`}>
                <div className="flex items-center gap-3"><Store className="h-5 w-5" /><div><p className="font-semibold">Seller</p><p className="text-xs text-slate-500">Sell construction materials</p></div></div>
              </button>
            </div>
          </div>

          {role === 'buyer' ? (
            <div className="card space-y-4">
              <h2 className="flex items-center gap-2 font-semibold text-slate-900"><MapPin className="h-5 w-5" /> Delivery address</h2>
              <div><label className="label">Address</label>{input('addressLine1', 'House / shop / street address')}</div>
              <div><label className="label">Address Line 2 <span className="font-normal text-slate-400">(optional)</span></label>{input('addressLine2', 'Landmark, area, etc.', 'text', false)}</div>
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                <div><label className="label">City</label>{input('city', 'City')}</div>
                <div><label className="label">State</label>{input('state', 'State')}</div>
                <div><label className="label">PIN Code</label>{input('pinCode', '6-digit PIN')}</div>
              </div>
            </div>
          ) : (
            <>
              <div className="card space-y-4">
                <div><h2 className="flex items-center gap-2 font-semibold text-slate-900"><Store className="h-5 w-5" /> Seller business application</h2><p className="mt-1 text-sm text-slate-500">These details are submitted to admin for verification with your account.</p></div>
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div><label className="label">Business Name</label>{input('businessName', 'Your business name')}</div>
                  <div><label className="label">GST Number <span className="font-normal text-slate-400">(if applicable)</span></label>{input('gstNumber', 'GSTIN', 'text', false)}</div>
                  <div><label className="label">Business Registration Info <span className="font-normal text-slate-400">(if applicable)</span></label>{input('businessRegistrationInfo', 'Registration / licence details', 'text', false)}</div>
                </div>
                <div><label className="label">Business Description</label><textarea value={form.businessDescription} onChange={(e) => update('businessDescription', e.target.value)} className="input min-h-[90px]" placeholder="What construction materials do you sell?" /></div>
              </div>

              <div className="card space-y-4">
                <h2 className="flex items-center gap-2 font-semibold text-slate-900"><MapPin className="h-5 w-5" /> Business address</h2>
                <div><label className="label">Address</label>{input('addressLine1', 'Shop / warehouse / business address')}</div>
                <div><label className="label">Address Line 2 <span className="font-normal text-slate-400">(optional)</span></label>{input('addressLine2', 'Landmark, area, etc.', 'text', false)}</div>
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                  <div><label className="label">City</label>{input('city', 'City')}</div>
                  <div><label className="label">State</label>{input('state', 'State')}</div>
                  <div><label className="label">PIN Code</label>{input('pinCode', '6-digit PIN')}</div>
                </div>
              </div>

              <div className="card space-y-4">
                <div><h2 className="flex items-center gap-2 font-semibold text-slate-900"><Landmark className="h-5 w-5" /> Settlement details <span className="text-xs font-normal text-slate-400">(optional for initial review)</span></h2></div>
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div><label className="label">Account Name</label>{input('bankAccountName', 'Bank account holder', 'text', false)}</div>
                  <div><label className="label">Account Number</label>{input('bankAccountNumber', 'Bank account number', 'text', false)}</div>
                  <div><label className="label">IFSC</label>{input('bankIfsc', 'IFSC code', 'text', false)}</div>
                  <div><label className="label">Bank Name</label>{input('bankName', 'Bank name', 'text', false)}</div>
                  <div><label className="label">UPI ID</label>{input('upiId', 'example@upi', 'text', false)}</div>
                </div>
              </div>
            </>
          )}

          {error && <div className="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">{error}</div>}
          <button type="submit" disabled={loading} className="btn-primary w-full">
            {loading ? 'Creating account...' : role === 'seller' ? 'Create Account & Submit Seller Application' : 'Create Buyer Account'}
            {!loading && <ArrowRight className="h-4 w-4" />}
          </button>
        </form>

        <p className="mt-4 text-center text-sm text-slate-600">Already have an account? <Link to="/login" className="font-medium text-slate-900 hover:underline">Sign in</Link></p>
      </div>
    </div>
  );
}
