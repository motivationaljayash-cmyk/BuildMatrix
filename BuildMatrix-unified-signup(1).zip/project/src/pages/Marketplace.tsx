import { useEffect, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import type { Product, Category } from '@/types';
import { formatCurrency } from '@/lib/utils';
import { EmptyState } from '@/components/EmptyState';
import { Search, MapPin, Package, SlidersHorizontal, X } from 'lucide-react';

export default function Marketplace() {
  const [searchParams] = useSearchParams();
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [showFilters, setShowFilters] = useState(false);
  const [search, setSearch] = useState(searchParams.get('q') ?? '');
  const [categoryFilter, setCategoryFilter] = useState(searchParams.get('category') ?? '');
  const [minPrice, setMinPrice] = useState('');
  const [maxPrice, setMaxPrice] = useState('');
  const [sortBy, setSortBy] = useState('newest');

  useEffect(() => {
    const fetchCategories = async () => {
      const { data } = await supabase.from('categories').select('*').eq('is_active', true).order('sort_order');
      setCategories((data as Category[]) ?? []);
    };
    fetchCategories();
  }, []);

  useEffect(() => {
    const fetchProducts = async () => {
      setLoading(true);
      let query = supabase
        .from('products')
        .select(`
          *,
          category:categories(*),
          seller:seller_profiles(*),
          product_images(*)
        `)
        .eq('status', 'active');

      if (search) {
        query = query.or(`name.ilike.%${search}%,brand.ilike.%${search}%,description.ilike.%${search}%`);
      }
      if (categoryFilter) {
        const cat = categories.find((c) => c.slug === categoryFilter);
        if (cat) query = query.eq('category_id', cat.id);
      }
      if (minPrice) query = query.gte('price', parseFloat(minPrice));
      if (maxPrice) query = query.lte('price', parseFloat(maxPrice));

      if (sortBy === 'price_low') query = query.order('price', { ascending: true });
      else if (sortBy === 'price_high') query = query.order('price', { ascending: false });
      else query = query.order('created_at', { ascending: false });

      const { data } = await query;
      setProducts((data as Product[]) ?? []);
      setLoading(false);
    };
    fetchProducts();
  }, [search, categoryFilter, minPrice, maxPrice, sortBy, categories]);

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-900">Marketplace</h1>
        <p className="mt-1 text-sm text-slate-600">Browse construction materials from verified sellers</p>
      </div>

      <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search cement, steel, sand, bricks..."
            className="input pl-10"
          />
        </div>
        <select value={sortBy} onChange={(e) => setSortBy(e.target.value)} className="input sm:w-48">
          <option value="newest">Newest first</option>
          <option value="price_low">Price: Low to High</option>
          <option value="price_high">Price: High to Low</option>
        </select>
        <button onClick={() => setShowFilters(!showFilters)} className="btn-secondary sm:w-auto">
          <SlidersHorizontal className="h-4 w-4" />
          Filters
        </button>
      </div>

      {showFilters && (
        <div className="mb-6 rounded-xl border border-slate-200 bg-white p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-slate-900">Filters</h3>
            <button onClick={() => setShowFilters(false)}><X className="h-4 w-4 text-slate-400" /></button>
          </div>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <div>
              <label className="label">Category</label>
              <select value={categoryFilter} onChange={(e) => setCategoryFilter(e.target.value)} className="input">
                <option value="">All categories</option>
                {categories.map((c) => (
                  <option key={c.id} value={c.slug}>{c.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="label">Min Price</label>
              <input type="number" value={minPrice} onChange={(e) => setMinPrice(e.target.value)} className="input" placeholder="0" />
            </div>
            <div>
              <label className="label">Max Price</label>
              <input type="number" value={maxPrice} onChange={(e) => setMaxPrice(e.target.value)} className="input" placeholder="100000" />
            </div>
          </div>
          {(categoryFilter || minPrice || maxPrice) && (
            <button
              onClick={() => { setCategoryFilter(''); setMinPrice(''); setMaxPrice(''); }}
              className="mt-3 text-sm text-slate-600 hover:text-slate-900"
            >
              Clear all filters
            </button>
          )}
        </div>
      )}

      {loading ? (
        <div className="flex justify-center py-20">
          <div className="h-8 w-8 animate-spin rounded-full border-2 border-slate-300 border-t-slate-900" />
        </div>
      ) : products.length === 0 ? (
        <EmptyState
          icon={<Package className="h-8 w-8" />}
          title="No products available yet"
          description="Sellers can add products from their dashboard. Once approved, products will appear here for buyers to discover."
          action={
            <Link to="/signup" className="btn-primary">
              Become a Seller
            </Link>
          }
        />
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {products.map((product) => (
            <Link
              key={product.id}
              to={`/product/${product.id}`}
              className="group rounded-xl border border-slate-200 bg-white overflow-hidden transition-all hover:border-slate-300 hover:shadow-md"
            >
              <div className="aspect-square bg-slate-100 overflow-hidden">
                {product.product_images && product.product_images.length > 0 ? (
                  <img src={product.product_images[0].image_url} alt={product.name} className="h-full w-full object-cover transition-transform group-hover:scale-105" />
                ) : (
                  <div className="flex h-full w-full items-center justify-center">
                    <Package className="h-12 w-12 text-slate-300" />
                  </div>
                )}
              </div>
              <div className="p-4">
                {product.category && (
                  <span className="text-xs font-medium text-slate-500">{product.category.name}</span>
                )}
                <h3 className="mt-1 font-semibold text-slate-900 line-clamp-2">{product.name}</h3>
                {product.brand && <p className="text-sm text-slate-500">{product.brand}</p>}
                <div className="mt-2 flex items-baseline gap-1">
                  <span className="text-lg font-bold text-slate-900">{formatCurrency(product.price)}</span>
                  <span className="text-sm text-slate-500">/ {product.unit}</span>
                </div>
                {product.seller && (
                  <div className="mt-2 flex items-center gap-1 text-xs text-slate-500">
                    <MapPin className="h-3 w-3" />
                    {product.seller.city}, {product.seller.state}
                  </div>
                )}
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
