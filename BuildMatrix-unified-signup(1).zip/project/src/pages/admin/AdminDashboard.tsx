import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { StatCard } from '@/components/Layout';
import { EmptyState } from '@/components/EmptyState';
import { formatCurrency, formatShortDate, ORDER_STATUS_LABELS, ORDER_STATUS_COLORS, SELLER_STATUS_LABELS, SELLER_STATUS_COLORS } from '@/lib/utils';
import { Badge } from '@/components/Layout';
import { Users, Store, Package, Banknote, Boxes, CreditCard, Truck, AlertCircle, ArrowRight } from 'lucide-react';
import type { Order, SellerProfile, Product, Profile } from '@/types';

export default function AdminDashboard() {
  const [stats, setStats] = useState({ buyers: 0, sellers: 0, pendingSellers: 0, products: 0, pendingProducts: 0, orders: 0, pendingPayments: 0, revenue: 0, transporters: 0 });
  const [recentOrders, setRecentOrders] = useState<Order[]>([]);
  const [recentSellers, setRecentSellers] = useState<SellerProfile[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      const [buyers, sellers, pendingSellers, products, pendingProducts, orders, pendingPayments, transporters, commissions, recentOrdersData, recentSellersData] = await Promise.all([
        supabase.from('profiles').select('id', { count: 'exact' }).eq('role', 'buyer'),
        supabase.from('seller_profiles').select('id', { count: 'exact' }),
        supabase.from('seller_profiles').select('id', { count: 'exact' }).eq('verification_status', 'pending'),
        supabase.from('products').select('id', { count: 'exact' }),
        supabase.from('products').select('id', { count: 'exact' }).eq('status', 'pending_approval'),
        supabase.from('orders').select('id, final_total, status, created_at', { count: 'exact' }),
        supabase.from('payments').select('id', { count: 'exact' }).eq('status', 'payment_submitted'),
        supabase.from('transporter_profiles').select('id', { count: 'exact' }),
        supabase.from('commissions').select('commission_amount'),
        supabase.from('orders').select('*, order_items(*)').order('created_at', { ascending: false }).limit(5),
        supabase.from('seller_profiles').select('*').order('created_at', { ascending: false }).limit(5),
      ]);

      const commissionRevenue = (commissions.data ?? []).reduce((sum: number, c: unknown) => {
        const commission = c as { commission_amount: number };
        return sum + (commission.commission_amount ?? 0);
      }, 0);

      setStats({
        buyers: buyers.count ?? 0,
        sellers: sellers.count ?? 0,
        pendingSellers: pendingSellers.count ?? 0,
        products: products.count ?? 0,
        pendingProducts: pendingProducts.count ?? 0,
        orders: orders.count ?? 0,
        pendingPayments: pendingPayments.count ?? 0,
        revenue: commissionRevenue,
        transporters: transporters.count ?? 0,
      });
      setRecentOrders((recentOrdersData.data as Order[]) ?? []);
      setRecentSellers((recentSellersData.data as SellerProfile[]) ?? []);
      setLoading(false);
    };
    fetchData();
  }, []);

  if (loading) return <div className="flex justify-center py-20"><div className="h-8 w-8 animate-spin rounded-full border-2 border-slate-300 border-t-slate-900" /></div>;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Admin Overview</h1>
        <p className="mt-1 text-sm text-slate-600">Real-time platform statistics from the database</p>
      </div>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard label="Buyers" value={stats.buyers} icon={<Users className="h-5 w-5" />} />
        <StatCard label="Sellers" value={stats.sellers} icon={<Store className="h-5 w-5" />} />
        <StatCard label="Transporters" value={stats.transporters} icon={<Truck className="h-5 w-5" />} />
        <StatCard label="Products" value={stats.products} icon={<Boxes className="h-5 w-5" />} />
      </div>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard label="Total Orders" value={stats.orders} icon={<Package className="h-5 w-5" />} />
        <StatCard label="Pending Payments" value={stats.pendingPayments} icon={<CreditCard className="h-5 w-5" />} />
        <StatCard label="Pending Sellers" value={stats.pendingSellers} icon={<Store className="h-5 w-5" />} />
        <StatCard label="Pending Products" value={stats.pendingProducts} icon={<Package className="h-5 w-5" />} />
      </div>

      <StatCard label="Platform Revenue (Commissions)" value={formatCurrency(stats.revenue)} icon={<Banknote className="h-5 w-5" />} />

      {(stats.pendingSellers > 0 || stats.pendingProducts > 0 || stats.pendingPayments > 0) && (
        <div className="rounded-xl border border-amber-200 bg-amber-50 p-4">
          <div className="flex items-center gap-2 mb-3">
            <AlertCircle className="h-5 w-5 text-amber-600" />
            <h3 className="font-semibold text-amber-900">Action Required</h3>
          </div>
          <div className="space-y-2">
            {stats.pendingSellers > 0 && <Link to="/admin/sellers" className="block text-sm text-amber-800 hover:underline">{stats.pendingSellers} seller application(s) pending review</Link>}
            {stats.pendingProducts > 0 && <Link to="/admin/products" className="block text-sm text-amber-800 hover:underline">{stats.pendingProducts} product(s) pending approval</Link>}
            {stats.pendingPayments > 0 && <Link to="/admin/payments" className="block text-sm text-amber-800 hover:underline">{stats.pendingPayments} payment(s) pending verification</Link>}
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <div>
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-lg font-semibold text-slate-900">Recent Orders</h2>
            <Link to="/admin/orders" className="text-sm font-medium text-slate-600 hover:text-slate-900">View all</Link>
          </div>
          {recentOrders.length === 0 ? (
            <EmptyState icon={<Package className="h-8 w-8" />} title="No orders yet" description="Orders will appear here once buyers start placing them." />
          ) : (
            <div className="space-y-2">
              {recentOrders.map((o) => (
                <div key={o.id} className="card flex items-center justify-between">
                  <div>
                    <p className="font-medium text-slate-900">#{o.id.slice(0, 8)}</p>
                    <p className="text-sm text-slate-500">{formatShortDate(o.created_at)}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-slate-900">{formatCurrency(o.final_total)}</span>
                    <Badge label={ORDER_STATUS_LABELS[o.status] ?? o.status} className={ORDER_STATUS_COLORS[o.status] ?? ''} />
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div>
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-lg font-semibold text-slate-900">Recent Sellers</h2>
            <Link to="/admin/sellers" className="text-sm font-medium text-slate-600 hover:text-slate-900">View all</Link>
          </div>
          {recentSellers.length === 0 ? (
            <EmptyState icon={<Store className="h-8 w-8" />} title="No sellers yet" description="Sellers will appear here once they register." />
          ) : (
            <div className="space-y-2">
              {recentSellers.map((s) => (
                <div key={s.id} className="card flex items-center justify-between">
                  <div>
                    <p className="font-medium text-slate-900">{s.business_name}</p>
                    <p className="text-sm text-slate-500">{s.city}, {s.state}</p>
                  </div>
                  <Badge label={SELLER_STATUS_LABELS[s.verification_status]} className={SELLER_STATUS_COLORS[s.verification_status]} />
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
