import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import type { Payment, Order } from '@/types';
import { Badge, EmptyState } from '@/components/Layout';
import { PAYMENT_STATUS_LABELS, PAYMENT_STATUS_COLORS, formatCurrency, formatShortDate } from '@/lib/utils';
import { CreditCard, Check, X, Eye } from 'lucide-react';

interface PaymentWithOrder extends Payment {
  order?: Order & { seller?: { business_name: string }; buyer?: { full_name: string } };
  payment_proofs?: { id: string; screenshot_url: string; transaction_reference: string | null; notes: string | null; created_at: string }[];
}

export default function AdminPayments() {
  const [payments, setPayments] = useState<PaymentWithOrder[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');
  const [selected, setSelected] = useState<PaymentWithOrder | null>(null);

  useEffect(() => {
    const fetchPayments = async () => {
      let query = supabase.from('payments').select('*, order:orders(*, seller:seller_profiles(business_name), buyer:profiles!orders_buyer_id_fkey(full_name)), payment_proofs(*)').order('created_at', { ascending: false });
      if (filter !== 'all') query = query.eq('status', filter);
      const { data } = await query;
      setPayments((data as PaymentWithOrder[]) ?? []);
      setLoading(false);
    };
    fetchPayments();
  }, [filter]);

  const verifyPayment = async (paymentId: string, orderId: string) => {
    const { data: adminProfile } = await supabase.from('profiles').select('id').eq('role', 'admin').maybeSingle();
    await supabase.from('payments').update({ status: 'verified', verified_by: (adminProfile as { id: string })?.id ?? null, verified_at: new Date().toISOString() }).eq('id', paymentId);
    await supabase.from('orders').update({ status: 'confirmed' }).eq('id', orderId);
    const { data: order } = await supabase.from('orders').select('buyer_id, seller_id').eq('id', orderId).maybeSingle();
    if (order) {
      const o = order as { buyer_id: string; seller_id: string };
      await supabase.from('notifications').insert([
        { user_id: o.buyer_id, title: 'Payment Verified', message: 'Your payment has been verified. The seller will process your order shortly.', type: 'payment', link: `/buyer/orders/${orderId}` },
      ]);
      const { data: seller } = await supabase.from('seller_profiles').select('user_id').eq('id', o.seller_id).maybeSingle();
      if (seller) {
        await supabase.from('notifications').insert([
          { user_id: (seller as { user_id: string }).user_id, title: 'New Order to Process', message: `Payment verified for order #${orderId.slice(0, 8)}. Please accept and process.`, type: 'order', link: '/seller/orders' },
        ]);
      }
    }
    setSelected(null);
    let query = supabase.from('payments').select('*, order:orders(*, seller:seller_profiles(business_name), buyer:profiles!orders_buyer_id_fkey(full_name)), payment_proofs(*)').order('created_at', { ascending: false });
    if (filter !== 'all') query = query.eq('status', filter);
    const { data } = await query;
    setPayments((data as PaymentWithOrder[]) ?? []);
  };

  const rejectPayment = async (paymentId: string, orderId: string) => {
    const reason = prompt('Reason for rejection:');
    if (!reason) return;
    await supabase.from('payments').update({ status: 'rejected', rejection_reason: reason }).eq('id', paymentId);
    const { data: order } = await supabase.from('orders').select('buyer_id').eq('id', orderId).maybeSingle();
    if (order) {
      await supabase.from('notifications').insert({ user_id: (order as { buyer_id: string }).buyer_id, title: 'Payment Rejected', message: `Your payment was rejected: ${reason}`, type: 'payment', link: `/buyer/orders/${orderId}` });
    }
    setSelected(null);
    let query = supabase.from('payments').select('*, order:orders(*, seller:seller_profiles(business_name), buyer:profiles!orders_buyer_id_fkey(full_name)), payment_proofs(*)').order('created_at', { ascending: false });
    if (filter !== 'all') query = query.eq('status', filter);
    const { data } = await query;
    setPayments((data as PaymentWithOrder[]) ?? []);
  };

  if (loading) return <div className="flex justify-center py-20"><div className="h-8 w-8 animate-spin rounded-full border-2 border-slate-300 border-t-slate-900" /></div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-slate-900">Payments</h1>
        <select value={filter} onChange={(e) => setFilter(e.target.value)} className="input w-48">
          <option value="all">All Payments</option>
          <option value="unpaid">Unpaid</option>
          <option value="payment_submitted">Payment Submitted</option>
          <option value="verified">Verified</option>
          <option value="rejected">Rejected</option>
          <option value="refunded">Refunded</option>
        </select>
      </div>

      {payments.length === 0 ? (
        <EmptyState icon={<CreditCard className="h-8 w-8" />} title="No transactions yet" description="Payment records will appear here once buyers submit payments for their orders." />
      ) : (
        <div className="space-y-3">
          {payments.map((p) => (
            <div key={p.id} className="card flex flex-wrap items-center justify-between gap-3">
              <div>
                <p className="font-medium text-slate-900">Order #{p.order_id.slice(0, 8)}</p>
                <p className="text-sm text-slate-500">
                  {p.order?.buyer?.full_name ?? 'Buyer'} → {p.order?.seller?.business_name ?? 'Seller'} · {formatShortDate(p.created_at)}
                </p>
              </div>
              <div className="flex items-center gap-3">
                <span className="font-semibold text-slate-900">{formatCurrency(p.amount)}</span>
                <Badge label={PAYMENT_STATUS_LABELS[p.status] ?? p.status} className={PAYMENT_STATUS_COLORS[p.status] ?? ''} />
                <button onClick={() => setSelected(p)} className="btn-secondary text-xs px-3 py-1.5"><Eye className="h-3.5 w-3.5" /> View</button>
              </div>
            </div>
          ))}
        </div>
      )}

      {selected && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onClick={() => setSelected(null)}>
          <div className="max-h-[80vh] w-full max-w-lg overflow-y-auto rounded-xl bg-white p-6" onClick={(e) => e.stopPropagation()}>
            <h3 className="text-lg font-bold text-slate-900">Payment Details</h3>
            <div className="mt-4 space-y-2 text-sm">
              <p><span className="text-slate-500">Order ID:</span> <span className="font-mono text-slate-900">{selected.order_id.slice(0, 8)}</span></p>
              <p><span className="text-slate-500">Amount:</span> <span className="font-bold text-slate-900">{formatCurrency(selected.amount)}</span></p>
              <p><span className="text-slate-500">Method:</span> <span className="text-slate-900">{selected.payment_method}</span></p>
              <p><span className="text-slate-500">Status:</span> <Badge label={PAYMENT_STATUS_LABELS[selected.status] ?? selected.status} className={PAYMENT_STATUS_COLORS[selected.status] ?? ''} /></p>
              <p><span className="text-slate-500">Submitted:</span> <span className="text-slate-900">{formatShortDate(selected.created_at)}</span></p>
              {selected.rejection_reason && <p><span className="text-red-500">Rejection:</span> <span className="text-slate-700">{selected.rejection_reason}</span></p>}
            </div>

            {selected.payment_proofs && selected.payment_proofs.length > 0 && (
              <div className="mt-4">
                <h4 className="font-semibold text-slate-900 mb-2">Payment Proofs</h4>
                {selected.payment_proofs.map((proof) => (
                  <div key={proof.id} className="mb-3 rounded-lg border border-slate-200 p-3">
                    {proof.transaction_reference && <p className="text-sm"><span className="text-slate-500">Reference:</span> <span className="font-mono text-slate-900">{proof.transaction_reference}</span></p>}
                    {proof.notes && <p className="text-sm text-slate-600 mt-1">{proof.notes}</p>}
                    <a href={proof.screenshot_url} target="_blank" rel="noopener noreferrer" className="mt-2 block">
                      <img src={proof.screenshot_url} alt="Payment proof" className="h-40 rounded-lg border border-slate-200 object-cover" />
                    </a>
                  </div>
                ))}
              </div>
            )}

            {selected.status === 'payment_submitted' && (
              <div className="mt-6 flex gap-2">
                <button onClick={() => verifyPayment(selected.id, selected.order_id)} className="btn-primary text-xs"><Check className="h-3.5 w-3.5" /> Verify Payment</button>
                <button onClick={() => rejectPayment(selected.id, selected.order_id)} className="btn-danger text-xs"><X className="h-3.5 w-3.5" /> Reject Payment</button>
                <button onClick={() => setSelected(null)} className="btn-secondary text-xs">Close</button>
              </div>
            )}
            {selected.status !== 'payment_submitted' && (
              <button onClick={() => setSelected(null)} className="btn-secondary mt-6 text-xs">Close</button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
