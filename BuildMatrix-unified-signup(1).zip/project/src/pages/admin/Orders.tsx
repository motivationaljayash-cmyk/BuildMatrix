import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import type { Order } from '@/types';
import { Badge, EmptyState } from '@/components/Layout';
import { ORDER_STATUS_LABELS, ORDER_STATUS_COLORS, formatCurrency, formatShortDate } from '@/lib/utils';
import { Package, PackageX } from 'lucide-react';

export default function AdminOrders() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    const fetchOrders = async () => {
      let query = supabase.from('orders').select('*, order_items(*), seller:seller_profiles(*), buyer:profiles!orders_buyer_id_fkey(full_name)').order('created_at', { ascending: false });
      if (filter !== 'all') query = query.eq('status', filter);
      const { data } = await query;
      setOrders((data as Order[]) ?? []);
      setLoading(false);
    };
    fetchOrders();
  }, [filter]);

  if (loading) return <div className="flex justify-center py-20"><div className="h-8 w-8 animate-spin rounded-full border-2 border-slate-300 border-t-slate-900" /></div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-slate-900">All Orders</h1>
        <select value={filter} onChange={(e) => setFilter(e.target.value)} className="input w-48">
          <option value="all">All Status</option>
          <option value="pending_payment">Pending Payment</option>
          <option value="payment_submitted">Payment Submitted</option>
          <option value="confirmed">Confirmed</option>
          <option value="seller_accepted">Seller Accepted</option>
          <option value="processing">Processing</option>
          <option value="out_for_delivery">Out for Delivery</option>
          <option value="delivered">Delivered</option>
          <option value="completed">Completed</option>
          <option value="cancelled">Cancelled</option>
          <option value="disputed">Disputed</option>
        </select>
      </div>

      {orders.length === 0 ? (
        <EmptyState icon={<PackageX className="h-8 w-8" />} title="No orders yet" description="Orders will appear here once buyers start purchasing from the marketplace." />
      ) : (
        <div className="space-y-3">
          {orders.map((o) => (
            <div key={o.id} className="card">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <p className="font-medium text-slate-900">Order #{o.id.slice(0, 8)}</p>
                  <p className="text-sm text-slate-500">
                    {formatShortDate(o.created_at)} · {(o as { buyer?: { full_name?: string } }).buyer?.full_name ?? 'Buyer'} · {o.seller?.business_name ?? 'Seller'} · {o.order_items?.length ?? 0} items
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <span className="font-semibold text-slate-900">{formatCurrency(o.final_total)}</span>
                  <Badge label={ORDER_STATUS_LABELS[o.status] ?? o.status} className={ORDER_STATUS_COLORS[o.status] ?? ''} />
                </div>
              </div>
              <div className="mt-3 text-sm space-y-1">
                <p className="text-slate-600">Material: {formatCurrency(o.material_subtotal)} · Delivery: {formatCurrency(o.delivery_charge)} · Fee ({o.platform_fee_percentage}%): {formatCurrency(o.platform_fee_amount)}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
