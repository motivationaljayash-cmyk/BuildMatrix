import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import type { SupportTicket } from '@/types';
import { Badge, EmptyState } from '@/components/Layout';
import { TICKET_STATUS_LABELS, TICKET_STATUS_COLORS, formatShortDate } from '@/lib/utils';
import { LifeBuoy, MessageSquare, X, Send } from 'lucide-react';

export default function AdminSupport() {
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<SupportTicket | null>(null);
  const [reply, setReply] = useState('');

  useEffect(() => {
    const fetchTickets = async () => {
      const { data } = await supabase.from('support_tickets').select('*, support_ticket_replies(*)').order('created_at', { ascending: false });
      setTickets((data as SupportTicket[]) ?? []);
      setLoading(false);
    };
    fetchTickets();
  }, []);

  const updateStatus = async (id: string, status: string) => {
    await supabase.from('support_tickets').update({ status }).eq('id', id);
    const { data } = await supabase.from('support_tickets').select('*, support_ticket_replies(*)').order('created_at', { ascending: false });
    setTickets((data as SupportTicket[]) ?? []);
    if (selected) {
      const updated = (data as SupportTicket[]).find((t) => t.id === id);
      if (updated) setSelected(updated);
    }
  };

  const sendReply = async (ticketId: string, userId: string) => {
    if (!reply.trim()) return;
    await supabase.from('support_ticket_replies').insert({ ticket_id: ticketId, user_id: userId, message: reply, is_staff_reply: true });
    await supabase.from('support_tickets').update({ status: 'in_progress' }).eq('id', ticketId);
    await supabase.from('notifications').insert({ user_id: userId, title: 'Support Reply', message: 'You have a new reply to your support ticket.', type: 'support', link: '/buyer/support' });
    setReply('');
    const { data } = await supabase.from('support_tickets').select('*, support_ticket_replies(*)').order('created_at', { ascending: false });
    setTickets((data as SupportTicket[]) ?? []);
    const updated = (data as SupportTicket[]).find((t) => t.id === ticketId);
    if (updated) setSelected(updated);
  };

  if (loading) return <div className="flex justify-center py-20"><div className="h-8 w-8 animate-spin rounded-full border-2 border-slate-300 border-t-slate-900" /></div>;

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-slate-900">Support Tickets</h1>

      {tickets.length === 0 ? (
        <EmptyState icon={<LifeBuoy className="h-8 w-8" />} title="No support tickets" description="Support tickets from buyers, sellers, and transporters will appear here." />
      ) : (
        <div className="space-y-3">
          {tickets.map((t) => (
            <div key={t.id} className="card flex items-center justify-between">
              <div>
                <p className="font-medium text-slate-900">{t.subject}</p>
                <p className="text-sm text-slate-500">{formatShortDate(t.created_at)} · {t.category ?? 'General'}</p>
              </div>
              <div className="flex items-center gap-2">
                <Badge label={TICKET_STATUS_LABELS[t.status] ?? t.status} className={TICKET_STATUS_COLORS[t.status] ?? ''} />
                <button onClick={() => setSelected(t)} className="btn-secondary text-xs px-3 py-1.5"><MessageSquare className="h-3.5 w-3.5" /> View</button>
              </div>
            </div>
          ))}
        </div>
      )}

      {selected && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onClick={() => setSelected(null)}>
          <div className="max-h-[80vh] w-full max-w-lg overflow-y-auto rounded-xl bg-white p-6" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-slate-900">{selected.subject}</h3>
              <button onClick={() => setSelected(null)}><X className="h-4 w-4 text-slate-400" /></button>
            </div>
            <div className="space-y-2 text-sm">
              <p className="text-slate-600">{selected.description}</p>
              <div className="border-t border-slate-100 pt-3 mt-3">
                <p className="text-xs font-medium text-slate-500 mb-2">Replies</p>
                {selected.support_ticket_replies?.length === 0 && <p className="text-sm text-slate-400">No replies yet.</p>}
                {selected.support_ticket_replies?.map((r) => (
                  <div key={r.id} className={`mb-2 rounded-lg p-3 ${r.is_staff_reply ? 'bg-slate-100' : 'bg-blue-50'}`}>
                    <p className="text-sm text-slate-700">{r.message}</p>
                    <p className="text-xs text-slate-400 mt-1">{formatShortDate(r.created_at)} {r.is_staff_reply && '· Staff'}</p>
                  </div>
                ))}
              </div>
              <div className="border-t border-slate-100 pt-3 mt-3">
                <textarea value={reply} onChange={(e) => setReply(e.target.value)} className="input min-h-[60px]" placeholder="Type a reply..." />
                <button onClick={() => sendReply(selected.id, selected.user_id)} className="btn-primary mt-2 text-xs"><Send className="h-3.5 w-3.5" /> Send Reply</button>
              </div>
              <div className="flex gap-2 mt-3">
                {selected.status === 'open' && <button onClick={() => updateStatus(selected.id, 'in_progress')} className="btn-secondary text-xs">Mark In Progress</button>}
                {selected.status !== 'resolved' && <button onClick={() => updateStatus(selected.id, 'resolved')} className="btn-secondary text-xs">Mark Resolved</button>}
                {selected.status !== 'closed' && <button onClick={() => updateStatus(selected.id, 'closed')} className="btn-secondary text-xs">Close Ticket</button>}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
