import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import type { PlatformSettings } from '@/types';
import { Save, Settings as SettingsIcon, CreditCard, Banknote } from 'lucide-react';

export default function AdminSettings() {
  const [settings, setSettings] = useState<PlatformSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [form, setForm] = useState({
    platform_name: '', tagline: '', support_email: '', support_phone: '', commission_percentage: '4',
    upi_id: '', upi_qr_image_url: '', payment_instructions: '', logo_url: '',
  });

  useEffect(() => {
    const fetchSettings = async () => {
      const { data } = await supabase.from('platform_settings').select('*').eq('id', 1).maybeSingle();
      setSettings(data as PlatformSettings | null);
      if (data) {
        const s = data as PlatformSettings;
        setForm({
          platform_name: s.platform_name, tagline: s.tagline, support_email: s.support_email ?? '',
          support_phone: s.support_phone ?? '', commission_percentage: String(s.commission_percentage),
          upi_id: s.upi_id ?? '', upi_qr_image_url: s.upi_qr_image_url ?? '', payment_instructions: s.payment_instructions ?? '',
          logo_url: s.logo_url ?? '',
        });
      }
      setLoading(false);
    };
    fetchSettings();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    await supabase.from('platform_settings').update({
      platform_name: form.platform_name, tagline: form.tagline, support_email: form.support_email,
      support_phone: form.support_phone, commission_percentage: parseFloat(form.commission_percentage),
      upi_id: form.upi_id, upi_qr_image_url: form.upi_qr_image_url, payment_instructions: form.payment_instructions,
      logo_url: form.logo_url,
    }).eq('id', 1);
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  if (loading) return <div className="flex justify-center py-20"><div className="h-8 w-8 animate-spin rounded-full border-2 border-slate-300 border-t-slate-900" /></div>;

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-slate-900">Platform Settings</h1>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="card space-y-4">
          <div className="flex items-center gap-2">
            <SettingsIcon className="h-5 w-5 text-slate-600" />
            <h3 className="font-semibold text-slate-900">General</h3>
          </div>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div><label className="label">Platform Name</label><input value={form.platform_name} onChange={(e) => setForm({ ...form, platform_name: e.target.value })} className="input" /></div>
            <div><label className="label">Tagline</label><input value={form.tagline} onChange={(e) => setForm({ ...form, tagline: e.target.value })} className="input" /></div>
            <div><label className="label">Support Email</label><input type="email" value={form.support_email} onChange={(e) => setForm({ ...form, support_email: e.target.value })} className="input" /></div>
            <div><label className="label">Support Phone</label><input value={form.support_phone} onChange={(e) => setForm({ ...form, support_phone: e.target.value })} className="input" /></div>
            <div><label className="label">Logo URL</label><input value={form.logo_url} onChange={(e) => setForm({ ...form, logo_url: e.target.value })} className="input" /></div>
          </div>
        </div>

        <div className="card space-y-4">
          <div className="flex items-center gap-2">
            <Banknote className="h-5 w-5 text-slate-600" />
            <h3 className="font-semibold text-slate-900">Commission</h3>
          </div>
          <div><label className="label">Platform Commission (%)</label><input type="number" step="0.01" value={form.commission_percentage} onChange={(e) => setForm({ ...form, commission_percentage: e.target.value })} className="input max-w-xs" /><p className="mt-1 text-xs text-slate-500">Default: 4%. This is the fee charged on completed material orders.</p></div>
        </div>

        <div className="card space-y-4">
          <div className="flex items-center gap-2">
            <CreditCard className="h-5 w-5 text-slate-600" />
            <h3 className="font-semibold text-slate-900">UPI Payment Settings</h3>
          </div>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div><label className="label">UPI ID</label><input value={form.upi_id} onChange={(e) => setForm({ ...form, upi_id: e.target.value })} className="input" placeholder="business@upi" /><p className="mt-1 text-xs text-slate-500">Enter your real business UPI ID here.</p></div>
            <div><label className="label">UPI QR Image URL</label><input value={form.upi_qr_image_url} onChange={(e) => setForm({ ...form, upi_qr_image_url: e.target.value })} className="input" placeholder="https://...qr.png" /></div>
          </div>
          <div><label className="label">Payment Instructions</label><textarea value={form.payment_instructions} onChange={(e) => setForm({ ...form, payment_instructions: e.target.value })} className="input min-h-[80px]" placeholder="Instructions shown to buyers at checkout..." /></div>
        </div>

        <button type="submit" disabled={saving} className="btn-primary"><Save className="h-4 w-4" /> {saving ? 'Saving...' : 'Save Settings'}</button>
        {saved && <p className="text-sm text-green-600">Settings saved successfully.</p>}
      </form>
    </div>
  );
}
