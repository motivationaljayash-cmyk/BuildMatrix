import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import type { SellerProfile, SellerAuditLog } from '@/types';
import { Badge, EmptyState } from '@/components/Layout';
import { SELLER_STATUS_LABELS, SELLER_STATUS_COLORS, SELLER_AUDIT_ACTION_LABELS, formatShortDate } from '@/lib/utils';
import { Store, Check, X, Ban, Eye, MessageSquare, FileText, ShieldCheck, ArrowLeft } from 'lucide-react';

type TabFilter = 'all' | 'pending' | 'approved' | 'rejected' | 'more_information_required' | 'suspended';

export default function AdminSellers() {
  const { user } = useAuth();
  const [sellers, setSellers] = useState<SellerProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<TabFilter>('all');
  const [reviewingId, setReviewingId] = useState<string | null>(null);
  const [reviewSeller, setReviewSeller] = useState<SellerProfile | null>(null);
  const [auditLogs, setAuditLogs] = useState<SellerAuditLog[]>([]);
  const [adminNames, setAdminNames] = useState<Record<string, string>>({});
  const [actionLoading, setActionLoading] = useState(false);
  const [showRejectModal, setShowRejectModal] = useState(false);
  const [showInfoModal, setShowInfoModal] = useState(false);
  const [rejectReason, setRejectReason] = useState('');
  const [infoMessage, setInfoMessage] = useState('');

  const fetchSellers = useCallback(async () => {
    let query = supabase.from('seller_profiles').select('*').order('created_at', { ascending: false });
    if (filter !== 'all') query = query.eq('verification_status', filter);
    const { data } = await query;
    setSellers((data as SellerProfile[]) ?? []);
    setLoading(false);
  }, [filter]);

  useEffect(() => { fetchSellers(); }, [fetchSellers]);

  const openReview = async (seller: SellerProfile) => {
    setReviewSeller(seller);
    setReviewingId(seller.id);
    const { data: logs } = await supabase
      .from('seller_audit_logs')
      .select('*')
      .eq('seller_id', seller.id)
      .order('created_at', { ascending: false });
    setAuditLogs((logs as SellerAuditLog[]) ?? []);

    const adminIds = [...new Set((logs as SellerAuditLog[] ?? []).map((l) => l.admin_id))];
    if (adminIds.length > 0) {
      const { data: profiles } = await supabase
        .from('profiles')
        .select('id, full_name')
        .in('id', adminIds);
      const nameMap: Record<string, string> = {};
      (profiles as { id: string; full_name: string }[] ?? []).forEach((p) => { nameMap[p.id] = p.full_name; });
      setAdminNames(nameMap);
    } else {
      setAdminNames({});
    }
  };

  const closeReview = () => {
    setReviewSeller(null);
    setReviewingId(null);
    setAuditLogs([]);
    setShowRejectModal(false);
    setShowInfoModal(false);
    setRejectReason('');
    setInfoMessage('');
  };

  const logAction = async (sellerId: string, action: string, message: string | null, previousStatus: string, newStatus: string) => {
    if (!user) return;
    await supabase.from('seller_audit_logs').insert({
      seller_id: sellerId,
      admin_id: user.id,
      action,
      message,
      previous_status: previousStatus,
      new_status: newStatus,
    });
  };

  const notifySeller = async (userId: string, title: string, message: string) => {
    await supabase.from('notifications').insert({
      user_id: userId,
      title,
      message,
      type: 'verification',
      link: '/seller',
    });
  };

  const approveSeller = async () => {
    if (!reviewSeller || !user) return;
    setActionLoading(true);
    const prev = reviewSeller.verification_status;
    await supabase.from('seller_profiles').update({
      verification_status: 'approved',
      verification_notes: null,
      rejection_reason: null,
      approved_at: new Date().toISOString(),
      approved_by: user.id,
    }).eq('id', reviewSeller.id);
    await logAction(reviewSeller.id, 'approve', null, prev, 'approved');
    await notifySeller(reviewSeller.user_id, 'Seller Approved', 'Your seller application has been approved. You can now add and publish products.');
    await fetchSellers();
    const updated = { ...reviewSeller, verification_status: 'approved' as const };
    setReviewSeller(updated);
    await openReview(updated);
    setActionLoading(false);
  };

  const rejectSeller = async () => {
    if (!reviewSeller || !user || !rejectReason.trim()) return;
    setActionLoading(true);
    const prev = reviewSeller.verification_status;
    await supabase.from('seller_profiles').update({
      verification_status: 'rejected',
      rejection_reason: rejectReason.trim(),
      verification_notes: rejectReason.trim(),
      rejected_at: new Date().toISOString(),
      rejected_by: user.id,
    }).eq('id', reviewSeller.id);
    await logAction(reviewSeller.id, 'reject', rejectReason.trim(), prev, 'rejected');
    await notifySeller(reviewSeller.user_id, 'Seller Application Rejected', `Your application was rejected: ${rejectReason.trim()}`);
    setShowRejectModal(false);
    setRejectReason('');
    await fetchSellers();
    const updated = { ...reviewSeller, verification_status: 'rejected' as const, rejection_reason: rejectReason.trim() };
    setReviewSeller(updated);
    await openReview(updated);
    setActionLoading(false);
  };

  const requestInfo = async () => {
    if (!reviewSeller || !user || !infoMessage.trim()) return;
    setActionLoading(true);
    const prev = reviewSeller.verification_status;
    await supabase.from('seller_profiles').update({
      verification_status: 'more_information_required',
      info_request_message: infoMessage.trim(),
      verification_notes: infoMessage.trim(),
      info_requested_at: new Date().toISOString(),
      info_requested_by: user.id,
    }).eq('id', reviewSeller.id);
    await logAction(reviewSeller.id, 'request_info', infoMessage.trim(), prev, 'more_information_required');
    await notifySeller(reviewSeller.user_id, 'More Information Required', `The admin needs more information: ${infoMessage.trim()}`);
    setShowInfoModal(false);
    setInfoMessage('');
    await fetchSellers();
    const updated = { ...reviewSeller, verification_status: 'more_information_required' as const, info_request_message: infoMessage.trim() };
    setReviewSeller(updated);
    await openReview(updated);
    setActionLoading(false);
  };

  const suspendSeller = async () => {
    if (!reviewSeller || !user) return;
    setActionLoading(true);
    const prev = reviewSeller.verification_status;
    await supabase.from('seller_profiles').update({
      verification_status: 'suspended',
      verification_notes: 'Account suspended by admin.',
    }).eq('id', reviewSeller.id);
    await logAction(reviewSeller.id, 'suspend', 'Account suspended by admin.', prev, 'suspended');
    await notifySeller(reviewSeller.user_id, 'Seller Account Suspended', 'Your seller account has been suspended. Please contact support.');
    await fetchSellers();
    const updated = { ...reviewSeller, verification_status: 'suspended' as const };
    setReviewSeller(updated);
    await openReview(updated);
    setActionLoading(false);
  };

  if (loading) return <div className="flex justify-center py-20"><div className="h-8 w-8 animate-spin rounded-full border-2 border-slate-300 border-t-slate-900" /></div>;

  const tabs: { value: TabFilter; label: string }[] = [
    { value: 'all', label: 'All' },
    { value: 'pending', label: 'Pending' },
    { value: 'approved', label: 'Approved' },
    { value: 'rejected', label: 'Rejected' },
    { value: 'more_information_required', label: 'More Info Required' },
    { value: 'suspended', label: 'Suspended' },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Seller Requests</h1>
        <p className="mt-1 text-sm text-slate-600">Review and approve seller applications</p>
      </div>

      {/* Tabs */}
      <div className="flex flex-wrap gap-2">
        {tabs.map((tab) => (
          <button
            key={tab.value}
            onClick={() => { setFilter(tab.value); setLoading(true); }}
            className={`rounded-lg px-3 py-1.5 text-sm font-medium transition-colors ${
              filter === tab.value
                ? 'bg-slate-900 text-white'
                : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Seller list */}
      {sellers.length === 0 ? (
        <EmptyState
          icon={<Store className="h-8 w-8" />}
          title="No seller applications yet"
          description="When sellers register, their applications will appear here for review and approval."
        />
      ) : (
        <div className="space-y-3">
          {sellers.map((s) => (
            <div key={s.id} className="card">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="min-w-0 flex-1">
                  <p className="font-medium text-slate-900">{s.business_name}</p>
                  <p className="text-sm text-slate-500">
                    {s.owner_name} · {s.phone} · {s.email}
                  </p>
                  <p className="text-sm text-slate-500">
                    {s.city}, {s.state} · Applied {formatShortDate(s.created_at)}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <Badge label={SELLER_STATUS_LABELS[s.verification_status] ?? s.verification_status} className={SELLER_STATUS_COLORS[s.verification_status] ?? ''} />
                  <button onClick={() => openReview(s)} className="btn-primary text-xs px-3 py-1.5">
                    <Eye className="h-3.5 w-3.5" /> Review
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Review Modal */}
      {reviewSeller && reviewingId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onClick={closeReview}>
          <div className="max-h-[85vh] w-full max-w-2xl overflow-y-auto rounded-xl bg-white p-6" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-lg font-bold text-slate-900">{reviewSeller.business_name}</h3>
                <Badge label={SELLER_STATUS_LABELS[reviewSeller.verification_status] ?? reviewSeller.verification_status} className={SELLER_STATUS_COLORS[reviewSeller.verification_status] ?? ''} />
              </div>
              <button onClick={closeReview} className="text-slate-400 hover:text-slate-600"><X className="h-5 w-5" /></button>
            </div>

            {/* Business Information */}
            <div className="mb-4">
              <h4 className="mb-2 flex items-center gap-1.5 text-sm font-semibold text-slate-700"><Store className="h-4 w-4" /> Business Information</h4>
              <div className="grid grid-cols-1 gap-2 rounded-lg border border-slate-200 p-4 text-sm sm:grid-cols-2">
                <div><span className="text-slate-500">Business Name:</span> <span className="font-medium text-slate-900">{reviewSeller.business_name}</span></div>
                <div><span className="text-slate-500">Owner Name:</span> <span className="font-medium text-slate-900">{reviewSeller.owner_name}</span></div>
                <div><span className="text-slate-500">Phone:</span> <span className="font-medium text-slate-900">{reviewSeller.phone}</span></div>
                <div><span className="text-slate-500">Email:</span> <span className="font-medium text-slate-900">{reviewSeller.email}</span></div>
                <div className="sm:col-span-2"><span className="text-slate-500">Business Address:</span> <span className="font-medium text-slate-900">{reviewSeller.business_address}, {reviewSeller.city}, {reviewSeller.state} {reviewSeller.pin_code}</span></div>
                {reviewSeller.gst_number && <div><span className="text-slate-500">GST Number:</span> <span className="font-mono font-medium text-slate-900">{reviewSeller.gst_number}</span></div>}
                {reviewSeller.business_registration_info && <div><span className="text-slate-500">Registration Info:</span> <span className="font-medium text-slate-900">{reviewSeller.business_registration_info}</span></div>}
              </div>
            </div>

            {/* Business Description */}
            {reviewSeller.business_description && (
              <div className="mb-4">
                <h4 className="mb-2 flex items-center gap-1.5 text-sm font-semibold text-slate-700"><FileText className="h-4 w-4" /> Business Description</h4>
                <p className="rounded-lg border border-slate-200 p-4 text-sm text-slate-700">{reviewSeller.business_description}</p>
              </div>
            )}

            {/* Bank/Payment Info */}
            {(reviewSeller.bank_name || reviewSeller.upi_id) && (
              <div className="mb-4">
                <h4 className="mb-2 text-sm font-semibold text-slate-700">Bank / Payment Settlement</h4>
                <div className="grid grid-cols-1 gap-2 rounded-lg border border-slate-200 p-4 text-sm sm:grid-cols-2">
                  {reviewSeller.bank_name && <div><span className="text-slate-500">Bank:</span> <span className="font-medium text-slate-900">{reviewSeller.bank_name}</span></div>}
                  {reviewSeller.bank_ifsc && <div><span className="text-slate-500">IFSC:</span> <span className="font-mono font-medium text-slate-900">{reviewSeller.bank_ifsc}</span></div>}
                  {reviewSeller.upi_id && <div><span className="text-slate-500">UPI ID:</span> <span className="font-mono font-medium text-slate-900">{reviewSeller.upi_id}</span></div>}
                </div>
              </div>
            )}

            {/* Application date */}
            <div className="mb-4 text-sm text-slate-500">
              Date of application: {formatShortDate(reviewSeller.created_at)}
            </div>

            {/* Rejection reason if rejected */}
            {reviewSeller.verification_status === 'rejected' && reviewSeller.rejection_reason && (
              <div className="mb-4 rounded-lg border border-red-200 bg-red-50 p-4">
                <p className="text-sm font-medium text-red-800">Rejection Reason:</p>
                <p className="mt-1 text-sm text-red-700">{reviewSeller.rejection_reason}</p>
                {reviewSeller.rejected_at && <p className="mt-2 text-xs text-red-500">Rejected on {formatShortDate(reviewSeller.rejected_at)}</p>}
              </div>
            )}

            {/* Info request message */}
            {reviewSeller.verification_status === 'more_information_required' && reviewSeller.info_request_message && (
              <div className="mb-4 rounded-lg border border-blue-200 bg-blue-50 p-4">
                <p className="text-sm font-medium text-blue-800">Information Requested by Admin:</p>
                <p className="mt-1 text-sm text-blue-700">{reviewSeller.info_request_message}</p>
                {reviewSeller.info_requested_at && <p className="mt-2 text-xs text-blue-500">Requested on {formatShortDate(reviewSeller.info_requested_at)}</p>}
              </div>
            )}

            {/* Audit Log */}
            {auditLogs.length > 0 && (
              <div className="mb-4">
                <h4 className="mb-2 flex items-center gap-1.5 text-sm font-semibold text-slate-700"><ShieldCheck className="h-4 w-4" /> Admin Audit Log</h4>
                <div className="space-y-2">
                  {auditLogs.map((log) => (
                    <div key={log.id} className="rounded-lg border border-slate-200 p-3 text-sm">
                      <div className="flex items-center justify-between">
                        <span className="font-medium text-slate-900">{SELLER_AUDIT_ACTION_LABELS[log.action] ?? log.action}</span>
                        <span className="text-xs text-slate-400">{formatShortDate(log.created_at)}</span>
                      </div>
                      <p className="mt-1 text-xs text-slate-500">
                        By: {adminNames[log.admin_id] ?? 'Admin'} · {log.previous_status} → {log.new_status}
                      </p>
                      {log.message && <p className="mt-1 text-xs text-slate-600">{log.message}</p>}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Admin Actions */}
            <div className="flex flex-wrap gap-2 border-t border-slate-200 pt-4">
              {reviewSeller.verification_status !== 'approved' && (
                <button onClick={approveSeller} disabled={actionLoading} className="btn-primary text-xs">
                  <Check className="h-3.5 w-3.5" /> {actionLoading ? 'Processing...' : 'Approve Seller'}
                </button>
              )}
              {reviewSeller.verification_status !== 'rejected' && (
                <button onClick={() => setShowRejectModal(true)} disabled={actionLoading} className="btn-danger text-xs">
                  <X className="h-3.5 w-3.5" /> Reject Seller
                </button>
              )}
              {reviewSeller.verification_status !== 'more_information_required' && (
                <button onClick={() => setShowInfoModal(true)} disabled={actionLoading} className="btn-secondary text-xs">
                  <MessageSquare className="h-3.5 w-3.5" /> Request More Information
                </button>
              )}
              {reviewSeller.verification_status !== 'suspended' && reviewSeller.verification_status === 'approved' && (
                <button onClick={suspendSeller} disabled={actionLoading} className="btn-secondary text-xs">
                  <Ban className="h-3.5 w-3.5" /> Suspend
                </button>
              )}
            </div>

            {/* Reject Modal */}
            {showRejectModal && (
              <div className="mt-4 rounded-lg border border-red-200 bg-red-50 p-4">
                <h4 className="mb-2 text-sm font-semibold text-red-800">Rejection Reason (required)</h4>
                <textarea
                  value={rejectReason}
                  onChange={(e) => setRejectReason(e.target.value)}
                  className="input min-h-[80px]"
                  placeholder="Explain why this seller application is being rejected..."
                />
                <div className="mt-2 flex gap-2">
                  <button onClick={rejectSeller} disabled={!rejectReason.trim() || actionLoading} className="btn-danger text-xs">
                    {actionLoading ? 'Processing...' : 'Confirm Rejection'}
                  </button>
                  <button onClick={() => { setShowRejectModal(false); setRejectReason(''); }} className="btn-secondary text-xs">Cancel</button>
                </div>
              </div>
            )}

            {/* Info Request Modal */}
            {showInfoModal && (
              <div className="mt-4 rounded-lg border border-blue-200 bg-blue-50 p-4">
                <h4 className="mb-2 text-sm font-semibold text-blue-800">What information or documents are missing? (required)</h4>
                <textarea
                  value={infoMessage}
                  onChange={(e) => setInfoMessage(e.target.value)}
                  className="input min-h-[80px]"
                  placeholder="Describe what additional information or documents the seller needs to provide..."
                />
                <div className="mt-2 flex gap-2">
                  <button onClick={requestInfo} disabled={!infoMessage.trim() || actionLoading} className="btn-primary text-xs">
                    {actionLoading ? 'Processing...' : 'Send Request'}
                  </button>
                  <button onClick={() => { setShowInfoModal(false); setInfoMessage(''); }} className="btn-secondary text-xs">Cancel</button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
