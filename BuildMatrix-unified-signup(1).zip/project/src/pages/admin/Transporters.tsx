import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import type { TransporterProfile } from '@/types';
import { Badge, EmptyState } from '@/components/Layout';
import { SELLER_STATUS_LABELS, SELLER_STATUS_COLORS, formatShortDate } from '@/lib/utils';
import { Truck, Check, X, Ban } from 'lucide-react';

export default function AdminTransporters() {
  const [transporters, setTransporters] = useState<TransporterProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    const fetchTransporters = async () => {
      let query = supabase.from('transporter_profiles').select('*').order('created_at', { ascending: false });
      if (filter !== 'all') query = query.eq('verification_status', filter);
      const { data } = await query;
      setTransporters((data as TransporterProfile[]) ?? []);
      setLoading(false);
    };
    fetchTransporters();
  }, [filter]);

  const updateStatus = async (id: string, status: string, notes?: string) => {
    await supabase.from('transporter_profiles').update({ verification_status: status, verification_notes: notes ?? null }).eq('id', id);
    const { data: tp } = await supabase.from('transporter_profiles').select('user_id, name').eq('id', id).maybeSingle();
    if (tp) {
      const t = tp as { user_id: string; name: string };
      await supabase.from('notifications').insert({
        user_id: t.user_id,
        title: `Transporter ${status === 'approved' ? 'Approved' : status === 'rejected' ? 'Rejected' : 'Suspended'}`,
        message: `Your transporter application has been ${status}.`,
        type: 'verification',
        link: '/transporter',
      });
    }
    let query = supabase.from('transporter_profiles').select('*').order('created_at', { ascending: false });
    if (filter !== 'all') query = query.eq('verification_status', filter);
    const { data } = await query;
    setTransporters((data as TransporterProfile[]) ?? []);
  };

  if (loading) return <div className="flex justify-center py-20"><div className="h-8 w-8 animate-spin rounded-full border-2 border-slate-300 border-t-slate-900" /></div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-slate-900">Transporters</h1>
        <select value={filter} onChange={(e) => setFilter(e.target.value)} className="input w-48">
          <option value="all">All Transporters</option>
          <option value="pending">Pending</option>
          <option value="approved">Approved</option>
          <option value="rejected">Rejected</option>
          <option value="suspended">Suspended</option>
        </select>
      </div>

      {transporters.length === 0 ? (
        <EmptyState icon={<Truck className="h-8 w-8" />} title="No transporters have joined yet" description="When transporters register, their applications will appear here for review." />
      ) : (
        <div className="space-y-3">
          {transporters.map((t) => (
            <div key={t.id} className="card flex flex-wrap items-center justify-between gap-3">
              <div>
                <p className="font-medium text-slate-900">{t.name}</p>
                <p className="text-sm text-slate-500">{t.phone} · {t.service_area} · {formatShortDate(t.created_at)}</p>
                <p className="text-sm text-slate-500">Base charge: ₹{t.base_delivery_charge}</p>
              </div>
              <div className="flex items-center gap-2">
                <Badge label={SELLER_STATUS_LABELS[t.verification_status]} className={SELLER_STATUS_COLORS[t.verification_status]} />
                {t.verification_status !== 'approved' && <button onClick={() => updateStatus(t.id, 'approved')} className="btn-primary text-xs"><Check className="h-3.5 w-3.5" /> Approve</button>}
                {t.verification_status !== 'rejected' && <button onClick={() => updateStatus(t.id, 'rejected', 'Application rejected.')} className="btn-danger text-xs"><X className="h-3.5 w-3.5" /> Reject</button>}
                {t.verification_status !== 'suspended' && <button onClick={() => updateStatus(t.id, 'suspended', 'Account suspended.')} className="btn-secondary text-xs"><Ban className="h-3.5 w-3.5" /> Suspend</button>}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
