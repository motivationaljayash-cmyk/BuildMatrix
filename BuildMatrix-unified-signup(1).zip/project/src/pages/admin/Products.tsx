import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import type { Product, SellerProfile } from '@/types';
import { Badge, EmptyState } from '@/components/Layout';
import { PRODUCT_STATUS_LABELS, PRODUCT_STATUS_COLORS, formatCurrency, formatShortDate } from '@/lib/utils';
import { Boxes, Check, X, Ban, Eye } from 'lucide-react';

export default function AdminProducts() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');
  const [selected, setSelected] = useState<Product | null>(null);

  useEffect(() => {
    const fetchProducts = async () => {
      let query = supabase.from('products').select('*, category:categories(*), seller:seller_profiles(*)').order('created_at', { ascending: false });
      if (filter !== 'all') query = query.eq('status', filter);
      const { data } = await query;
      setProducts((data as Product[]) ?? []);
      setLoading(false);
    };
    fetchProducts();
  }, [filter]);

  const updateStatus = async (id: string, status: string, reason?: string) => {
    await supabase.from('products').update({ status, rejection_reason: reason ?? null }).eq('id', id);
    const { data: product } = await supabase.from('products').select('seller_id').eq('id', id).maybeSingle();
    if (product) {
      const p = product as { seller_id: string };
      const { data: seller } = await supabase.from('seller_profiles').select('user_id').eq('id', p.seller_id).maybeSingle();
      if (seller) {
        await supabase.from('notifications').insert({
          user_id: (seller as { user_id: string }).user_id,
          title: `Product ${status === 'active' ? 'Approved' : status === 'rejected' ? 'Rejected' : 'Disabled'}`,
          message: `Your product has been ${status}.`,
          type: 'product',
          link: '/seller/products',
        });
      }
    }
    setSelected(null);
    let query = supabase.from('products').select('*, category:categories(*), seller:seller_profiles(*)').order('created_at', { ascending: false });
    if (filter !== 'all') query = query.eq('status', filter);
    const { data } = await query;
    setProducts((data as Product[]) ?? []);
  };

  if (loading) return <div className="flex justify-center py-20"><div className="h-8 w-8 animate-spin rounded-full border-2 border-slate-300 border-t-slate-900" /></div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-slate-900">Products</h1>
        <select value={filter} onChange={(e) => setFilter(e.target.value)} className="input w-48">
          <option value="all">All Products</option>
          <option value="pending_approval">Pending Approval</option>
          <option value="active">Active</option>
          <option value="draft">Draft</option>
          <option value="rejected">Rejected</option>
          <option value="disabled">Disabled</option>
        </select>
      </div>

      {products.length === 0 ? (
        <EmptyState icon={<Boxes className="h-8 w-8" />} title="No products yet" description="When sellers add products, they'll appear here for approval before becoming visible to buyers." />
      ) : (
        <div className="space-y-3">
          {products.map((p) => (
            <div key={p.id} className="card flex flex-wrap items-center justify-between gap-3">
              <div>
                <p className="font-medium text-slate-900">{p.name}</p>
                <p className="text-sm text-slate-500">{p.seller?.business_name ?? 'Unknown seller'} · {formatCurrency(p.price)}/{p.unit} · {formatShortDate(p.created_at)}</p>
              </div>
              <div className="flex items-center gap-2">
                <Badge label={PRODUCT_STATUS_LABELS[p.status] ?? p.status} className={PRODUCT_STATUS_COLORS[p.status] ?? ''} />
                <button onClick={() => setSelected(p)} className="btn-secondary text-xs px-3 py-1.5"><Eye className="h-3.5 w-3.5" /> View</button>
              </div>
            </div>
          ))}
        </div>
      )}

      {selected && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onClick={() => setSelected(null)}>
          <div className="max-h-[80vh] w-full max-w-lg overflow-y-auto rounded-xl bg-white p-6" onClick={(e) => e.stopPropagation()}>
            <h3 className="text-lg font-bold text-slate-900">{selected.name}</h3>
            <div className="mt-4 space-y-2 text-sm">
              <p><span className="text-slate-500">Seller:</span> <span className="font-medium text-slate-900">{selected.seller?.business_name}</span></p>
              <p><span className="text-slate-500">Category:</span> <span className="font-medium text-slate-900">{selected.category?.name ?? 'N/A'}</span></p>
              <p><span className="text-slate-500">Brand:</span> <span className="font-medium text-slate-900">{selected.brand ?? 'N/A'}</span></p>
              <p><span className="text-slate-500">Price:</span> <span className="font-medium text-slate-900">{formatCurrency(selected.price)} / {selected.unit}</span></p>
              <p><span className="text-slate-500">Stock:</span> <span className="font-medium text-slate-900">{selected.stock_quantity}</span></p>
              <p><span className="text-slate-500">Min Order:</span> <span className="font-medium text-slate-900">{selected.min_order_quantity}</span></p>
              {selected.description && <p><span className="text-slate-500">Description:</span> <span className="text-slate-700">{selected.description}</span></p>}
              {selected.rejection_reason && <p><span className="text-red-500">Rejection reason:</span> <span className="text-slate-700">{selected.rejection_reason}</span></p>}
            </div>
            <div className="mt-6 flex flex-wrap gap-2">
              {selected.status !== 'active' && <button onClick={() => updateStatus(selected.id, 'active')} className="btn-primary text-xs"><Check className="h-3.5 w-3.5" /> Approve</button>}
              {selected.status !== 'rejected' && <button onClick={() => updateStatus(selected.id, 'rejected', 'Product not approved by admin.')} className="btn-danger text-xs"><X className="h-3.5 w-3.5" /> Reject</button>}
              {selected.status !== 'disabled' && <button onClick={() => updateStatus(selected.id, 'disabled')} className="btn-secondary text-xs"><Ban className="h-3.5 w-3.5" /> Disable</button>}
              <button onClick={() => setSelected(null)} className="btn-secondary text-xs">Close</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
