import { useEffect, useState } from 'react';
import { Mail, Phone, MessageCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { PlatformSettings } from '@/types';

export default function Contact() {
  const [settings, setSettings] = useState<PlatformSettings | null>(null);

  useEffect(() => {
    supabase.from('platform_settings').select('*').eq('id', 1).maybeSingle().then(({ data }) => {
      setSettings(data as PlatformSettings | null);
    });
  }, []);

  return (
    <div className="mx-auto max-w-5xl px-4 py-14 sm:px-6 lg:px-8">
      <div className="max-w-2xl">
        <p className="text-sm font-semibold uppercase tracking-wide text-slate-500">BuildMatrix Support</p>
        <h1 className="mt-2 text-4xl font-bold tracking-tight text-slate-900">How can we help?</h1>
        <p className="mt-4 text-slate-600">For order, seller, delivery, or account questions, use the support details below.</p>
      </div>
      <div className="mt-10 grid gap-5 sm:grid-cols-2">
        <a href={settings?.support_email ? `mailto:${settings.support_email}` : '#'} className="card block hover:border-slate-300">
          <Mail className="h-6 w-6 text-slate-900" /><h2 className="mt-4 font-semibold text-slate-900">Email</h2><p className="mt-1 text-sm text-slate-600">{settings?.support_email ?? 'Support email not configured yet.'}</p>
        </a>
        <a href={settings?.support_phone ? `tel:${settings.support_phone}` : '#'} className="card block hover:border-slate-300">
          <Phone className="h-6 w-6 text-slate-900" /><h2 className="mt-4 font-semibold text-slate-900">Phone</h2><p className="mt-1 text-sm text-slate-600">{settings?.support_phone ?? 'Support phone not configured yet.'}</p>
        </a>
      </div>
      <div className="mt-6 card flex items-start gap-3 bg-slate-50">
        <MessageCircle className="mt-0.5 h-5 w-5 shrink-0 text-slate-700" />
        <p className="text-sm leading-6 text-slate-600">For account-specific support tickets, sign in and use your dashboard's Support section.</p>
      </div>
    </div>
  );
}
