import { Outlet } from 'react-router-dom';
import { DashboardLayout, ProtectedRoute } from './Layout';
import { LayoutDashboard, Search, ShoppingCart, Package, MapPin, User, Heart, LifeBuoy, Store, Plus, Banknote, Settings, ShieldCheck, Users, Boxes, CreditCard, Truck, Sliders, BarChart3, FileText, Headphones } from 'lucide-react';

const buyerNav = [
  { label: 'Overview', path: '/buyer', icon: <LayoutDashboard className="h-4 w-4" /> },
  { label: 'Search Products', path: '/buyer/search', icon: <Search className="h-4 w-4" /> },
  { label: 'Cart', path: '/buyer/cart', icon: <ShoppingCart className="h-4 w-4" /> },
  { label: 'Orders', path: '/buyer/orders', icon: <Package className="h-4 w-4" /> },
  { label: 'Saved Products', path: '/buyer/saved', icon: <Heart className="h-4 w-4" /> },
  { label: 'Addresses', path: '/buyer/addresses', icon: <MapPin className="h-4 w-4" /> },
  { label: 'Profile', path: '/buyer/profile', icon: <User className="h-4 w-4" /> },
  { label: 'Support', path: '/buyer/support', icon: <LifeBuoy className="h-4 w-4" /> },
];

const sellerNav = [
  { label: 'Overview', path: '/seller', icon: <LayoutDashboard className="h-4 w-4" /> },
  { label: 'Products', path: '/seller/products', icon: <Boxes className="h-4 w-4" /> },
  { label: 'Add Product', path: '/seller/products/add', icon: <Plus className="h-4 w-4" /> },
  { label: 'Orders', path: '/seller/orders', icon: <Package className="h-4 w-4" /> },
  { label: 'Earnings', path: '/seller/earnings', icon: <Banknote className="h-4 w-4" /> },
  { label: 'Store Profile', path: '/seller/store-profile', icon: <Store className="h-4 w-4" /> },
  { label: 'Support', path: '/seller/support', icon: <LifeBuoy className="h-4 w-4" /> },
];

const transporterNav = [
  { label: 'Overview', path: '/transporter', icon: <LayoutDashboard className="h-4 w-4" /> },
  { label: 'Delivery Jobs', path: '/transporter/jobs', icon: <Truck className="h-4 w-4" /> },
  { label: 'Vehicle', path: '/transporter/vehicle', icon: <Truck className="h-4 w-4" /> },
  { label: 'Profile', path: '/transporter/profile', icon: <User className="h-4 w-4" /> },
  { label: 'Support', path: '/transporter/support', icon: <LifeBuoy className="h-4 w-4" /> },
];

const adminNav = [
  { label: 'Overview', path: '/admin', icon: <LayoutDashboard className="h-4 w-4" /> },
  { label: 'Sellers', path: '/admin/sellers', icon: <Store className="h-4 w-4" /> },
  { label: 'Products', path: '/admin/products', icon: <Boxes className="h-4 w-4" /> },
  { label: 'Orders', path: '/admin/orders', icon: <Package className="h-4 w-4" /> },
  { label: 'Payments', path: '/admin/payments', icon: <CreditCard className="h-4 w-4" /> },
  { label: 'Transporters', path: '/admin/transporters', icon: <Truck className="h-4 w-4" /> },
  { label: 'Settings', path: '/admin/settings', icon: <Settings className="h-4 w-4" /> },
  { label: 'Support', path: '/admin/support', icon: <LifeBuoy className="h-4 w-4" /> },
];

export function BuyerLayout() {
  return <ProtectedRoute allowedRoles={['buyer', 'admin']}><DashboardLayout navItems={buyerNav} title="Buyer Dashboard"><Outlet /></DashboardLayout></ProtectedRoute>;
}
export function SellerLayout() {
  return <ProtectedRoute allowedRoles={['seller', 'admin']}><DashboardLayout navItems={sellerNav} title="Seller Dashboard"><Outlet /></DashboardLayout></ProtectedRoute>;
}
export function TransporterLayout() {
  return <ProtectedRoute allowedRoles={['transporter', 'admin']}><DashboardLayout navItems={transporterNav} title="Transporter Dashboard"><Outlet /></DashboardLayout></ProtectedRoute>;
}
export function AdminLayout() {
  return <ProtectedRoute allowedRoles={['admin']}><DashboardLayout navItems={adminNav} title="Admin Dashboard"><Outlet /></DashboardLayout></ProtectedRoute>;
}
