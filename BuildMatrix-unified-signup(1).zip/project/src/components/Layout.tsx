import { ReactNode } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { Building2, ShoppingCart, LayoutDashboard, Package, Truck, Users, Settings, LogOut, Bell, Menu, X } from 'lucide-react';
import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import type { Notification } from '@/types';
import { EmptyState } from '@/components/EmptyState';

export { EmptyState };

interface NavbarProps {
  children?: ReactNode;
}

export function Navbar() {
  const { user, profile, signOut } = useAuth();
  const navigate = useNavigate();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [showNotifs, setShowNotifs] = useState(false);

  useEffect(() => {
    if (!user) return;
    const fetchNotifications = async () => {
      const { data } = await supabase
        .from('notifications')
        .select('*')
        .eq('user_id', user.id)
        .eq('is_read', false)
        .order('created_at', { ascending: false })
        .limit(10);
      setNotifications((data as Notification[]) ?? []);
    };
    fetchNotifications();
    const interval = setInterval(fetchNotifications, 30000);
    return () => clearInterval(interval);
  }, [user]);

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

  const markNotificationRead = async (id: string) => {
    await supabase.from('notifications').update({ is_read: true }).eq('id', id);
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  };

  const dashboardLink = profile?.role === 'admin' ? '/admin' : profile?.role === 'seller' ? '/seller' : profile?.role === 'transporter' ? '/transporter' : '/buyer';

  return (
    <header className="sticky top-0 z-50 border-b border-slate-200 bg-white/95 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-2">
          <Link to="/" className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-slate-900 text-white">
              <Building2 className="h-5 w-5" />
            </div>
            <span className="text-lg font-bold tracking-tight text-slate-900">BuildMatrix</span>
          </Link>
        </div>

        <nav className="hidden items-center gap-6 md:flex">
          <Link to="/" className="text-sm font-medium text-slate-600 hover:text-slate-900">Home</Link>
          <Link to="/marketplace" className="text-sm font-medium text-slate-600 hover:text-slate-900">Marketplace</Link>
          <Link to="/categories" className="text-sm font-medium text-slate-600 hover:text-slate-900">Categories</Link>
          {user && (
            <Link to="/marketplace" className="text-sm font-medium text-slate-600 hover:text-slate-900">
              <span className="inline-flex items-center gap-1.5">
                <ShoppingCart className="h-4 w-4" />
              </span>
            </Link>
          )}
        </nav>

        <div className="flex items-center gap-3">
          {user && (
            <div className="relative">
              <button
                onClick={() => setShowNotifs(!showNotifs)}
                className="relative rounded-lg p-2 text-slate-600 hover:bg-slate-100"
              >
                <Bell className="h-5 w-5" />
                {notifications.length > 0 && (
                  <span className="absolute right-1 top-1 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-[10px] font-bold text-white">
                    {notifications.length}
                  </span>
                )}
              </button>
              {showNotifs && (
                <div className="absolute right-0 mt-2 w-80 rounded-lg border border-slate-200 bg-white shadow-lg">
                  <div className="border-b border-slate-100 px-4 py-3">
                    <p className="text-sm font-semibold text-slate-800">Notifications</p>
                  </div>
                  <div className="max-h-80 overflow-y-auto">
                    {notifications.length === 0 ? (
                      <p className="px-4 py-6 text-center text-sm text-slate-500">No new notifications</p>
                    ) : (
                      notifications.map((n) => (
                        <button
                          key={n.id}
                          onClick={() => markNotificationRead(n.id)}
                          className="block w-full border-b border-slate-50 px-4 py-3 text-left hover:bg-slate-50"
                        >
                          <p className="text-sm font-medium text-slate-800">{n.title}</p>
                          <p className="mt-0.5 text-xs text-slate-500">{n.message}</p>
                        </button>
                      ))
                    )}
                  </div>
                </div>
              )}
            </div>
          )}

          {user ? (
            <div className="hidden items-center gap-3 md:flex">
              <Link
                to={dashboardLink}
                className="inline-flex items-center gap-1.5 rounded-lg bg-slate-900 px-4 py-2 text-sm font-medium text-white hover:bg-slate-800"
              >
                <LayoutDashboard className="h-4 w-4" />
                Dashboard
              </Link>
              <button
                onClick={handleSignOut}
                className="rounded-lg p-2 text-slate-600 hover:bg-slate-100"
                title="Sign out"
              >
                <LogOut className="h-5 w-5" />
              </button>
            </div>
          ) : (
            <div className="hidden items-center gap-3 md:flex">
              <Link to="/login" className="text-sm font-medium text-slate-600 hover:text-slate-900">
                Sign In
              </Link>
              <Link
                to="/signup"
                className="rounded-lg bg-slate-900 px-4 py-2 text-sm font-medium text-white hover:bg-slate-800"
              >
                Get Started
              </Link>
            </div>
          )}

          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="rounded-lg p-2 text-slate-600 hover:bg-slate-100 md:hidden"
          >
            {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {mobileOpen && (
        <div className="border-t border-slate-200 bg-white px-4 py-4 md:hidden">
          <nav className="flex flex-col gap-3">
            <Link to="/" onClick={() => setMobileOpen(false)} className="text-sm font-medium text-slate-600 hover:text-slate-900">Home</Link>
            <Link to="/marketplace" onClick={() => setMobileOpen(false)} className="text-sm font-medium text-slate-600 hover:text-slate-900">Marketplace</Link>
            <Link to="/categories" onClick={() => setMobileOpen(false)} className="text-sm font-medium text-slate-600 hover:text-slate-900">Categories</Link>
            {user ? (
              <>
                <Link to={dashboardLink} onClick={() => setMobileOpen(false)} className="text-sm font-medium text-slate-600 hover:text-slate-900">Dashboard</Link>
                <button onClick={handleSignOut} className="text-left text-sm font-medium text-red-600">Sign Out</button>
              </>
            ) : (
              <>
                <Link to="/login" onClick={() => setMobileOpen(false)} className="text-sm font-medium text-slate-600 hover:text-slate-900">Sign In</Link>
                <Link to="/signup" onClick={() => setMobileOpen(false)} className="text-sm font-medium text-slate-600 hover:text-slate-900">Get Started</Link>
              </>
            )}
          </nav>
        </div>
      )}
    </header>
  );
}

export function Footer() {
  return (
    <footer className="border-t border-slate-200 bg-slate-900 text-slate-300">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-4">
          <div>
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-white text-slate-900">
                <Building2 className="h-5 w-5" />
              </div>
              <span className="text-lg font-bold text-white">BuildMatrix</span>
            </div>
            <p className="mt-3 text-sm text-slate-400">
              Construction Materials. Local Suppliers. Delivered.
            </p>
          </div>
          <div>
            <h4 className="text-sm font-semibold text-white">Marketplace</h4>
            <ul className="mt-3 space-y-2 text-sm">
              <li><Link to="/marketplace" className="hover:text-white">Browse Materials</Link></li>
              <li><Link to="/categories" className="hover:text-white">Categories</Link></li>
              <li><Link to="/signup" className="hover:text-white">Become a Seller</Link></li>
              <li><Link to="/signup" className="hover:text-white">Transport Partner</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="text-sm font-semibold text-white">Account</h4>
            <ul className="mt-3 space-y-2 text-sm">
              <li><Link to="/login" className="hover:text-white">Sign In</Link></li>
              <li><Link to="/signup" className="hover:text-white">Create Account</Link></li>
              <li><Link to="/buyer" className="hover:text-white">Buyer Dashboard</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="text-sm font-semibold text-white">Support</h4>
            <ul className="mt-3 space-y-2 text-sm">
              <li><Link to="/buyer/support" className="hover:text-white">Help Center</Link></li>
              <li><Link to="/about" className="hover:text-white">About Us</Link></li>
              <li><Link to="/contact" className="hover:text-white">Contact</Link></li>
            </ul>
          </div>
        </div>
        <div className="mt-8 border-t border-slate-800 pt-6 text-center text-sm text-slate-400">
          <p>&copy; {new Date().getFullYear()} BuildMatrix. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}

interface ProtectedRouteProps {
  children: ReactNode;
  allowedRoles?: string[];
}

export function ProtectedRoute({ children, allowedRoles }: ProtectedRouteProps) {
  const { user, profile, loading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading) {
      if (!user) {
        navigate('/login');
      } else if (allowedRoles && profile && !allowedRoles.includes(profile.role)) {
        navigate('/');
      }
    }
  }, [user, profile, loading, allowedRoles, navigate]);

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-slate-300 border-t-slate-900" />
      </div>
    );
  }

  if (!user) return null;
  if (allowedRoles && profile && !allowedRoles.includes(profile.role)) return null;

  return <>{children}</>;
}

interface DashboardLayoutProps {
  children: ReactNode;
  navItems: { label: string; path: string; icon: ReactNode }[];
  title: string;
}

export function DashboardLayout({ children, navItems, title }: DashboardLayoutProps) {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="min-h-screen bg-slate-50">
      <Navbar />
      <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
        <div className="flex flex-col gap-6 lg:flex-row">
          <aside className="lg:w-64 lg:shrink-0">
            <div className="mb-4 lg:sticky lg:top-20">
              <div className="rounded-xl border border-slate-200 bg-white p-4">
                <h2 className="mb-3 px-2 text-xs font-semibold uppercase tracking-wide text-slate-500">{title}</h2>
                <button
                  onClick={() => setSidebarOpen(!sidebarOpen)}
                  className="mb-2 w-full rounded-lg bg-slate-100 px-3 py-2 text-left text-sm font-medium text-slate-700 lg:hidden"
                >
                  {sidebarOpen ? 'Hide Menu' : 'Show Menu'}
                </button>
                <nav className={`space-y-1 ${sidebarOpen ? 'block' : 'hidden lg:block'}`}>
                  {navItems.map((item) => (
                    <Link
                      key={item.path}
                      to={item.path}
                      className="flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm font-medium text-slate-600 hover:bg-slate-100 hover:text-slate-900"
                    >
                      {item.icon}
                      {item.label}
                    </Link>
                  ))}
                </nav>
              </div>
            </div>
          </aside>
          <main className="flex-1 min-w-0">{children}</main>
        </div>
      </div>
    </div>
  );
}

interface StatCardProps {
  label: string;
  value: string | number;
  icon?: ReactNode;
}

export function StatCard({ label, value, icon }: StatCardProps) {
  return (
    <div className="rounded-xl border border-slate-200 bg-white p-5">
      <div className="flex items-center justify-between">
        <p className="text-sm font-medium text-slate-500">{label}</p>
        {icon && <div className="text-slate-400">{icon}</div>}
      </div>
      <p className="mt-2 text-2xl font-bold text-slate-900">{value}</p>
    </div>
  );
}

interface BadgeProps {
  label: string;
  className?: string;
}

export function Badge({ label, className = '' }: BadgeProps) {
  return (
    <span className={`inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium ${className}`}>
      {label}
    </span>
  );
}
