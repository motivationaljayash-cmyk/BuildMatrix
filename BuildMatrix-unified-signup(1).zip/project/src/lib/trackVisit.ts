import { supabase } from './supabase';

const VISITOR_ID_KEY = 'buildmatrix_visitor_id';

function getVisitorId(): string {
  let visitorId = localStorage.getItem(VISITOR_ID_KEY);
  if (!visitorId) {
    visitorId = crypto.randomUUID();
    localStorage.setItem(VISITOR_ID_KEY, visitorId);
  }
  return visitorId;
}

export async function trackVisit(pagePath = window.location.pathname) {
  try {
    const visitorId = getVisitorId();
    const { data: { user } } = await supabase.auth.getUser();

    await supabase.from('site_visits').insert({
      visitor_id: visitorId,
      user_id: user?.id ?? null,
      page_path: pagePath,
      referrer: document.referrer || null,
    });
  } catch {
    // Analytics must never block or break the customer experience.
  }
}
