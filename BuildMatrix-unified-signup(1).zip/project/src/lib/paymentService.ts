export interface PaymentService {
  method: string;
  generatePaymentDetails(amount: number, upiId: string, payeeName: string): PaymentDetails;
}

export interface PaymentDetails {
  upiId: string;
  amount: number;
  payeeName: string;
  upiLink: string;
  qrUrl: string;
  instructions: string;
}

class ManualUPIPaymentService implements PaymentService {
  method = 'manual_upi';

  generatePaymentDetails(amount: number, upiId: string, payeeName: string): PaymentDetails {
    const upiLink = `upi://pay?pa=${encodeURIComponent(upiId)}&pn=${encodeURIComponent(payeeName)}&am=${amount}&cu=INR&tn=BuildMatrix Order`;
    const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=256x256&data=${encodeURIComponent(upiLink)}`;
    return {
      upiId,
      amount,
      payeeName,
      upiLink,
      qrUrl,
      instructions: 'Open your UPI app (Google Pay, PhonePe, Paytm, etc.) and pay the amount to the UPI ID shown. After payment, take a screenshot and upload it as payment proof.',
    };
  }
}

export const paymentService: PaymentService = new ManualUPIPaymentService();
