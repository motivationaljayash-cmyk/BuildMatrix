import { supabase } from '@/lib/supabase';
import type { PlatformSettings } from '@/types';

export async function getPlatformSettings(): Promise<PlatformSettings | null> {
  const { data, error } = await supabase
    .from('platform_settings')
    .select('*')
    .eq('id', 1)
    .maybeSingle();
  if (error) {
    console.error('Error fetching platform settings:', error);
    return null;
  }
  return data as PlatformSettings | null;
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 2,
  }).format(amount);
}

export function formatDate(dateString: string): string {
  return new Date(dateString).toLocaleDateString('en-IN', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function formatShortDate(dateString: string): string {
  return new Date(dateString).toLocaleDateString('en-IN', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
}

export const ORDER_STATUS_LABELS: Record<string, string> = {
  pending_payment: 'Pending Payment',
  payment_submitted: 'Payment Submitted',
  payment_verification: 'Payment Verification',
  confirmed: 'Confirmed',
  seller_accepted: 'Seller Accepted',
  processing: 'Processing',
  ready_for_pickup: 'Ready for Pickup',
  transport_assigned: 'Transport Assigned',
  out_for_delivery: 'Out for Delivery',
  delivered: 'Delivered',
  completed: 'Completed',
  cancelled: 'Cancelled',
  refunded: 'Refunded',
  disputed: 'Disputed',
};

export const ORDER_STATUS_COLORS: Record<string, string> = {
  pending_payment: 'bg-amber-100 text-amber-800 border-amber-200',
  payment_submitted: 'bg-blue-100 text-blue-800 border-blue-200',
  payment_verification: 'bg-blue-100 text-blue-800 border-blue-200',
  confirmed: 'bg-green-100 text-green-800 border-green-200',
  seller_accepted: 'bg-green-100 text-green-800 border-green-200',
  processing: 'bg-indigo-100 text-indigo-800 border-indigo-200',
  ready_for_pickup: 'bg-cyan-100 text-cyan-800 border-cyan-200',
  transport_assigned: 'bg-purple-100 text-purple-800 border-purple-200',
  out_for_delivery: 'bg-orange-100 text-orange-800 border-orange-200',
  delivered: 'bg-green-100 text-green-800 border-green-200',
  completed: 'bg-emerald-100 text-emerald-800 border-emerald-200',
  cancelled: 'bg-red-100 text-red-800 border-red-200',
  refunded: 'bg-gray-100 text-gray-800 border-gray-200',
  disputed: 'bg-red-100 text-red-800 border-red-200',
};

export const SELLER_STATUS_LABELS: Record<string, string> = {
  pending: 'Pending',
  approved: 'Approved',
  rejected: 'Rejected',
  suspended: 'Suspended',
  more_information_required: 'More Info Required',
};

export const SELLER_STATUS_COLORS: Record<string, string> = {
  pending: 'bg-amber-100 text-amber-800 border-amber-200',
  approved: 'bg-green-100 text-green-800 border-green-200',
  rejected: 'bg-red-100 text-red-800 border-red-200',
  suspended: 'bg-gray-100 text-gray-800 border-gray-200',
  more_information_required: 'bg-blue-100 text-blue-800 border-blue-200',
};

export const SELLER_AUDIT_ACTION_LABELS: Record<string, string> = {
  approve: 'Approved',
  reject: 'Rejected',
  request_info: 'Requested More Information',
  suspend: 'Suspended',
  unsuspend: 'Reinstated',
};

export const PRODUCT_STATUS_LABELS: Record<string, string> = {
  draft: 'Draft',
  pending_approval: 'Pending Approval',
  active: 'Active',
  out_of_stock: 'Out of Stock',
  rejected: 'Rejected',
  disabled: 'Disabled',
};

export const PRODUCT_STATUS_COLORS: Record<string, string> = {
  draft: 'bg-gray-100 text-gray-800 border-gray-200',
  pending_approval: 'bg-amber-100 text-amber-800 border-amber-200',
  active: 'bg-green-100 text-green-800 border-green-200',
  out_of_stock: 'bg-red-100 text-red-800 border-red-200',
  rejected: 'bg-red-100 text-red-800 border-red-200',
  disabled: 'bg-gray-100 text-gray-800 border-gray-200',
};

export const DELIVERY_STATUS_LABELS: Record<string, string> = {
  available: 'Available',
  accepted: 'Accepted',
  pickup: 'Pickup',
  in_transit: 'In Transit',
  delivered: 'Delivered',
  cancelled: 'Cancelled',
};

export const DELIVERY_STATUS_COLORS: Record<string, string> = {
  available: 'bg-blue-100 text-blue-800 border-blue-200',
  accepted: 'bg-amber-100 text-amber-800 border-amber-200',
  pickup: 'bg-cyan-100 text-cyan-800 border-cyan-200',
  in_transit: 'bg-orange-100 text-orange-800 border-orange-200',
  delivered: 'bg-green-100 text-green-800 border-green-200',
  cancelled: 'bg-red-100 text-red-800 border-red-200',
};

export const PAYMENT_STATUS_LABELS: Record<string, string> = {
  unpaid: 'Unpaid',
  payment_submitted: 'Payment Submitted',
  verified: 'Verified',
  rejected: 'Rejected',
  refunded: 'Refunded',
};

export const PAYMENT_STATUS_COLORS: Record<string, string> = {
  unpaid: 'bg-amber-100 text-amber-800 border-amber-200',
  payment_submitted: 'bg-blue-100 text-blue-800 border-blue-200',
  verified: 'bg-green-100 text-green-800 border-green-200',
  rejected: 'bg-red-100 text-red-800 border-red-200',
  refunded: 'bg-gray-100 text-gray-800 border-gray-200',
};

export const TICKET_STATUS_LABELS: Record<string, string> = {
  open: 'Open',
  in_progress: 'In Progress',
  resolved: 'Resolved',
  closed: 'Closed',
};

export const TICKET_STATUS_COLORS: Record<string, string> = {
  open: 'bg-amber-100 text-amber-800 border-amber-200',
  in_progress: 'bg-blue-100 text-blue-800 border-blue-200',
  resolved: 'bg-green-100 text-green-800 border-green-200',
  closed: 'bg-gray-100 text-gray-800 border-gray-200',
};

export function calculatePlatformFee(subtotal: number, percentage: number): number {
  return Math.round(subtotal * percentage) / 100;
}

export function calculateOrderTotal(
  materialSubtotal: number,
  deliveryCharge: number,
  platformFee: number,
  otherCharges: number = 0
): number {
  return materialSubtotal + deliveryCharge + platformFee + otherCharges;
}
