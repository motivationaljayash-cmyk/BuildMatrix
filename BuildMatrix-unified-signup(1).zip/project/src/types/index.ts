export type UserRole = 'buyer' | 'seller' | 'transporter' | 'admin';

export interface Profile {
  id: string;
  full_name: string;
  phone: string | null;
  role: UserRole;
  avatar_url: string | null;
  created_at: string;
  updated_at: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  icon: string | null;
  sort_order: number;
  is_active: boolean;
}

export interface SellerProfile {
  id: string;
  user_id: string;
  owner_name: string;
  business_name: string;
  phone: string;
  email: string;
  business_address: string;
  city: string;
  state: string;
  pin_code: string;
  gst_number: string | null;
  business_registration_info: string | null;
  business_description: string | null;
  bank_account_name: string | null;
  bank_account_number: string | null;
  bank_ifsc: string | null;
  bank_name: string | null;
  upi_id: string | null;
  verification_status: 'pending' | 'approved' | 'rejected' | 'suspended' | 'more_information_required';
  verification_notes: string | null;
  rejection_reason: string | null;
  approved_at: string | null;
  approved_by: string | null;
  rejected_at: string | null;
  rejected_by: string | null;
  info_requested_at: string | null;
  info_requested_by: string | null;
  info_request_message: string | null;
  latitude: number | null;
  longitude: number | null;
  delivery_radius_km: number;
  is_delivery_available: boolean;
  created_at: string;
  updated_at: string;
}

export interface SellerAuditLog {
  id: string;
  seller_id: string;
  admin_id: string;
  action: 'approve' | 'reject' | 'request_info' | 'suspend' | 'unsuspend';
  message: string | null;
  previous_status: string;
  new_status: string;
  created_at: string;
}

export interface TransporterProfile {
  id: string;
  user_id: string;
  name: string;
  phone: string;
  email: string;
  service_area: string;
  base_delivery_charge: number;
  additional_distance_charge: number;
  verification_status: 'pending' | 'approved' | 'rejected' | 'suspended';
  verification_notes: string | null;
  latitude: number | null;
  longitude: number | null;
  created_at: string;
  updated_at: string;
}

export interface Vehicle {
  id: string;
  transporter_id: string;
  vehicle_type: 'truck' | 'pickup' | 'mini_truck' | 'tractor' | 'trailer' | 'other';
  vehicle_number: string;
  vehicle_capacity: string;
  is_active: boolean;
}

export interface Product {
  id: string;
  seller_id: string;
  category_id: string | null;
  name: string;
  brand: string | null;
  description: string | null;
  price: number;
  unit: string;
  min_order_quantity: number;
  stock_quantity: number;
  sku: string | null;
  delivery_radius_km: number;
  is_delivery_available: boolean;
  estimated_delivery_days: string | null;
  status: 'draft' | 'pending_approval' | 'active' | 'out_of_stock' | 'rejected' | 'disabled';
  rejection_reason: string | null;
  created_at: string;
  updated_at: string;
  category?: Category;
  seller?: SellerProfile;
  product_images?: ProductImage[];
}

export interface ProductImage {
  id: string;
  product_id: string;
  image_url: string;
  sort_order: number;
}

export interface ProductSpec {
  id: string;
  product_id: string;
  spec_key: string;
  spec_value: string;
}

export interface Cart {
  id: string;
  user_id: string;
  seller_id: string | null;
  created_at: string;
  updated_at: string;
  cart_items?: CartItem[];
  seller?: SellerProfile;
}

export interface CartItem {
  id: string;
  cart_id: string;
  product_id: string;
  quantity: number;
  product?: Product;
}

export interface Address {
  id: string;
  user_id: string;
  label: string | null;
  recipient_name: string;
  phone: string;
  address_line1: string;
  address_line2: string | null;
  city: string;
  state: string;
  pin_code: string;
  latitude: number | null;
  longitude: number | null;
  is_default: boolean;
}

export interface Order {
  id: string;
  buyer_id: string;
  seller_id: string;
  delivery_address_id: string | null;
  material_subtotal: number;
  delivery_charge: number;
  platform_fee_percentage: number;
  platform_fee_amount: number;
  other_charges: number;
  final_total: number;
  status: OrderStatus;
  payment_method: string;
  delivery_option: string;
  notes: string | null;
  created_at: string;
  updated_at: string;
  order_items?: OrderItem[];
  seller?: SellerProfile;
  delivery_address?: Address;
  payments?: Payment[];
  delivery?: Delivery;
}

export type OrderStatus =
  | 'pending_payment'
  | 'payment_submitted'
  | 'payment_verification'
  | 'confirmed'
  | 'seller_accepted'
  | 'processing'
  | 'ready_for_pickup'
  | 'transport_assigned'
  | 'out_for_delivery'
  | 'delivered'
  | 'completed'
  | 'cancelled'
  | 'refunded'
  | 'disputed';

export interface OrderItem {
  id: string;
  order_id: string;
  product_id: string;
  product_name: string;
  quantity: number;
  unit_price: number;
  unit: string;
  subtotal: number;
}

export interface Payment {
  id: string;
  order_id: string;
  buyer_id: string;
  payment_method: string;
  amount: number;
  status: 'unpaid' | 'payment_submitted' | 'verified' | 'rejected' | 'refunded';
  verified_by: string | null;
  verified_at: string | null;
  rejection_reason: string | null;
  created_at: string;
  updated_at: string;
  payment_proofs?: PaymentProof[];
}

export interface PaymentProof {
  id: string;
  payment_id: string;
  screenshot_url: string;
  transaction_reference: string | null;
  notes: string | null;
  created_at: string;
}

export interface Delivery {
  id: string;
  order_id: string;
  transporter_id: string | null;
  pickup_address: string | null;
  delivery_address: string | null;
  material_description: string | null;
  approximate_weight: string | null;
  required_vehicle_capacity: string | null;
  preferred_delivery_time: string | null;
  delivery_charge: number;
  status: 'available' | 'accepted' | 'pickup' | 'in_transit' | 'delivered' | 'cancelled';
  created_at: string;
  updated_at: string;
  transporter?: TransporterProfile;
  order?: Order;
}

export interface Review {
  id: string;
  order_id: string;
  buyer_id: string;
  product_id: string | null;
  seller_id: string | null;
  delivery_id: string | null;
  review_type: 'product' | 'seller' | 'delivery';
  rating: number;
  comment: string | null;
  created_at: string;
}

export interface Notification {
  id: string;
  user_id: string;
  title: string;
  message: string;
  type: string | null;
  is_read: boolean;
  link: string | null;
  created_at: string;
}

export interface SupportTicket {
  id: string;
  user_id: string;
  subject: string;
  description: string;
  category: string | null;
  status: 'open' | 'in_progress' | 'resolved' | 'closed';
  priority: string;
  created_at: string;
  updated_at: string;
  support_ticket_replies?: SupportTicketReply[];
}

export interface SupportTicketReply {
  id: string;
  ticket_id: string;
  user_id: string;
  message: string;
  is_staff_reply: boolean;
  created_at: string;
}

export interface Commission {
  id: string;
  order_id: string;
  commission_percentage: number;
  commission_amount: number;
  seller_settlement_amount: number;
  transport_charge: number;
  transporter_settlement: number;
  other_charges: number;
  status: 'pending' | 'settled' | 'cancelled';
}

export interface Settlement {
  id: string;
  seller_id: string | null;
  transporter_id: string | null;
  order_id: string;
  amount: number;
  type: 'seller' | 'transporter';
  status: 'pending' | 'processed' | 'failed';
}

export interface PlatformSettings {
  id: number;
  platform_name: string;
  tagline: string;
  support_email: string | null;
  support_phone: string | null;
  commission_percentage: number;
  upi_id: string | null;
  upi_qr_image_url: string | null;
  payment_instructions: string | null;
  logo_url: string | null;
}
