/*
# BuildMarket Core Schema - Part 2: Products, Carts, Orders, Payments, Deliveries

This migration creates the marketplace transaction tables.

## New Tables
- `products` — Seller products with price, stock, category, status
- `product_images` — Multiple images per product
- `product_specs` — Key-value product specifications
- `carts` — Buyer carts (one seller per cart for MVP)
- `cart_items` — Items in a cart with quantity
- `orders` — Order with material subtotal, delivery charge, platform fee, total, status
- `order_items` — Individual product line items in an order
- `payments` — Payment records (manual UPI)
- `payment_proofs` — Uploaded payment screenshots and reference IDs
- `deliveries` — Delivery jobs for transporters
- `reviews` — Buyer reviews for products, sellers, and deliveries
- `notifications` — In-app notifications
- `support_tickets` — Support tickets and replies
- `commissions` — Commission records per order
- `settlements` — Seller and transporter settlements

## Security
- RLS enabled on all tables with owner-scoped policies
*/

-- ============ PRODUCTS ============
CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  seller_id uuid NOT NULL REFERENCES seller_profiles(id) ON DELETE CASCADE,
  category_id uuid REFERENCES categories(id) ON DELETE SET NULL,
  name text NOT NULL,
  brand text,
  description text,
  price numeric(10,2) NOT NULL,
  unit text NOT NULL,
  min_order_quantity numeric(10,2) DEFAULT 1,
  stock_quantity numeric(10,2) NOT NULL DEFAULT 0,
  sku text,
  delivery_radius_km int DEFAULT 10,
  is_delivery_available boolean DEFAULT true,
  estimated_delivery_days text,
  status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'pending_approval', 'active', 'out_of_stock', 'rejected', 'disabled')),
  rejection_reason text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE products ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_read_active_products" ON products;
CREATE POLICY "anon_read_active_products" ON products FOR SELECT
  TO anon, authenticated
  USING (
    status = 'active'
    AND EXISTS (
      SELECT 1 FROM seller_profiles sp
      WHERE sp.id = products.seller_id
      AND sp.verification_status = 'approved'
    )
  );

DROP POLICY IF EXISTS "seller_read_own_products" ON products;
CREATE POLICY "seller_read_own_products" ON products FOR SELECT
  TO authenticated USING (
    EXISTS (
      SELECT 1 FROM seller_profiles sp
      WHERE sp.id = products.seller_id AND sp.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS "seller_insert_own_products" ON products;
CREATE POLICY "seller_insert_own_products" ON products FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (
      SELECT 1 FROM seller_profiles sp
      WHERE sp.id = products.seller_id AND sp.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS "seller_update_own_products" ON products;
CREATE POLICY "seller_update_own_products" ON products FOR UPDATE
  TO authenticated USING (
    EXISTS (
      SELECT 1 FROM seller_profiles sp
      WHERE sp.id = products.seller_id AND sp.user_id = auth.uid()
    )
  ) WITH CHECK (
    EXISTS (
      SELECT 1 FROM seller_profiles sp
      WHERE sp.id = products.seller_id AND sp.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS "seller_delete_own_products" ON products;
CREATE POLICY "seller_delete_own_products" ON products FOR DELETE
  TO authenticated USING (
    EXISTS (
      SELECT 1 FROM seller_profiles sp
      WHERE sp.id = products.seller_id AND sp.user_id = auth.uid()
    )
  );

-- ============ PRODUCT_IMAGES ============
CREATE TABLE IF NOT EXISTS product_images (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  image_url text NOT NULL,
  sort_order int DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE product_images ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_read_product_images" ON product_images;
CREATE POLICY "anon_read_product_images" ON product_images FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "seller_manage_own_product_images" ON product_images;
CREATE POLICY "seller_manage_own_product_images" ON product_images FOR ALL
  TO authenticated USING (
    EXISTS (
      SELECT 1 FROM products p
      JOIN seller_profiles sp ON sp.id = p.seller_id
      WHERE p.id = product_images.product_id AND sp.user_id = auth.uid()
    )
  ) WITH CHECK (
    EXISTS (
      SELECT 1 FROM products p
      JOIN seller_profiles sp ON sp.id = p.seller_id
      WHERE p.id = product_images.product_id AND sp.user_id = auth.uid()
    )
  );

-- ============ PRODUCT_SPECS ============
CREATE TABLE IF NOT EXISTS product_specs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  spec_key text NOT NULL,
  spec_value text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE product_specs ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_read_product_specs" ON product_specs;
CREATE POLICY "anon_read_product_specs" ON product_specs FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "seller_manage_own_product_specs" ON product_specs;
CREATE POLICY "seller_manage_own_product_specs" ON product_specs FOR ALL
  TO authenticated USING (
    EXISTS (
      SELECT 1 FROM products p
      JOIN seller_profiles sp ON sp.id = p.seller_id
      WHERE p.id = product_specs.product_id AND sp.user_id = auth.uid()
    )
  ) WITH CHECK (
    EXISTS (
      SELECT 1 FROM products p
      JOIN seller_profiles sp ON sp.id = p.seller_id
      WHERE p.id = product_specs.product_id AND sp.user_id = auth.uid()
    )
  );

-- ============ CARTS ============
CREATE TABLE IF NOT EXISTS carts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  seller_id uuid REFERENCES seller_profiles(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE carts ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_carts" ON carts;
CREATE POLICY "select_own_carts" ON carts FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_carts" ON carts;
CREATE POLICY "insert_own_carts" ON carts FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_carts" ON carts;
CREATE POLICY "update_own_carts" ON carts FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_carts" ON carts;
CREATE POLICY "delete_own_carts" ON carts FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- ============ CART_ITEMS ============
CREATE TABLE IF NOT EXISTS cart_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  cart_id uuid NOT NULL REFERENCES carts(id) ON DELETE CASCADE,
  product_id uuid NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  quantity numeric(10,2) NOT NULL DEFAULT 1,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE cart_items ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_cart_items" ON cart_items;
CREATE POLICY "select_own_cart_items" ON cart_items FOR SELECT
  TO authenticated USING (
    EXISTS (SELECT 1 FROM carts c WHERE c.id = cart_id AND c.user_id = auth.uid())
  );

DROP POLICY IF EXISTS "insert_own_cart_items" ON cart_items;
CREATE POLICY "insert_own_cart_items" ON cart_items FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM carts c WHERE c.id = cart_id AND c.user_id = auth.uid())
  );

DROP POLICY IF EXISTS "update_own_cart_items" ON cart_items;
CREATE POLICY "update_own_cart_items" ON cart_items FOR UPDATE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM carts c WHERE c.id = cart_id AND c.user_id = auth.uid())
  );

DROP POLICY IF EXISTS "delete_own_cart_items" ON cart_items;
CREATE POLICY "delete_own_cart_items" ON cart_items FOR DELETE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM carts c WHERE c.id = cart_id AND c.user_id = auth.uid())
  );

-- ============ ORDERS ============
CREATE TABLE IF NOT EXISTS orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  buyer_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  seller_id uuid NOT NULL REFERENCES seller_profiles(id) ON DELETE CASCADE,
  delivery_address_id uuid REFERENCES addresses(id) ON DELETE SET NULL,
  material_subtotal numeric(10,2) NOT NULL DEFAULT 0,
  delivery_charge numeric(10,2) NOT NULL DEFAULT 0,
  platform_fee_percentage numeric(5,2) NOT NULL DEFAULT 4.00,
  platform_fee_amount numeric(10,2) NOT NULL DEFAULT 0,
  other_charges numeric(10,2) NOT NULL DEFAULT 0,
  final_total numeric(10,2) NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'pending_payment' CHECK (status IN (
    'pending_payment', 'payment_submitted', 'payment_verification',
    'confirmed', 'seller_accepted', 'processing', 'ready_for_pickup',
    'transport_assigned', 'out_for_delivery', 'delivered', 'completed',
    'cancelled', 'refunded', 'disputed'
  )),
  payment_method text DEFAULT 'manual_upi',
  delivery_option text DEFAULT 'standard',
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE orders ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "buyer_read_own_orders" ON orders;
CREATE POLICY "buyer_read_own_orders" ON orders FOR SELECT
  TO authenticated USING (auth.uid() = buyer_id);

DROP POLICY IF EXISTS "seller_read_own_orders" ON orders;
CREATE POLICY "seller_read_own_orders" ON orders FOR SELECT
  TO authenticated USING (
    EXISTS (SELECT 1 FROM seller_profiles sp WHERE sp.id = orders.seller_id AND sp.user_id = auth.uid())
  );

DROP POLICY IF EXISTS "buyer_insert_own_orders" ON orders;
CREATE POLICY "buyer_insert_own_orders" ON orders FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = buyer_id);

DROP POLICY IF EXISTS "buyer_update_own_orders" ON orders;
CREATE POLICY "buyer_update_own_orders" ON orders FOR UPDATE
  TO authenticated USING (auth.uid() = buyer_id) WITH CHECK (auth.uid() = buyer_id);

DROP POLICY IF EXISTS "seller_update_own_orders" ON orders;
CREATE POLICY "seller_update_own_orders" ON orders FOR UPDATE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM seller_profiles sp WHERE sp.id = orders.seller_id AND sp.user_id = auth.uid())
  ) WITH CHECK (
    EXISTS (SELECT 1 FROM seller_profiles sp WHERE sp.id = orders.seller_id AND sp.user_id = auth.uid())
  );

-- ============ ORDER_ITEMS ============
CREATE TABLE IF NOT EXISTS order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id uuid NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  product_name text NOT NULL,
  quantity numeric(10,2) NOT NULL,
  unit_price numeric(10,2) NOT NULL,
  unit text NOT NULL,
  subtotal numeric(10,2) NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE order_items ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "buyer_read_own_order_items" ON order_items;
CREATE POLICY "buyer_read_own_order_items" ON order_items FOR SELECT
  TO authenticated USING (
    EXISTS (SELECT 1 FROM orders o WHERE o.id = order_id AND o.buyer_id = auth.uid())
  );

DROP POLICY IF EXISTS "seller_read_own_order_items" ON order_items;
CREATE POLICY "seller_read_own_order_items" ON order_items FOR SELECT
  TO authenticated USING (
    EXISTS (
      SELECT 1 FROM orders o
      JOIN seller_profiles sp ON sp.id = o.seller_id
      WHERE o.id = order_id AND sp.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS "buyer_insert_own_order_items" ON order_items;
CREATE POLICY "buyer_insert_own_order_items" ON order_items FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM orders o WHERE o.id = order_id AND o.buyer_id = auth.uid())
  );

-- ============ PAYMENTS ============
CREATE TABLE IF NOT EXISTS payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  buyer_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  payment_method text NOT NULL DEFAULT 'manual_upi',
  amount numeric(10,2) NOT NULL,
  status text NOT NULL DEFAULT 'unpaid' CHECK (status IN ('unpaid', 'payment_submitted', 'verified', 'rejected', 'refunded')),
  verified_by uuid,
  verified_at timestamptz,
  rejection_reason text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE payments ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "buyer_read_own_payments" ON payments;
CREATE POLICY "buyer_read_own_payments" ON payments FOR SELECT
  TO authenticated USING (auth.uid() = buyer_id);

DROP POLICY IF EXISTS "seller_read_order_payments" ON payments;
CREATE POLICY "seller_read_order_payments" ON payments FOR SELECT
  TO authenticated USING (
    EXISTS (
      SELECT 1 FROM orders o
      JOIN seller_profiles sp ON sp.id = o.seller_id
      WHERE o.id = payments.order_id AND sp.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS "buyer_insert_own_payments" ON payments;
CREATE POLICY "buyer_insert_own_payments" ON payments FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = buyer_id);

DROP POLICY IF EXISTS "buyer_update_own_payments" ON payments;
CREATE POLICY "buyer_update_own_payments" ON payments FOR UPDATE
  TO authenticated USING (auth.uid() = buyer_id) WITH CHECK (auth.uid() = buyer_id);

-- ============ PAYMENT_PROOFS ============
CREATE TABLE IF NOT EXISTS payment_proofs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  payment_id uuid NOT NULL REFERENCES payments(id) ON DELETE CASCADE,
  screenshot_url text NOT NULL,
  transaction_reference text,
  notes text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE payment_proofs ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "buyer_read_own_payment_proofs" ON payment_proofs;
CREATE POLICY "buyer_read_own_payment_proofs" ON payment_proofs FOR SELECT
  TO authenticated USING (
    EXISTS (SELECT 1 FROM payments p WHERE p.id = payment_id AND p.buyer_id = auth.uid())
  );

DROP POLICY IF EXISTS "seller_read_order_payment_proofs" ON payment_proofs;
CREATE POLICY "seller_read_order_payment_proofs" ON payment_proofs FOR SELECT
  TO authenticated USING (
    EXISTS (
      SELECT 1 FROM payments p
      JOIN orders o ON o.id = p.order_id
      JOIN seller_profiles sp ON sp.id = o.seller_id
      WHERE p.id = payment_id AND sp.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS "buyer_insert_own_payment_proofs" ON payment_proofs;
CREATE POLICY "buyer_insert_own_payment_proofs" ON payment_proofs FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM payments p WHERE p.id = payment_id AND p.buyer_id = auth.uid())
  );

-- ============ DELIVERIES ============
CREATE TABLE IF NOT EXISTS deliveries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  transporter_id uuid REFERENCES transporter_profiles(id) ON DELETE SET NULL,
  pickup_address text,
  delivery_address text,
  material_description text,
  approximate_weight text,
  required_vehicle_capacity text,
  preferred_delivery_time text,
  delivery_charge numeric(10,2) DEFAULT 0,
  status text NOT NULL DEFAULT 'available' CHECK (status IN ('available', 'accepted', 'pickup', 'in_transit', 'delivered', 'cancelled')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE deliveries ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "buyer_read_own_deliveries" ON deliveries;
CREATE POLICY "buyer_read_own_deliveries" ON deliveries FOR SELECT
  TO authenticated USING (
    EXISTS (SELECT 1 FROM orders o WHERE o.id = deliveries.order_id AND o.buyer_id = auth.uid())
  );

DROP POLICY IF EXISTS "transporter_read_deliveries" ON deliveries;
CREATE POLICY "transporter_read_deliveries" ON deliveries FOR SELECT
  TO authenticated USING (
    deliveries.status = 'available'
    OR (
      deliveries.transporter_id IS NOT NULL
      AND EXISTS (
        SELECT 1 FROM transporter_profiles tp WHERE tp.id = deliveries.transporter_id AND tp.user_id = auth.uid()
      )
    )
  );

DROP POLICY IF EXISTS "seller_read_order_deliveries" ON deliveries;
CREATE POLICY "seller_read_order_deliveries" ON deliveries FOR SELECT
  TO authenticated USING (
    EXISTS (
      SELECT 1 FROM orders o
      JOIN seller_profiles sp ON sp.id = o.seller_id
      WHERE o.id = deliveries.order_id AND sp.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS "transporter_update_own_deliveries" ON deliveries;
CREATE POLICY "transporter_update_own_deliveries" ON deliveries FOR UPDATE
  TO authenticated USING (
    deliveries.transporter_id IS NOT NULL
    AND EXISTS (
      SELECT 1 FROM transporter_profiles tp WHERE tp.id = deliveries.transporter_id AND tp.user_id = auth.uid()
    )
  ) WITH CHECK (
    deliveries.transporter_id IS NOT NULL
    AND EXISTS (
      SELECT 1 FROM transporter_profiles tp WHERE tp.id = deliveries.transporter_id AND tp.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS "buyer_insert_own_deliveries" ON deliveries;
CREATE POLICY "buyer_insert_own_deliveries" ON deliveries FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM orders o WHERE o.id = deliveries.order_id AND o.buyer_id = auth.uid())
  );

DROP POLICY IF EXISTS "transporter_accept_deliveries" ON deliveries;
CREATE POLICY "transporter_accept_deliveries" ON deliveries FOR UPDATE
  TO authenticated USING (deliveries.status = 'available')
  WITH CHECK (
    deliveries.transporter_id IS NOT NULL
    AND EXISTS (
      SELECT 1 FROM transporter_profiles tp WHERE tp.id = deliveries.transporter_id AND tp.user_id = auth.uid()
    )
  );

-- ============ REVIEWS ============
CREATE TABLE IF NOT EXISTS reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  buyer_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  product_id uuid REFERENCES products(id) ON DELETE CASCADE,
  seller_id uuid REFERENCES seller_profiles(id) ON DELETE CASCADE,
  delivery_id uuid REFERENCES deliveries(id) ON DELETE CASCADE,
  review_type text NOT NULL CHECK (review_type IN ('product', 'seller', 'delivery')),
  rating int NOT NULL CHECK (rating >= 1 AND rating <= 5),
  comment text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_read_reviews" ON reviews;
CREATE POLICY "anon_read_reviews" ON reviews FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "buyer_insert_own_reviews" ON reviews;
CREATE POLICY "buyer_insert_own_reviews" ON reviews FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = buyer_id);

-- ============ NOTIFICATIONS ============
CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL,
  message text NOT NULL,
  type text,
  is_read boolean DEFAULT false,
  link text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_notifications" ON notifications;
CREATE POLICY "select_own_notifications" ON notifications FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_notifications" ON notifications;
CREATE POLICY "insert_own_notifications" ON notifications FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_notifications" ON notifications;
CREATE POLICY "update_own_notifications" ON notifications FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_notifications" ON notifications;
CREATE POLICY "delete_own_notifications" ON notifications FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- ============ SUPPORT_TICKETS ============
CREATE TABLE IF NOT EXISTS support_tickets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  subject text NOT NULL,
  description text NOT NULL,
  category text,
  status text NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'in_progress', 'resolved', 'closed')),
  priority text DEFAULT 'normal',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE support_tickets ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_tickets" ON support_tickets;
CREATE POLICY "select_own_tickets" ON support_tickets FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_tickets" ON support_tickets;
CREATE POLICY "insert_own_tickets" ON support_tickets FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_tickets" ON support_tickets;
CREATE POLICY "update_own_tickets" ON support_tickets FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- ============ SUPPORT_TICKET_REPLIES ============
CREATE TABLE IF NOT EXISTS support_ticket_replies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ticket_id uuid NOT NULL REFERENCES support_tickets(id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  message text NOT NULL,
  is_staff_reply boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE support_ticket_replies ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_ticket_replies" ON support_ticket_replies;
CREATE POLICY "select_own_ticket_replies" ON support_ticket_replies FOR SELECT
  TO authenticated USING (
    EXISTS (SELECT 1 FROM support_tickets t WHERE t.id = ticket_id AND t.user_id = auth.uid())
  );

DROP POLICY IF EXISTS "insert_own_ticket_replies" ON support_ticket_replies;
CREATE POLICY "insert_own_ticket_replies" ON support_ticket_replies FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM support_tickets t WHERE t.id = ticket_id AND t.user_id = auth.uid())
  );

-- ============ COMMISSIONS ============
CREATE TABLE IF NOT EXISTS commissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  commission_percentage numeric(5,2) NOT NULL,
  commission_amount numeric(10,2) NOT NULL,
  seller_settlement_amount numeric(10,2) NOT NULL,
  transport_charge numeric(10,2) DEFAULT 0,
  transporter_settlement numeric(10,2) DEFAULT 0,
  other_charges numeric(10,2) DEFAULT 0,
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'settled', 'cancelled')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE commissions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "buyer_read_own_commissions" ON commissions;
CREATE POLICY "buyer_read_own_commissions" ON commissions FOR SELECT
  TO authenticated USING (
    EXISTS (SELECT 1 FROM orders o WHERE o.id = commissions.order_id AND o.buyer_id = auth.uid())
  );

DROP POLICY IF EXISTS "seller_read_own_commissions" ON commissions;
CREATE POLICY "seller_read_own_commissions" ON commissions FOR SELECT
  TO authenticated USING (
    EXISTS (
      SELECT 1 FROM orders o
      JOIN seller_profiles sp ON sp.id = o.seller_id
      WHERE o.id = commissions.order_id AND sp.user_id = auth.uid()
    )
  );

-- ============ SETTLEMENTS ============
CREATE TABLE IF NOT EXISTS settlements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  seller_id uuid REFERENCES seller_profiles(id) ON DELETE SET NULL,
  transporter_id uuid REFERENCES transporter_profiles(id) ON DELETE SET NULL,
  order_id uuid REFERENCES orders(id) ON DELETE CASCADE,
  amount numeric(10,2) NOT NULL,
  type text NOT NULL CHECK (type IN ('seller', 'transporter')),
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'processed', 'failed')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE settlements ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "seller_read_own_settlements" ON settlements;
CREATE POLICY "seller_read_own_settlements" ON settlements FOR SELECT
  TO authenticated USING (
    seller_id IS NOT NULL AND EXISTS (
      SELECT 1 FROM seller_profiles sp WHERE sp.id = settlements.seller_id AND sp.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS "transporter_read_own_settlements" ON settlements;
CREATE POLICY "transporter_read_own_settlements" ON settlements FOR SELECT
  TO authenticated USING (
    transporter_id IS NOT NULL AND EXISTS (
      SELECT 1 FROM transporter_profiles tp WHERE tp.id = settlements.transporter_id AND tp.user_id = auth.uid()
    )
  );

-- ============ TRIGGERS ============
DO $$ BEGIN
  CREATE TRIGGER update_products_updated_at BEFORE UPDATE ON products FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TRIGGER update_carts_updated_at BEFORE UPDATE ON carts FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TRIGGER update_orders_updated_at BEFORE UPDATE ON orders FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TRIGGER update_payments_updated_at BEFORE UPDATE ON payments FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TRIGGER update_deliveries_updated_at BEFORE UPDATE ON deliveries FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TRIGGER update_support_tickets_updated_at BEFORE UPDATE ON support_tickets FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TRIGGER update_commissions_updated_at BEFORE UPDATE ON commissions FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TRIGGER update_settlements_updated_at BEFORE UPDATE ON settlements FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- ============ INDEXES ============
CREATE INDEX IF NOT EXISTS idx_products_seller_id ON products(seller_id);
CREATE INDEX IF NOT EXISTS idx_products_category_id ON products(category_id);
CREATE INDEX IF NOT EXISTS idx_products_status ON products(status);
CREATE INDEX IF NOT EXISTS idx_product_images_product_id ON product_images(product_id);
CREATE INDEX IF NOT EXISTS idx_cart_items_cart_id ON cart_items(cart_id);
CREATE INDEX IF NOT EXISTS idx_orders_buyer_id ON orders(buyer_id);
CREATE INDEX IF NOT EXISTS idx_orders_seller_id ON orders(seller_id);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
CREATE INDEX IF NOT EXISTS idx_order_items_order_id ON order_items(order_id);
CREATE INDEX IF NOT EXISTS idx_payments_order_id ON payments(order_id);
CREATE INDEX IF NOT EXISTS idx_payments_buyer_id ON payments(buyer_id);
CREATE INDEX IF NOT EXISTS idx_deliveries_order_id ON deliveries(order_id);
CREATE INDEX IF NOT EXISTS idx_deliveries_transporter_id ON deliveries(transporter_id);
CREATE INDEX IF NOT EXISTS idx_deliveries_status ON deliveries(status);
CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_support_tickets_user_id ON support_tickets(user_id);
CREATE INDEX IF NOT EXISTS idx_commissions_order_id ON commissions(order_id);
CREATE INDEX IF NOT EXISTS idx_settlements_seller_id ON settlements(seller_id);
CREATE INDEX IF NOT EXISTS idx_settlements_transporter_id ON settlements(transporter_id);