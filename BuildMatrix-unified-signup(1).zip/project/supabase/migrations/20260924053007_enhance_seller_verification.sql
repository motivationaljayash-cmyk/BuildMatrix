/*
# Seller Verification System Enhancement

This migration adds the "MORE_INFORMATION_REQUIRED" seller status, audit logging for admin actions on sellers, and additional verification tracking columns.

## Changes to seller_profiles
- Add `rejection_reason` text — stores admin's rejection reason
- Add `approved_at` timestamptz — when the seller was approved
- Add `approved_by` uuid — which admin approved (references auth.users)
- Add `rejected_at` timestamptz — when the seller was rejected
- Add `rejected_by` uuid — which admin rejected (references auth.users)
- Add `info_requested_at` timestamptz — when more info was requested
- Add `info_requested_by` uuid — which admin requested info
- Add `info_request_message` text — the message from admin about what info is needed
- Update verification_status CHECK constraint to include 'more_information_required'

## New Tables
- `seller_audit_logs` — records every admin action on a seller (approve, reject, request_info, suspend)
  - `id`, `seller_id`, `admin_id`, `action`, `reason/message`, `previous_status`, `new_status`, `created_at`

## Security
- RLS on seller_audit_logs: admin-only read/write
- seller_profiles update policy: already restricted to owner (self) + admin via existing policies
- Sellers can never change their own verification_status (no policy allows it — only admin policies allow verification_status changes)
*/

-- ============ ADD COLUMNS TO seller_profiles ============
ALTER TABLE seller_profiles ADD COLUMN IF NOT EXISTS rejection_reason text;
ALTER TABLE seller_profiles ADD COLUMN IF NOT EXISTS approved_at timestamptz;
ALTER TABLE seller_profiles ADD COLUMN IF NOT EXISTS approved_by uuid;
ALTER TABLE seller_profiles ADD COLUMN IF NOT EXISTS rejected_at timestamptz;
ALTER TABLE seller_profiles ADD COLUMN IF NOT EXISTS rejected_by uuid;
ALTER TABLE seller_profiles ADD COLUMN IF NOT EXISTS info_requested_at timestamptz;
ALTER TABLE seller_profiles ADD COLUMN IF NOT EXISTS info_requested_by uuid;
ALTER TABLE seller_profiles ADD COLUMN IF NOT EXISTS info_request_message text;

-- ============ UPDATE verification_status CHECK CONSTRAINT ============
ALTER TABLE seller_profiles DROP CONSTRAINT IF EXISTS seller_profiles_verification_status_check;
ALTER TABLE seller_profiles ADD CONSTRAINT seller_profiles_verification_status_check
  CHECK (verification_status IN ('pending', 'approved', 'rejected', 'suspended', 'more_information_required'));

-- ============ SELLER_AUDIT_LOGS TABLE ============
CREATE TABLE IF NOT EXISTS seller_audit_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  seller_id uuid NOT NULL REFERENCES seller_profiles(id) ON DELETE CASCADE,
  admin_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE SET NULL,
  action text NOT NULL CHECK (action IN ('approve', 'reject', 'request_info', 'suspend', 'unsuspend')),
  message text,
  previous_status text NOT NULL,
  new_status text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE seller_audit_logs ENABLE ROW LEVEL SECURITY;

-- Only admins can read audit logs
DROP POLICY IF EXISTS "admin_read_seller_audit_logs" ON seller_audit_logs;
CREATE POLICY "admin_read_seller_audit_logs" ON seller_audit_logs FOR SELECT
  TO authenticated USING (is_admin());

-- Only admins can insert audit logs
DROP POLICY IF EXISTS "admin_insert_seller_audit_logs" ON seller_audit_logs;
CREATE POLICY "admin_insert_seller_audit_logs" ON seller_audit_logs FOR INSERT
  TO authenticated WITH CHECK (is_admin());

-- Sellers can read their own audit logs (so they can see who approved them and when)
DROP POLICY IF EXISTS "seller_read_own_audit_logs" ON seller_audit_logs;
CREATE POLICY "seller_read_own_audit_logs" ON seller_audit_logs FOR SELECT
  TO authenticated USING (
    EXISTS (
      SELECT 1 FROM seller_profiles sp
      WHERE sp.id = seller_audit_logs.seller_id AND sp.user_id = auth.uid()
    )
  );

-- ============ INDEX ============
CREATE INDEX IF NOT EXISTS idx_seller_audit_logs_seller_id ON seller_audit_logs(seller_id);
CREATE INDEX IF NOT EXISTS idx_seller_audit_logs_created_at ON seller_audit_logs(created_at);

-- ============ TRIGGER for updated_at ============
DO $$ BEGIN
  CREATE TRIGGER update_seller_audit_logs_updated_at BEFORE UPDATE ON seller_audit_logs FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
EXCEPTION WHEN duplicate_object THEN NULL; END $$;