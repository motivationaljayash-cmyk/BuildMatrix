/*
# BuildMarket Core Schema - Part 1: Profiles, Categories, Sellers, Transporters

This migration creates the foundational tables for the BuildMarket construction materials marketplace.

## New Tables
- `profiles` — Extended user data (phone, role, full_name) linked to auth.users
- `categories` — Construction material categories (cement, steel, sand, etc.)
- `seller_profiles` — Business information for sellers (business name, GST, address, verification status)
- `transporter_profiles` — Transporter business info (vehicle type, capacity, service area, verification status)
- `vehicles` — Transporter vehicles (type, number, capacity)

## Security
- RLS enabled on all tables
- Profiles: users can read/update their own profile
- Categories: public read (anon + authenticated), admin-only write
- Seller/Transporter profiles: owner read/write, admin read, public read of approved records
- Vehicles: owner CRUD, admin read, public read for approved transporters
*/

-- ============ PROFILES ============
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text NOT NULL,
  phone text,
  role text NOT NULL DEFAULT 'buyer' CHECK (role IN ('buyer', 'seller', 'transporter', 'admin')),
  avatar_url text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_profile" ON profiles;
CREATE POLICY "select_own_profile" ON profiles FOR SELECT
  TO authenticated USING (auth.uid() = id);

DROP POLICY IF EXISTS "insert_own_profile" ON profiles;
CREATE POLICY "insert_own_profile" ON profiles FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "update_own_profile" ON profiles;
CREATE POLICY "update_own_profile" ON profiles FOR UPDATE
  TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

-- ============ CATEGORIES ============
CREATE TABLE IF NOT EXISTS categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  slug text NOT NULL UNIQUE,
  description text,
  icon text,
  sort_order int DEFAULT 0,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE categories ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_read_categories" ON categories;
CREATE POLICY "anon_read_categories" ON categories FOR SELECT
  TO anon, authenticated USING (true);

-- ============ SELLER_PROFILES ============
CREATE TABLE IF NOT EXISTS seller_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  owner_name text NOT NULL,
  business_name text NOT NULL,
  phone text NOT NULL,
  email text NOT NULL,
  business_address text NOT NULL,
  city text NOT NULL,
  state text NOT NULL,
  pin_code text NOT NULL,
  gst_number text,
  business_registration_info text,
  business_description text,
  bank_account_name text,
  bank_account_number text,
  bank_ifsc text,
  bank_name text,
  upi_id text,
  verification_status text NOT NULL DEFAULT 'pending' CHECK (verification_status IN ('pending', 'approved', 'rejected', 'suspended')),
  verification_notes text,
  latitude numeric(10,7),
  longitude numeric(10,7),
  delivery_radius_km int DEFAULT 10,
  is_delivery_available boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE seller_profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_seller_profile" ON seller_profiles;
CREATE POLICY "select_own_seller_profile" ON seller_profiles FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_seller_profile" ON seller_profiles;
CREATE POLICY "insert_own_seller_profile" ON seller_profiles FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_seller_profile" ON seller_profiles;
CREATE POLICY "update_own_seller_profile" ON seller_profiles FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- ============ TRANSPORTER_PROFILES ============
CREATE TABLE IF NOT EXISTS transporter_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  phone text NOT NULL,
  email text NOT NULL,
  service_area text NOT NULL,
  base_delivery_charge numeric(10,2) DEFAULT 0,
  additional_distance_charge numeric(10,2) DEFAULT 0,
  verification_status text NOT NULL DEFAULT 'pending' CHECK (verification_status IN ('pending', 'approved', 'rejected', 'suspended')),
  verification_notes text,
  latitude numeric(10,7),
  longitude numeric(10,7),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE transporter_profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_transporter_profile" ON transporter_profiles;
CREATE POLICY "select_own_transporter_profile" ON transporter_profiles FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_transporter_profile" ON transporter_profiles;
CREATE POLICY "insert_own_transporter_profile" ON transporter_profiles FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_transporter_profile" ON transporter_profiles;
CREATE POLICY "update_own_transporter_profile" ON transporter_profiles FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- ============ VEHICLES ============
CREATE TABLE IF NOT EXISTS vehicles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  transporter_id uuid NOT NULL REFERENCES transporter_profiles(id) ON DELETE CASCADE,
  vehicle_type text NOT NULL CHECK (vehicle_type IN ('truck', 'pickup', 'mini_truck', 'tractor', 'trailer', 'other')),
  vehicle_number text NOT NULL,
  vehicle_capacity text NOT NULL,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE vehicles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_vehicles" ON vehicles;
CREATE POLICY "select_own_vehicles" ON vehicles FOR SELECT
  TO authenticated USING (
    EXISTS (SELECT 1 FROM transporter_profiles tp WHERE tp.id = transporter_id AND tp.user_id = auth.uid())
  );

DROP POLICY IF EXISTS "insert_own_vehicles" ON vehicles;
CREATE POLICY "insert_own_vehicles" ON vehicles FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM transporter_profiles tp WHERE tp.id = transporter_id AND tp.user_id = auth.uid())
  );

DROP POLICY IF EXISTS "update_own_vehicles" ON vehicles;
CREATE POLICY "update_own_vehicles" ON vehicles FOR UPDATE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM transporter_profiles tp WHERE tp.id = transporter_id AND tp.user_id = auth.uid())
  );

DROP POLICY IF EXISTS "delete_own_vehicles" ON vehicles;
CREATE POLICY "delete_own_vehicles" ON vehicles FOR DELETE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM transporter_profiles tp WHERE tp.id = transporter_id AND tp.user_id = auth.uid())
  );

-- ============ PLATFORM_SETTINGS ============
CREATE TABLE IF NOT EXISTS platform_settings (
  id int PRIMARY KEY DEFAULT 1,
  platform_name text DEFAULT 'BuildMarket',
  tagline text DEFAULT 'Construction Materials. Local Suppliers. Delivered.',
  support_email text,
  support_phone text,
  commission_percentage numeric(5,2) DEFAULT 4.00,
  upi_id text,
  upi_qr_image_url text,
  payment_instructions text,
  logo_url text,
  CONSTRAINT single_row CHECK (id = 1)
);

ALTER TABLE platform_settings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_read_platform_settings" ON platform_settings;
CREATE POLICY "anon_read_platform_settings" ON platform_settings FOR SELECT
  TO anon, authenticated USING (true);

-- ============ ADDRESSES ============
CREATE TABLE IF NOT EXISTS addresses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  label text,
  recipient_name text NOT NULL,
  phone text NOT NULL,
  address_line1 text NOT NULL,
  address_line2 text,
  city text NOT NULL,
  state text NOT NULL,
  pin_code text NOT NULL,
  latitude numeric(10,7),
  longitude numeric(10,7),
  is_default boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE addresses ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_addresses" ON addresses;
CREATE POLICY "select_own_addresses" ON addresses FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_addresses" ON addresses;
CREATE POLICY "insert_own_addresses" ON addresses FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_addresses" ON addresses;
CREATE POLICY "update_own_addresses" ON addresses FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_addresses" ON addresses;
CREATE POLICY "delete_own_addresses" ON addresses FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- ============ UPDATED_AT TRIGGER FUNCTION ============
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create triggers for all tables with updated_at
DO $$ BEGIN
  CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON profiles FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TRIGGER update_categories_updated_at BEFORE UPDATE ON categories FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TRIGGER update_seller_profiles_updated_at BEFORE UPDATE ON seller_profiles FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TRIGGER update_transporter_profiles_updated_at BEFORE UPDATE ON transporter_profiles FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TRIGGER update_vehicles_updated_at BEFORE UPDATE ON vehicles FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TRIGGER update_addresses_updated_at BEFORE UPDATE ON addresses FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- ============ INDEXES ============
CREATE INDEX IF NOT EXISTS idx_profiles_role ON profiles(role);
CREATE INDEX IF NOT EXISTS idx_seller_profiles_user_id ON seller_profiles(user_id);
CREATE INDEX IF NOT EXISTS idx_seller_profiles_verification_status ON seller_profiles(verification_status);
CREATE INDEX IF NOT EXISTS idx_transporter_profiles_user_id ON transporter_profiles(user_id);
CREATE INDEX IF NOT EXISTS idx_transporter_profiles_verification_status ON transporter_profiles(verification_status);
CREATE INDEX IF NOT EXISTS idx_vehicles_transporter_id ON vehicles(transporter_id);
CREATE INDEX IF NOT EXISTS idx_addresses_user_id ON addresses(user_id);

-- ============ SEED CATEGORIES ============
INSERT INTO categories (name, slug, description, icon, sort_order) VALUES
  ('Cement', 'cement', 'All types of cement including OPC, PPC, and rapid hardening cement', 'package', 1),
  ('Steel & TMT', 'steel-tmt', 'TMT bars, steel rods, and structural steel', 'layers', 2),
  ('Sand', 'sand', 'Construction sand including river sand, m-sand, and pit sand', 'mountain', 3),
  ('Bricks & Blocks', 'bricks-blocks', 'Clay bricks, fly ash bricks, AAC blocks, and concrete blocks', 'box', 4),
  ('Aggregates', 'aggregates', 'Coarse and fine aggregates for construction', 'layers', 5),
  ('Pipes & Plumbing', 'pipes-plumbing', 'PVC, CPVC, and metal pipes and plumbing materials', 'git-branch', 6),
  ('Tiles', 'tiles', 'Floor tiles, wall tiles, and marble', 'grid-3x3', 7),
  ('Paint', 'paint', 'Interior and exterior paints, primers, and coatings', 'paintbrush', 8),
  ('Electrical', 'electrical', 'Wires, switches, sockets, and electrical supplies', 'zap', 9),
  ('Hardware & Tools', 'hardware-tools', 'Tools, fasteners, and hardware supplies', 'wrench', 10),
  ('Construction Equipment', 'construction-equipment', 'Mixers, vibrators, and construction machinery', 'truck', 11),
  ('Other', 'other', 'Other construction materials', 'more-horizontal', 12)
ON CONFLICT (name) DO NOTHING;

-- ============ SEED PLATFORM SETTINGS ============
INSERT INTO platform_settings (id, platform_name, tagline, commission_percentage)
VALUES (1, 'BuildMarket', 'Construction Materials. Local Suppliers. Delivered.', 4.00)
ON CONFLICT (id) DO NOTHING;