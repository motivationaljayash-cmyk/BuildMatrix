/*
# BuildMarket Admin RLS Policies

This migration adds admin-level access policies to all marketplace tables.
Admin users (role = 'admin' in profiles) can read and manage all records.

## Security
- Creates a helper function `is_admin()` that checks if the current user has admin role
- Adds admin SELECT/INSERT/UPDATE/DELETE policies on all marketplace tables
- Admin can manage: sellers, transporters, products, orders, payments, deliveries, 
  reviews, notifications, support tickets, commissions, settlements, platform settings, categories
*/

-- ============ HELPER FUNCTION ============
CREATE OR REPLACE FUNCTION is_admin()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
STABLE
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM profiles
    WHERE id = auth.uid() AND role = 'admin'
  );
$$;

-- ============ CATEGORIES (admin write) ============
DROP POLICY IF EXISTS "admin_manage_categories" ON categories;
CREATE POLICY "admin_manage_categories" ON categories FOR ALL
  TO authenticated USING (is_admin()) WITH CHECK (is_admin());

-- ============ PROFILES (admin read all) ============
DROP POLICY IF EXISTS "admin_read_all_profiles" ON profiles;
CREATE POLICY "admin_read_all_profiles" ON profiles FOR SELECT
  TO authenticated USING (is_admin());

DROP POLICY IF EXISTS "admin_update_all_profiles" ON profiles;
CREATE POLICY "admin_update_all_profiles" ON profiles FOR UPDATE
  TO authenticated USING (is_admin()) WITH CHECK (is_admin());

-- ============ SELLER_PROFILES (admin manage) ============
DROP POLICY IF EXISTS "admin_read_all_seller_profiles" ON seller_profiles;
CREATE POLICY "admin_read_all_seller_profiles" ON seller_profiles FOR SELECT
  TO authenticated USING (is_admin());

DROP POLICY IF EXISTS "admin_update_all_seller_profiles" ON seller_profiles;
CREATE POLICY "admin_update_all_seller_profiles" ON seller_profiles FOR UPDATE
  TO authenticated USING (is_admin()) WITH CHECK (is_admin());

-- Public can read approved seller profiles (for store pages)
DROP POLICY IF EXISTS "anon_read_approved_seller_profiles" ON seller_profiles;
CREATE POLICY "anon_read_approved_seller_profiles" ON seller_profiles FOR SELECT
  TO anon, authenticated USING (verification_status = 'approved');

-- ============ TRANSPORTER_PROFILES (admin manage) ============
DROP POLICY IF EXISTS "admin_read_all_transporter_profiles" ON transporter_profiles;
CREATE POLICY "admin_read_all_transporter_profiles" ON transporter_profiles FOR SELECT
  TO authenticated USING (is_admin());

DROP POLICY IF EXISTS "admin_update_all_transporter_profiles" ON transporter_profiles;
CREATE POLICY "admin_update_all_transporter_profiles" ON transporter_profiles FOR UPDATE
  TO authenticated USING (is_admin()) WITH CHECK (is_admin());

-- ============ VEHICLES (admin read) ============
DROP POLICY IF EXISTS "admin_read_all_vehicles" ON vehicles;
CREATE POLICY "admin_read_all_vehicles" ON vehicles FOR SELECT
  TO authenticated USING (is_admin());

-- ============ PRODUCTS (admin manage) ============
DROP POLICY IF EXISTS "admin_read_all_products" ON products;
CREATE POLICY "admin_read_all_products" ON products FOR SELECT
  TO authenticated USING (is_admin());

DROP POLICY IF EXISTS "admin_update_all_products" ON products;
CREATE POLICY "admin_update_all_products" ON products FOR UPDATE
  TO authenticated USING (is_admin()) WITH CHECK (is_admin());

-- ============ PRODUCT_IMAGES (admin manage) ============
DROP POLICY IF EXISTS "admin_read_all_product_images" ON product_images;
CREATE POLICY "admin_read_all_product_images" ON product_images FOR SELECT
  TO authenticated USING (is_admin());

-- ============ ORDERS (admin manage) ============
DROP POLICY IF EXISTS "admin_read_all_orders" ON orders;
CREATE POLICY "admin_read_all_orders" ON orders FOR SELECT
  TO authenticated USING (is_admin());

DROP POLICY IF EXISTS "admin_update_all_orders" ON orders;
CREATE POLICY "admin_update_all_orders" ON orders FOR UPDATE
  TO authenticated USING (is_admin()) WITH CHECK (is_admin());

-- ============ ORDER_ITEMS (admin read) ============
DROP POLICY IF EXISTS "admin_read_all_order_items" ON order_items;
CREATE POLICY "admin_read_all_order_items" ON order_items FOR SELECT
  TO authenticated USING (is_admin());

-- ============ PAYMENTS (admin manage) ============
DROP POLICY IF EXISTS "admin_read_all_payments" ON payments;
CREATE POLICY "admin_read_all_payments" ON payments FOR SELECT
  TO authenticated USING (is_admin());

DROP POLICY IF EXISTS "admin_update_all_payments" ON payments;
CREATE POLICY "admin_update_all_payments" ON payments FOR UPDATE
  TO authenticated USING (is_admin()) WITH CHECK (is_admin());

-- ============ PAYMENT_PROOFS (admin read) ============
DROP POLICY IF EXISTS "admin_read_all_payment_proofs" ON payment_proofs;
CREATE POLICY "admin_read_all_payment_proofs" ON payment_proofs FOR SELECT
  TO authenticated USING (is_admin());

-- ============ DELIVERIES (admin manage) ============
DROP POLICY IF EXISTS "admin_read_all_deliveries" ON deliveries;
CREATE POLICY "admin_read_all_deliveries" ON deliveries FOR SELECT
  TO authenticated USING (is_admin());

DROP POLICY IF EXISTS "admin_update_all_deliveries" ON deliveries;
CREATE POLICY "admin_update_all_deliveries" ON deliveries FOR UPDATE
  TO authenticated USING (is_admin()) WITH CHECK (is_admin());

-- ============ REVIEWS (admin manage) ============
DROP POLICY IF EXISTS "admin_manage_all_reviews" ON reviews;
CREATE POLICY "admin_manage_all_reviews" ON reviews FOR ALL
  TO authenticated USING (is_admin()) WITH CHECK (is_admin());

-- ============ NOTIFICATIONS (admin insert to any user) ============
DROP POLICY IF EXISTS "admin_insert_all_notifications" ON notifications;
CREATE POLICY "admin_insert_all_notifications" ON notifications FOR INSERT
  TO authenticated WITH CHECK (is_admin());

-- ============ SUPPORT_TICKETS (admin manage) ============
DROP POLICY IF EXISTS "admin_read_all_tickets" ON support_tickets;
CREATE POLICY "admin_read_all_tickets" ON support_tickets FOR SELECT
  TO authenticated USING (is_admin());

DROP POLICY IF EXISTS "admin_update_all_tickets" ON support_tickets;
CREATE POLICY "admin_update_all_tickets" ON support_tickets FOR UPDATE
  TO authenticated USING (is_admin()) WITH CHECK (is_admin());

-- ============ SUPPORT_TICKET_REPLIES (admin manage) ============
DROP POLICY IF EXISTS "admin_read_all_ticket_replies" ON support_ticket_replies;
CREATE POLICY "admin_read_all_ticket_replies" ON support_ticket_replies FOR SELECT
  TO authenticated USING (is_admin());

DROP POLICY IF EXISTS "admin_insert_all_ticket_replies" ON support_ticket_replies;
CREATE POLICY "admin_insert_all_ticket_replies" ON support_ticket_replies FOR INSERT
  TO authenticated WITH CHECK (is_admin());

-- ============ COMMISSIONS (admin manage) ============
DROP POLICY IF EXISTS "admin_read_all_commissions" ON commissions;
CREATE POLICY "admin_read_all_commissions" ON commissions FOR SELECT
  TO authenticated USING (is_admin());

DROP POLICY IF EXISTS "admin_update_all_commissions" ON commissions;
CREATE POLICY "admin_update_all_commissions" ON commissions FOR UPDATE
  TO authenticated USING (is_admin()) WITH CHECK (is_admin());

-- ============ SETTLEMENTS (admin manage) ============
DROP POLICY IF EXISTS "admin_read_all_settlements" ON settlements;
CREATE POLICY "admin_read_all_settlements" ON settlements FOR SELECT
  TO authenticated USING (is_admin());

DROP POLICY IF EXISTS "admin_update_all_settlements" ON settlements;
CREATE POLICY "admin_update_all_settlements" ON settlements FOR UPDATE
  TO authenticated USING (is_admin()) WITH CHECK (is_admin());

-- ============ PLATFORM_SETTINGS (admin manage) ============
DROP POLICY IF EXISTS "admin_manage_platform_settings" ON platform_settings;
CREATE POLICY "admin_manage_platform_settings" ON platform_settings FOR ALL
  TO authenticated USING (is_admin()) WITH CHECK (is_admin());

-- ============ ADDRESSES (admin read for order delivery) ============
DROP POLICY IF EXISTS "admin_read_all_addresses" ON addresses;
CREATE POLICY "admin_read_all_addresses" ON addresses FOR SELECT
  TO authenticated USING (is_admin());

-- ============ AUTO-CREATE PROFILE ON SIGNUP ============
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, role)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', 'New User'),
    COALESCE(NEW.raw_user_meta_data->>'role', 'buyer')
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();